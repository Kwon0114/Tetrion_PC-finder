# Tetrion PC Finder — 파트별 분리본

`Tetrion_PCfinder_1.html`(4,474줄 한 파일)을 기능별 조각으로 나눈 것입니다. 합치면 원본과 **글자 하나까지 같은** 파일이 나옵니다.
(원본 1번 줄과 마지막 줄은 HTML 뷰어 앱이 붙인 감싸기용이라 제외했습니다.)

```
src/
  index.html      마크업 + 오프라인 등록 스크립트. {{STYLE}}, {{APP}} 자리에 아래가 들어감
  style.css       스타일 전체
  js/             앱 스크립트 조각 25개 (파일 이름 순서 = 실행 순서)
build.py          python3 build.py  →  dist/Tetrion_PCfinder.html 생성
dist/             만들어진 단일 파일 (이것을 열거나 배포)
```

## js/ 조각
| 파일 | 내용 |
|---|---|
| 00-prelude | strict 모드, 언어(LANG)와 L(한국어, 영어) |
| **엔진 (10~16, 워커로 복사되는 구간)** | |
| 10-engine-pieces | 보드 상수, 미노 모양, SRS 킥 표, 배치·스핀 판정, 이동 가능 판정 |
| 11-engine-scoring | 백투백 마스크, Jstris 점수, 파레토 플레이, 쌓는 순서(steps) |
| 12-engine-search | 큐 열거, 보드 저장소, 스캔·컬·배치(solve3), 셋업 파인더 기초 |
| 13-engine-mincover | 최소해법(minCoverG), 커버 순서 |
| 14-engine-search0 | PC 탐색 본체(search, search0) |
| 15-engine-see | See N 분석, 결과 스냅샷 |
| 16-engine-queue-syntax | 큐 문법 해석(parseQ), 큐 개수 추정, 큐 생성 |
| **화면·실행** | |
| 20-editor-board | 보드 편집기(그리기, 높이), 상태 표시 |
| 21-run-state | 실행 상태 변수, 진행 문구, See 힌트 |
| 22-run-finish | 셋업 결과 표시, 실행 종료 처리(finishRun) |
| 30-worker-pool | 워커 엔진 소스, 병렬 실행(runPool), 결과 병합, 메인 스레드 대체 |
| 31-run-controls | 셋업 파인더 UI, 실행 버튼 |
| 32-fumen | 후멘 인코딩·디코딩 |
| 33-saved-results | 마지막 결과 저장·복원 |
| 34-queue-info-history | 큐 경우의 수 안내, 연산 기록 |
| 35-results-render | 결과 화면(최소 조합, 실패 큐, 점수, 예시 플레이) |
| 36-min-set-worker | 최소 조합 계산 워커 |
| 37-play-viewer | 예시 쌓는 순서 재생 |
| 38-fumen-ui-lang | 후멘 가져오기·내보내기 UI, 옵션 요약, 번역표(STATIC), 언어 전환 |
| **구축 확률 모드** | |
| 40-build-boards | 보드 목록·칩, 묶음, 드래그 정렬, 삭제, 모드 전환 |
| 41-build-spec-conds | 보드 해석(suSpec), 조건 목록과 선택 UI |
| 42-build-solver | 한 보드의 큐 평가기(suSolver), 계산·실행·결과 표시 |
| 43-pc-board-picker | PC 모드의 보드 선택, 설정 목록 |
| 50-persist-init | 자동 저장·복원, 시작 처리 |

## 고칠 때 주의
- 모든 조각이 **하나의 함수 안(공유 범위)** 에서 이어 붙습니다. 조각 순서를 바꾸거나 한 조각의 코드를 다른 조각 위로 옮기면 `const`/`let`가 선언 전에 쓰여 깨질 수 있습니다.
- 워커는 `10-engine-pieces`의 `self.__ENGINE_START=1`부터 `16-engine-queue-syntax`의 `self.__ENGINE_END=1`까지를 통째로 복사해 씁니다. 엔진 조각(10~16) 사이에 화면 코드를 넣으면 워커에서 `document` 오류가 납니다.
- 조각을 새로 만들 때는 번호 접두어로 순서를 정하세요.
