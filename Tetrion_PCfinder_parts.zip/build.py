#!/usr/bin/env python3
"""조각(src/)을 합쳐 단일 HTML(dist/Tetrion_PCfinder.html)을 만든다.   python3 build.py
index.html 의 {{STYLE}} 자리에 style.css 를, {{APP}} 자리에 js/ 조각들을 파일 이름 순서대로 이어 붙인 앱 스크립트를 넣는다.
앱 스크립트는 (function(){ ... })(); 로 감싼다. 조각 사이는 줄바꿈 하나이고 순서가 곧 실행 순서다."""
import glob, os
here = os.path.dirname(os.path.abspath(__file__))
src = os.path.join(here, 'src')
rd = lambda p: open(p, encoding='utf8').read()
css = rd(os.path.join(src, 'style.css')).rstrip('\n')
parts = sorted(glob.glob(os.path.join(src, 'js', '*.js')))
app = '(function(){\n' + '\n'.join(rd(p).rstrip('\n') for p in parts) + '\n})();'
html = rd(os.path.join(src, 'index.html')).replace('{{STYLE}}', css).replace('{{APP}}', app)
os.makedirs(os.path.join(here, 'dist'), exist_ok=True)
out = os.path.join(here, 'dist', 'Tetrion_PCfinder.html')
open(out, 'w', encoding='utf8').write(html)
print(f'{len(parts)}개 조각 -> {out} ({len(html.encode("utf8")):,} bytes)')
