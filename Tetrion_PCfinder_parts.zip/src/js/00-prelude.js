"use strict";
let LANG='ko';
const L=(ko,en)=>LANG==='en'?en:ko;
