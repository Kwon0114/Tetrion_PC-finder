self.__ENGINE_START=1;
const COLS=10, BUF=4, CELL=26, MAXL=8;
  const COLORS = {
    I: '#68d7cd', O: '#f6d975', T: '#c995fc', S: '#8ddd9f',
    Z: '#ff8080', J: '#729df1', L: '#ffb26a', G: '#5a6472'
  };
  const SHAPES = {
    I: { size:4, states:[
      [[0,1],[1,1],[2,1],[3,1]], [[2,0],[2,1],[2,2],[2,3]],
      [[0,2],[1,2],[2,2],[3,2]], [[1,0],[1,1],[1,2],[1,3]] ] },
    O: { size:4, states:[
      [[1,0],[2,0],[1,1],[2,1]], [[1,0],[2,0],[1,1],[2,1]],
      [[1,0],[2,0],[1,1],[2,1]], [[1,0],[2,0],[1,1],[2,1]] ] },
    T: { size:3, states:[
      [[1,0],[0,1],[1,1],[2,1]], [[1,0],[1,1],[2,1],[1,2]],
      [[0,1],[1,1],[2,1],[1,2]], [[1,0],[0,1],[1,1],[1,2]] ] },
    S: { size:3, states:[
      [[1,0],[2,0],[0,1],[1,1]], [[1,0],[1,1],[2,1],[2,2]],
      [[1,1],[2,1],[0,2],[1,2]], [[0,0],[0,1],[1,1],[1,2]] ] },
    Z: { size:3, states:[
      [[0,0],[1,0],[1,1],[2,1]], [[2,0],[1,1],[2,1],[1,2]],
      [[0,1],[1,1],[1,2],[2,2]], [[1,0],[0,1],[1,1],[0,2]] ] },
    J: { size:3, states:[
      [[0,0],[0,1],[1,1],[2,1]], [[1,0],[2,0],[1,1],[1,2]],
      [[0,1],[1,1],[2,1],[2,2]], [[1,0],[1,1],[0,2],[1,2]] ] },
    L: { size:3, states:[
      [[2,0],[0,1],[1,1],[2,1]], [[1,0],[1,1],[1,2],[2,2]],
      [[0,1],[1,1],[2,1],[0,2]], [[0,0],[1,0],[1,1],[1,2]] ] }
  };
  const KICKS_JLSTZ = {
    "0>1": [[0,0],[-1,0],[-1,-1],[0,2],[-1,2]],
    "1>0": [[0,0],[1,0],[1,1],[0,-2],[1,-2]],
    "1>2": [[0,0],[1,0],[1,1],[0,-2],[1,-2]],
    "2>1": [[0,0],[-1,0],[-1,-1],[0,2],[-1,2]],
    "2>3": [[0,0],[1,0],[1,-1],[0,2],[1,2]],
    "3>2": [[0,0],[-1,0],[-1,1],[0,-2],[-1,-2]],
    "3>0": [[0,0],[-1,0],[-1,1],[0,-2],[-1,-2]],
    "0>3": [[0,0],[1,0],[1,-1],[0,2],[1,2]]
  };
  // TETR.IO SRS+ uses a symmetric I-piece 90-degree kick table rather than
  // the asymmetric Guideline SRS I table.
  const KICKS_I = {
    "0>1": [[0,0],[1,0],[-2,0],[-2,1],[1,-2]],
    "1>2": [[0,0],[-1,0],[2,0],[-1,-2],[2,1]],
    "2>3": [[0,0],[2,0],[-1,0],[2,-1],[-1,2]],
    "3>0": [[0,0],[1,0],[-2,0],[1,2],[-2,-1]],
    "0>3": [[0,0],[-1,0],[2,0],[2,1],[-1,-2]],
    "1>0": [[0,0],[-1,0],[2,0],[-1,2],[2,-1]],
    "2>1": [[0,0],[-2,0],[1,0],[-2,-1],[1,2]],
    "3>2": [[0,0],[1,0],[-2,0],[1,-2],[-2,1]]
  };
  // TETR.IO's default SRS+ adds direction-dependent 180-degree kicks instead
  // of one generic table: JLSTZ get six tests per facing, I gets two, and O
  // never meaningfully rotates.
  const KICKS_180_JLSTZ = {
    0: [[0,0],[0,-1],[1,-1],[-1,-1],[1,0],[-1,0]],
    1: [[0,0],[1,0],[1,-2],[1,-1],[0,-2],[0,-1]],
    2: [[0,0],[0,1],[-1,1],[1,1],[-1,0],[1,0]],
    3: [[0,0],[-1,0],[-1,-2],[-1,-1],[0,-2],[0,-1]]
  };
  const KICKS_180_I = {
    0: [[0,0],[0,-1]],
    1: [[0,0],[1,0]],
    2: [[0,0],[0,1]],
    3: [[0,0],[-1,0]]
  };
  // Standard Guideline SRS I-piece table (Jstris). y-down version of the usual y-up table.
  const KICKS_I_SRS = {
    "0>1": [[0,0],[-2,0],[1,0],[-2,1],[1,-2]],
    "1>0": [[0,0],[2,0],[-1,0],[2,-1],[-1,2]],
    "1>2": [[0,0],[-1,0],[2,0],[-1,-2],[2,1]],
    "2>1": [[0,0],[1,0],[-2,0],[1,2],[-2,-1]],
    "2>3": [[0,0],[2,0],[-1,0],[2,-1],[-1,2]],
    "3>2": [[0,0],[-2,0],[1,0],[-2,1],[1,-2]],
    "3>0": [[0,0],[1,0],[-2,0],[1,2],[-2,-1]],
    "0>3": [[0,0],[-1,0],[2,0],[-1,-2],[2,1]]
  };
  let JSI = false;   // true = Jstris preset: I piece uses the standard SRS table instead of TETR.IO's SRS+
  function setJSI(v){ v = !!v; if (v !== JSI){ JSI = v; for (const k in KK) delete KK[k]; PKCACHE.clear(); pkN = 0; SPCACHE.clear(); } }
  const KICK_KEYS = ['0>0','0>1','0>2','0>3','1>0','1>1','1>2','1>3','2>0','2>1','2>2','2>3','3>0','3>1','3>2','3>3'];
  function getKicks(type, from, to){
    if (type === 'O') return [[0,0]];
    const table = type === 'I' ? (JSI ? KICKS_I_SRS : KICKS_I) : KICKS_JLSTZ;
    return table[KICK_KEYS[from*4+to]] || [[0,0]];
  }
  // 180-degree kicks are keyed by the piece's facing before the turn (not by
  // a from>to pair — TETR.IO's table is direction-dependent, not symmetric).
  // u = 0 (180 off) or 64+mask: bit i (0..4) of mask = kick test #(i+2) enabled. Test #1 (0,0) is always on.
  function get180Kicks(type, from, u){
    if (type === 'O') return [[0,0]];
    const table = type === 'I' ? KICKS_180_I : KICKS_180_JLSTZ;
    const base = table[from] || [[0,0]], m = u === undefined ? 31 : (u & 31);
    return base.filter((_,i)=>i===0||(m>>(i-1))&1);
  }

//LOGIC_START
const D90=[1,3],D180=[1,3,2],MAXB=28;
// Per piece/rotation: row masks (so a collision test is a few ANDs) + column bounds
const PM={};
for(const t of Object.keys(SHAPES)) PM[t]=SHAPES[t].states.map(cs=>{
  const m={};let lo=9,hi=0,y0=9;
  for(const [cx,cy] of cs){m[cy]=(m[cy]||0)|(1<<cx);lo=Math.min(lo,cx);hi=Math.max(hi,cx);y0=Math.min(y0,cy);}
  const g=[];for(const k in m)g.push(+k,m[k]);
  // numeric id parts: bounding-box origin (lo,y0) + packed sorted cell offsets (no strings/arrays in the hot paths)
  const offs=cs.map(([cx,cy])=>(cy-y0)*10+(cx-lo)).sort((a,b)=>a-b);
  const sig=((offs[0]*128+offs[1])*128+offs[2])*128+offs[3];
  return {g,lo,hi,y0,sig};
});
for(const t of Object.keys(PM)){const seen=[];for(const P of PM[t]){let k=seen.indexOf(P.sig);if(k<0){k=seen.length;seen.push(P.sig);}P.sg=k;}}   // sg: index of the rotation's distinct shape (0..3), for the dedupe stamp
const SIGM=268435456;   // 128^4: a placement id = (top*10+left)*SIGM + sig
let _mx=0,_my=0;
// Packed shape signature of 4 cells [[x,y],..] (sorted offsets from the bounding-box origin); leaves the origin in _mx/_my.
function sigOf(cs){
  let mx=99,my=99;
  for(let i=0;i<4;i++){const c=cs[i];if(c[0]<mx)mx=c[0];if(c[1]<my)my=c[1];}
  let a=(cs[0][1]-my)*10+cs[0][0]-mx,b=(cs[1][1]-my)*10+cs[1][0]-mx,c=(cs[2][1]-my)*10+cs[2][0]-mx,d=(cs[3][1]-my)*10+cs[3][0]-mx,t;
  if(a>b){t=a;a=b;b=t;} if(c>d){t=c;c=d;d=t;} if(a>c){t=a;a=c;c=t;} if(b>d){t=b;b=d;d=t;} if(b>c){t=b;b=c;c=t;}
  _mx=mx;_my=my;
  return ((a*128+b)*128+c)*128+d;
}
const cellsId=cs=>{const q=sigOf(cs);return (_my*10+_mx)*SIGM+q;};
// Every lock position reachable via move / soft drop / rotate (SRS kicks), as placement ids (see cellsId).
// Bit-parallel: for every (rotation, row y) one mask holds all columns at once (bit b = column x+3).
//   valid[r][y]  columns where the piece fits at row y (4 shifted ANDs of the board rows)
//   reach[r][y]  columns the piece can reach at row y
// Soft drop is one AND with the next row's valid mask, sliding is a shift-and-AND flood, and a rotation tries the kicks in order on all columns
// at once (a column that already found a kick is done). Above the stack the piece moves freely, so rows y <= free only drop (as before).
const XO=3, XM=0x1FFF, SCN=4*(MAXB+2);
const INB={};for(const t of Object.keys(SHAPES)) INB[t]=PM[t].map(P=>{let m=0;for(let x=-P.lo;x+P.hi<COLS;x++) m|=1<<(x+XO);return m;});
// kick lists per (piece, 180 setting u: 0 off / 64+mask of enabled kicks #2-#6): KK[t][u180][d*4+r] = flat [kx,ky,kx,ky,...]
const KK={};function kkFor(t,u){const c=KK[t]||(KK[t]={});return c[u]||(c[u]=buildKK(t,u));}
function buildKK(t,u){return (u=>{const a=[];for(const d of (u?D180:D90)) for(let r=0;r<4;r++){const ks=t==='O'?[[0,0]]:(d===2?get180Kicks(t,r,u):getKicks(t,r,(r+d)%4));a[d*4+r]=ks.flat();}return a;})(u);}
const ID_OUT=new Float64Array(1024);   // placementIds writes its (distinct) ids here and returns the count: no array per call
const S_STAMP=new Int32Array(4096);let S_GEN=0;   // dedupe of placement ids: stamp[(row*10+col)*4+shape] === current call number
const S_VALID=new Int32Array(SCN),S_REACH=new Int32Array(SCN),S_V=new Int32Array(SCN),S_DIRTY=new Uint8Array(SCN),S_STK=new Int32Array(SCN*2+8);
const ID_TL=new Int32Array(1024),ID_SG=new Int32Array(1024);
function placementIds(rows,t,u180,B,spin,rotOut){
  const W=B+2,N=4*W,NR=(t==='O'&&!rotOut)?1:4,cs=SHAPES[t].states,PMt=PM[t],inb=INB[t],kk=kkFor(t,u180|0);
  const valid=S_VALID,reach=S_REACH,V=S_V,dirty=S_DIRTY,stk=S_STK;
  reach.fill(0,0,N);dirty.fill(0,0,N);if(rotOut){S_ROT.fill(0,0,N);S_ROT5.fill(0,0,N);}
  for(let r=0;r<NR;r++){
    const c=cs[r],base=r*W;
    for(let y=0;y<B;y++){
      let bad=0,ok=true;
      for(let k=0;k<4;k++){const Y=y+c[k][1];if(Y<0||Y>=B){ok=false;break;}bad|=(rows[Y]<<XO)>>c[k][0];}
      valid[base+y]=ok?(inb[r]&~bad&XM):0;
    }
    valid[base+B]=0;valid[base+B+1]=0;
  }
  let top=B;for(let i=0;i<B;i++) if(rows[i]){top=i;break;}
  const free=top-5;
  let nid=0;const out=ID_OUT,stamp=S_STAMP;
  if(++S_GEN>2000000000){stamp.fill(0);S_GEN=1;}
  const gen=S_GEN;
  let sp=0;
  // straight drops (rotate / shift above the stack, then drop): same ids, no free limit
  for(let r=0;r<NR;r++){
    const P=PMt[r],base=r*W;let v=valid[base];reach[base]=v;V[base]=v;
    for(let y=0;y<B;y++){
      if(y>0){v=V[base+y-1]&valid[base+y];V[base+y]=v;}
      const lk=v&~valid[base+y+1];
      if(lk&&y+P.y0>=BUF) for(let lm=lk;lm;lm&=lm-1){const b=31-Math.clz32(lm&-lm);const yy=y+P.y0,tl=yy*10+(b-XO+P.lo),ci=(tl<<2)|P.sg;if(stamp[ci]!==gen){stamp[ci]=gen;ID_TL[nid]=tl;ID_SG[nid]=P.sig;out[nid++]=tl*SIGM+P.sig;}}
    }
    dirty[base]=1;stk[sp++]=r;stk[sp++]=0;
  }
  if(spin===false) return nid;
  const nd=NR===1?0:(u180?3:2);
  while(sp>0){
    const y=stk[--sp],r=stk[--sp],i=r*W+y;dirty[i]=0;
    let m=reach[i];
    if(y+1<B){const a=m&valid[i+1],j=i+1;if(a&&(reach[j]|a)!==reach[j]){reach[j]|=a;if(!dirty[j]){dirty[j]=1;stk[sp++]=r;stk[sp++]=y+1;}}}
    if(y<=free) continue;
    const vv=valid[i];
    for(;;){const n2=(m|(m<<1)|(m>>1))&vv;if(n2===m) break;m=n2;}
    reach[i]=m;
    if(y+1<B){const a=m&valid[i+1],j=i+1;if(a&&(reach[j]|a)!==reach[j]){reach[j]|=a;if(!dirty[j]){dirty[j]=1;stk[sp++]=r;stk[sp++]=y+1;}}}
    const P=PMt[r];
    if(y+P.y0>=BUF){
      const lk=m&~valid[i+1];
      if(lk) for(let lm=lk;lm;lm&=lm-1){const b=31-Math.clz32(lm&-lm);const yy=y+P.y0,tl=yy*10+(b-XO+P.lo),ci=(tl<<2)|P.sg;if(stamp[ci]!==gen){stamp[ci]=gen;ID_TL[nid]=tl;ID_SG[nid]=P.sig;out[nid++]=tl*SIGM+P.sig;}}
    }
    for(let di=0;di<nd;di++){
      const d=u180?(di===2?2:(di===0?1:3)):(di===0?1:3);
      const nr=(r+d)%4,ks=kk[d*4+r];let done=0;
      for(let q=0;q<ks.length;q+=2){
        const kx=ks[q],Y=y+ks[q+1];if(Y<0||Y>=B) continue;
        const tv=valid[nr*W+Y];
        const src=m&~done&(kx>=0?tv>>kx:(tv<<-kx)&XM);
        if(!src) continue;
        done|=src;
        const dst=kx>=0?(src<<kx):(src>>-kx),j=nr*W+Y;
        if(rotOut){S_ROT[j]|=dst;if(q===8&&d!==2) S_ROT5[j]|=dst;}   // q===8: the 5th SRS kick test (1x2 offset) = T-spin exception
        if((reach[j]|dst)!==reach[j]){reach[j]|=dst;if(!dirty[j]){dirty[j]=1;stk[sp++]=nr;stk[sp++]=Y;}}
      }
    }
  }
  if(rotOut){
    // spin locks: positions entered by a ROTATION as the last move that rest there and are immobile (cannot move left / right / up);
    // T also counts with 3 of its 4 corners filled
    for(let r=0;r<4;r++){
      const P=PMt[r],base=r*W;
      for(let y=0;y<B;y++){
        if(y+P.y0<BUF) continue;
        const i=base+y,vv=valid[i];
        const lk=S_ROT[i]&~valid[i+1]&XM;
        if(!lk) continue;
        const mob=((vv<<1)|(vv>>1)|(y>0?valid[i-1]:0))&XM;
        for(let b=0;b<13;b++){
          if(!((lk>>b)&1)) continue;
          let ok=!((mob>>b)&1);
          if(!ok&&t==='T'){
            const c=tcen(r),cx=b-XO+c[0],cy=y+c[1];let n=0;
            for(const dx of [-1,1]) for(const dy of [-1,1]){
              const X=cx+dx,Y=cy+dy;
              if(X<0||X>=COLS||Y>=B||(Y>=0&&((rows[Y]>>X)&1))) n++;
            }
            ok=n>=3;
          }
          if(ok){const id=((y+P.y0)*10+(b-XO+P.lo))*SIGM+P.sig;rotOut.add(id);if(t==='T'&&rotOut.k5&&((S_ROT5[i]>>b)&1)) rotOut.k5.add(id);}
        }
      }
    }
  }
  return nid;
}
const S_ROT=new Int32Array(SCN),S_ROT5=new Int32Array(SCN);
const TCEN=[];
function tcen(r){
  if(TCEN[r]) return TCEN[r];
  const c=SHAPES.T.states[r];
  for(const a of c){let n=0;for(const b of c) if(Math.abs(a[0]-b[0])+Math.abs(a[1]-b[1])===1) n++;if(n===3) return TCEN[r]=a;}
  return TCEN[r]=c[0];
}
const SPCACHE=new Map();
function spinOK(rows,t,cs,u180,B){
  const key=rows.join(',')+t+(u180|0);
  let s=SPCACHE.get(key);
  if(!s){if(SPCACHE.size>=20000) SPCACHE.clear();s=new Set();s.k5=new Set();placementIds(rows,t,u180,B,true,s);SPCACHE.set(key,s);}
  return s.has(cellsId(cs));
}
// T-spin exception: the last rotation used the 5th kick test (1x2 offset) -> a full T-spin even when the front corners are not both filled.
function spinFull(rows,cs,u180,B){
  const key=rows.join(',')+'T'+(u180|0);
  let s=SPCACHE.get(key);
  if(!s){spinOK(rows,'T',cs,u180,B);s=SPCACHE.get(key);}
  return !!(s&&s.k5&&s.k5.has(cellsId(cs)));
}
const POP=new Uint8Array(1024);for(let i=1;i<1024;i++) POP[i]=POP[i>>1]+(i&1);   // bit counts of 0..1023 (a board row is 10 bits)
const popc=v=>{let c=0;while(v){c+=POP[v&1023];v>>>=10;}return c;};   // any int32, built on POP
const CR=new Uint8Array(64), CB=new Int32Array(64);   // cell index -> row / column bit
for(let i=0;i<64;i++){CR[i]=(i/COLS)|0;CB[i]=1<<(i%COLS);}

const TYPES='IOTSZJL';
// A piece as it sits on the (already cleared) board, ignoring where it is: used to reject pieces whose rows are not adjacent yet
const SHKN={};for(const t of TYPES) SHKN[t]=new Set(SHAPES[t].states.map(sigOf));
const TIDX={I:0,O:1,T:2,S:3,Z:4,J:5,L:6};
function tState(T,S,ctx){
  let st=T.st.get(S);if(st) return st;
  const {rows0,B}=ctx, rows=rows0.slice();
  for(let i=0;i<T.p.length;i++) if((S>>i)&1) for(const [x,id] of T.p[i].cells) rows[id+BUF]|=1<<x;
  const pos=new Int16Array(B).fill(-1), kept=[];
  for(let r=0;r<B;r++) if(rows[r]!==1023) kept.push(r);
  const c=B-kept.length;
  kept.forEach((r,j)=>{pos[r]=c+j;});
  st={rows:Array(c).fill(0).concat(kept.map(r=>rows[r])),pos};
  T.st.set(S,st);return st;
}
function isHard(rows,cs,B){
  // 1) nothing filled above the piece in any of its columns (it can drop straight in)
  for(let i=0;i<4;i++){
    const x=cs[i][0],y=cs[i][1];
    let isTop=true;
    for(let j=0;j<4;j++) if(cs[j][0]===x&&cs[j][1]<y){isTop=false;break;}
    if(isTop) for(let yy=0;yy<y;yy++) if((rows[yy]>>x)&1) return false;
  }
  // 2) it rests on the floor or on a filled cell that is not its own
  for(let i=0;i<4;i++){
    const x=cs[i][0],y=cs[i][1];
    if(y+1>=B) return true;
    if((rows[y+1]>>x)&1){
      let own=false;
      for(let j=0;j<4;j++) if(cs[j][0]===x&&cs[j][1]===y+1){own=true;break;}
      if(!own) return true;
    }
  }
  return false;
}
// reachable lock positions per (stack, piece, 180 setting); survives between runs. Numeric keys only:
// Map<bottom 3 rows, Map<next 3 rows * 256 + (B, piece, 180 flag), Set<placement id>>>
// (the board is at most 6 rows high and everything above is empty, so the bottom 6 rows identify a stack)
const PKCACHE=new Map();let pkN=0;
function canPlace(ctx,st,t,cs){
  const rows=st.rows,B=ctx.B;
  if(isHard(rows,cs,B)) return true;
  if(!ctx.spin) return false;
  if(st.ka===undefined){
    st.ka=rows[B-1]+rows[B-2]*1024+rows[B-3]*1048576;
    st.kb=rows[B-4]+rows[B-5]*1024+rows[B-6]*1048576;
  }
  let bt=st.kb*65536+(B*7+TIDX[t])*128+(ctx.u180|0);
  if(B>6) bt=bt+'|'+(rows[B-7]||0)*1024+(rows[B-8]||0);   // a stack can be up to 8 rows high
  let m=PKCACHE.get(st.ka),s=m&&m.get(bt);
  if(!s){
    if(pkN>=30000){PKCACHE.clear();pkN=0;m=undefined;}
    {const n=placementIds(rows,t,ctx.u180,B);s=new Set();for(let i=0;i<n;i++) s.add(ID_OUT[i]);}
    if(!m){m=new Map();PKCACHE.set(st.ka,m);}
    m.set(bt,s);pkN++;
  }
  return s.has(cellsId(cs));
}
function reachMask(T,S,ctx){
  let m=T.rm.get(S);if(m!==undefined) return m;
  const st=tState(T,S,ctx);m=0;
  for(let i=0;i<T.p.length;i++){
    if((S>>i)&1) continue;
    const p=T.p[i];
    const cs=p.cells.map(([x,id])=>[x,st.pos[id+BUF]]);
    if(cs.every(c=>c[1]>=BUF)&&SHKN[p.t].has(sigOf(cs))&&canPlace(ctx,st,p.t,cs)) m|=1<<i;
  }
  T.rm.set(S,m);return m;
}
