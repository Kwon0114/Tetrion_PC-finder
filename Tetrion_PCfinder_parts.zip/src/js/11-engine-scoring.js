// Placements (of those reachMask allows) that keep back-to-back: no line clear, a quad, a spin clear (any spin) or the final perfect clear.
// Singles / doubles / triples without a spin break it.
function b2bMask(T,S,ctx){
  let m=T.sm.get(S);if(m!==undefined) return m;
  const rm=reachMask(T,S,ctx),n=T.p.length,full=(1<<n)-1,st=tState(T,S,ctx);m=0;
  for(let i=0;i<n;i++){
    if(!((rm>>i)&1)) continue;
    if((S|(1<<i))===full){m|=1<<i;continue;}
    const p=T.p[i],cs=p.cells.map(([x,id])=>[x,st.pos[id+BUF]]);
    const add=new Map();for(const [x,y] of cs) add.set(y,(add.get(y)||0)|(1<<x));
    let lines=0;for(const [y,b] of add) if((st.rows[y]|b)===1023) lines++;
    if(lines===0||lines===4||(ctx.spin&&spinOK(st.rows,p.t,cs,ctx.u180,ctx.B))) m|=1<<i;
  }
  T.sm.set(S,m);return m;
}
// TETR.IO Blitz is scored at level 1 only (no level multiplier)
const JS_NO=[0,100,300,500,800],JS_TS=[400,800,1200,1600,1600];
// Jstris score of one placement -> [points, back-to-back afterwards, combo afterwards]. Every difficult clear (quad / line-clearing T-spin, mini single included) receives the B2B bonus.
function jsCalc(rows,cs,t,sp,ctx){
  const B=rows.length,add={};
  for(const c of cs) add[c[1]]=(add[c[1]]|0)|(1<<c[0]);
  let n=0;for(const y in add) if((rows[y]|add[y])===1023) n++;
  let ts=0;
  if(t==='T'&&sp&&ctx.spin&&spinOK(rows,'T',cs,ctx.u180,B)){
    let ctr=null;
    for(const a of cs){let adj=0;for(const b of cs) if(Math.abs(a[0]-b[0])+Math.abs(a[1]-b[1])===1) adj++;if(adj===3){ctr=a;break;}}
    if(ctr){
      let mx=0,my=0;
      for(const d of [[1,0],[-1,0],[0,1],[0,-1]]) if(!cs.some(c=>c[0]===ctr[0]+d[0]&&c[1]===ctr[1]+d[1])){mx=d[0];my=d[1];}
      let all=0,front=0;
      for(const dx of [-1,1]) for(const dy of [-1,1]){
        const x=ctr[0]+dx,y=ctr[1]+dy,oc=(x<0||x>9||y>=B||(y>=0&&((rows[y]>>x)&1)===1))?1:0;
        all+=oc;if(oc&&(dx*-mx+dy*-my)>0) front++;
      }
      if(all>=3) ts=(front===2||spinFull(rows,cs,ctx.u180,B))?2:1;
    }
  }
  if(ts===1&&n>=2&&!ctx.tio) ts=2;   // Jstris: a mini double counts as a full T-spin double; TETR.IO Blitz scores it as a mini (400)
  const base=ts===2?(ctx.tio&&n===4?2600:JS_TS[n]):ts===1?(ctx.tio?[100,200,400,800,1600][n]:(n===0?100:200)):JS_NO[n];
  const difficult=n===4||(ts>0&&n>0);
  const ev=n===4?0:ts===2?(n===0?1:n===1?4:n===2?5:6):ts===1?(n===0?2:n===1?3:7):-1;   // event id for the clear-type probabilities
  return {n,base,difficult,ev,last:false};
}
// the part that depends on back-to-back / combo: r = jsCalc result (+ r.last)
function jsApply(r,b2b,combo,ctx){
  let pts=(r.difficult&&b2b)?r.base*1.5:r.base;
  if(r.n>0){combo++;pts+=50*combo;b2b=r.difficult;} else combo=-1;
  if(r.last) pts+=ctx.tio?3500:3000;
  return [pts,b2b,combo,r.ev];
}
// Jstris score of one placement -> [points, back-to-back afterwards, combo afterwards]. Every difficult clear (quad / line-clearing T-spin, mini single included) receives the B2B bonus.
// line clears / spin of placing piece i of T after the set S: does not depend on the piece order, back-to-back or combo, so it is worked out once per (S,i)
function jsPlace(T,S,i,ctx){
  const c=T.pl||(T.pl=new Map()),key=S*16+i;
  let r=c.get(key);if(r!==undefined) return r;
  const st=tState(T,S,ctx),p=T.p[i],cs=p.cells.map(([x,id])=>[x,st.pos[id+BUF]]);
  r=jsCalc(st.rows,cs,p.t,!isHard(st.rows,cs,ctx.B),ctx);
  r.last=(S|(1<<i))===(1<<T.p.length)-1;
  c.set(key,r);return r;
}
// best Jstris score of a solution played in the given order of piece types P (same-type pieces may swap roles): DP over placed subsets
function jsBest(T,P,b2b0,ctx,c0){
  const ck=P+(b2b0?'1':'0')+(ctx.tio?'t':'j')+'|'+(c0|0),cache=T.jb||(T.jb=new Map());
  let v=cache.get(ck);if(v!==undefined) return v;
  const n=T.p.length,full=(1<<n)-1,memo=new Map();
  const rec=(S,b2b,combo)=>{
    if(S===full) return 0;
    const mk=(S*2+(b2b?1:0))*64+combo+1;
    let r=memo.get(mk);if(r!==undefined) return r;
    r=-1;
    const t=P[popc(S)],rm=reachMask(T,S,ctx),st=tState(T,S,ctx);
    for(let i=0;i<n;i++){
      if(((S>>i)&1)||!((rm>>i)&1)||T.p[i].t!==t) continue;
      const q=jsApply(jsPlace(T,S,i,ctx),b2b,combo,ctx);
      const sub=rec(S|(1<<i),q[1],q[2]);
      if(sub>=0&&q[0]+sub>r) r=q[0]+sub;
    }
    memo.set(mk,r);return r;
  };
  v=rec(0,b2b0,(c0|0)-1);cache.set(ck,v);return v;
}
// the placement order (indices into T.p) that reaches the best score for the piece-type order P, or null
function jsBestOrder(T,P,b2b0,ctx,c0){
  const n=T.p.length,full=(1<<n)-1,memo=new Map();
  const rec=(S,b2b,combo)=>{
    if(S===full) return {v:0};
    const mk=(S*2+(b2b?1:0))*64+combo+1;
    let r=memo.get(mk);if(r!==undefined) return r;
    r={v:-1};
    const t=P[popc(S)],rm=reachMask(T,S,ctx),st=tState(T,S,ctx);
    for(let i=0;i<n;i++){
      if(((S>>i)&1)||!((rm>>i)&1)||T.p[i].t!==t) continue;
      const q=jsApply(jsPlace(T,S,i,ctx),b2b,combo,ctx);
      const sub=rec(S|(1<<i),q[1],q[2]);
      if(sub.v>=0&&q[0]+sub.v>r.v) r={v:q[0]+sub.v,i,b:q[1],c:q[2]};
    }
    memo.set(mk,r);return r;
  };
  const order=[];let S=0,r=rec(0,b2b0,(c0|0)-1);
  while(S!==full){
    if(r.v<0||r.i===undefined) return null;
    order.push(r.i);S|=1<<r.i;r=rec(S,r.b,r.c);
  }
  return order;
}
// hold usage per placement when the pieces are placed in the type order P from the queue (same rules as seqPath), or null
function holdFlags(queue,P,useHold){
  const n=P.length,dead=new Set(),hid=h=>h?TYPES.indexOf(h)+1:0;
  const go=(j,qi,hold,fl)=>{
    if(j===n) return fl;
    const key=(j*16+qi)*8+hid(hold);
    if(dead.has(key)) return null;
    const cur=queue[qi],t=P[j];let r=null;
    if(cur!==undefined){
      if(cur===t) r=go(j+1,qi+1,hold,fl.concat([false]));
      if(!r&&useHold&&hold!==cur){
        if(hold){if(hold===t) r=go(j+1,qi+1,cur,fl.concat([true]));}
        else if(qi+1<queue.length&&queue[qi+1]===t) r=go(j+1,qi+2,cur,fl.concat([true]));
      }
    } else if(useHold&&hold&&hold===t) r=go(j+1,qi,null,fl.concat([true]));
    if(r) return r;
    dead.add(key);return null;
  };
  return go(0,0,null,[]);
}
// every clear type (JS_EV ids) that some playable placement order of the solution can produce, as a bitmask; -1 if the order cannot be completed
function jsEvents(T,P,ctx){
  const c=jsEvCounts(T,P,ctx);   // same DP as the counts: a type is possible iff its max count is at least 1
  if(!c) return -1;
  let m=0;for(let k=0;k<8;k++) if(c[k]>0) m|=1<<k;
  return m;
}
// the most times each clear type (JS_EV ids 0..7) can happen in ONE complete play of the solution in the given piece order (max over the playable placement orders, per type)
function jsEvCounts(T,P,ctx){
  const cache=T.jc||(T.jc=new Map()),ek=P+(ctx.tio?'t':'j');
  let v=cache.get(ek);if(v!==undefined) return v;
  const n=T.p.length,full=(1<<n)-1,memo=new Map(),Z=[0,0,0,0,0,0,0,0];
  const rec=(S)=>{
    if(S===full) return Z;
    let r=memo.get(S);if(r!==undefined) return r;
    r=null;
    const t=P[popc(S)],rm=reachMask(T,S,ctx),st=tState(T,S,ctx);
    for(let i=0;i<n;i++){
      if(((S>>i)&1)||!((rm>>i)&1)||T.p[i].t!==t) continue;
      const q=[0,0,0,jsPlace(T,S,i,ctx).ev];
      const sub=rec(S|(1<<i));
      if(!sub) continue;
      if(!r) r=[0,0,0,0,0,0,0,0];
      for(let k=0;k<8;k++){const c=sub[k]+(q[3]===k?1:0);if(c>r[k]) r[k]=c;}
    }
    memo.set(S,r);return r;
  };
  v=rec(0);cache.set(ek,v);return v;   // null = the order cannot be completed
}
// keeps only the maximal bitmasks of a collection (a mask contained in another one adds nothing)
function maxMasks(c){
  const a=[...new Set(c)].sort((x,y)=>y-x),out=[];
  for(const m of a){let dom=false;for(const k of out) if((k&m)===m){dom=true;break;}if(!dom) out.push(m);}
  return out;
}
// what ONE complete play of the solution can produce together, per placement order: count vectors (JS_EV id k = 4-bit field k, counts capped at 15).
// Only the Pareto-maximal vectors are kept ([] if the order cannot be completed).
const vecLE=(a,b)=>{for(let k=0;k<8;k++) if(((a>>>(4*k))&15)>((b>>>(4*k))&15)) return false;return true;};
function paretoVecs(c){
  const a=[...new Set(c)].sort((x,y)=>y-x),out=[];
  for(const v of a){let dom=false;for(const w of out) if(vecLE(v,w)){dom=true;break;}if(!dom) out.push(v);}
  return out;
}
const vecMask=v=>{let m=0;for(let k=0;k<8;k++) if((v>>>(4*k))&15) m|=1<<k;return m;};
function jsEvPlaysC(T,P,ctx){
  const cache=T.jp||(T.jp=new Map()),ek=P+(ctx.tio?'t':'j');
  let v=cache.get(ek);if(v!==undefined) return v;
  const n=T.p.length,full=(1<<n)-1,memo=new Map();
  const rec=(S)=>{
    if(S===full) return [0];
    let r=memo.get(S);if(r!==undefined) return r;
    const acc=[];
    const t=P[popc(S)],rm=reachMask(T,S,ctx),st=tState(T,S,ctx);
    for(let i=0;i<n;i++){
      if(((S>>i)&1)||!((rm>>i)&1)||T.p[i].t!==t) continue;
      const k=jsPlace(T,S,i,ctx).ev;
      const inc=k>=0?1<<(4*k):0;
      for(const m of rec(S|(1<<i))) acc.push((m+inc)>>>0);
    }
    r=paretoVecs(acc);memo.set(S,r);return r;
  };
  v=rec(0);cache.set(ek,v);return v;
}
// clear types (JS_EV ids) that ONE complete play of the solution can produce together: the maximal bitmasks over all playable placement orders ([] if the order cannot be completed)
function seqPath(T,queue,hold0,useHold,ctx,safe){
  const n=T.p.length,full=(1<<n)-1,dead=new Set();
  const hid=h=>h?TYPES.indexOf(h)+1:0;
  function go(S,qi,hold,path){
    if(S===full) return path;
    const key=(S*16+qi)*8+hid(hold);
    if(dead.has(key)) return null;
    const cur=queue[qi];
    if(cur!==undefined){
      const m=safe?b2bMask(T,S,ctx):reachMask(T,S,ctx);
      const tryP=(t,nq,nh,used)=>{
        for(let i=0;i<n;i++) if(!((S>>i)&1)&&((m>>i)&1)&&T.p[i].t===t){
          const r=go(S|(1<<i),nq,nh,path.concat([[i,used]]));
          if(r) return r;
        }
        return null;
      };
      let r=tryP(cur,qi+1,hold,false);
      if(!r&&useHold&&hold!==cur){
        if(hold) r=tryP(hold,qi+1,cur,true);
        else if(qi+1<queue.length) r=tryP(queue[qi+1],qi+2,cur,true);
      }
      if(r) return r;
    } else if(useHold&&hold){
      // queue exhausted: in a real game the next piece still spawns, so the held piece can be swapped in for the final placement
      const m=reachMask(T,S,ctx);
      for(let i=0;i<n;i++) if(!((S>>i)&1)&&((m>>i)&1)&&T.p[i].t===hold){
        const r=go(S|(1<<i),qi,null,path.concat([[i,true]]));
        if(r) return r;
      }
    }
    dead.add(key);return null;
  }
  return go(0,0,hold0||null,[]);
}
function buildSteps(T,path,ctx){
  let S=0;const steps=[];
  for(const [i,used] of path){
    const st=tState(T,S,ctx);
    const cs=T.p[i].cells.map(([x,id])=>[x,st.pos[id+BUF]]);
    const ghost=[];
    for(let j=0;j<T.p.length;j++) if(j!==i&&!((S>>j)&1)) ghost.push({t:T.p[j].t,cs:T.p[j].cells.map(([x,id])=>[x,st.pos[id+BUF]])});
    steps.push({t:T.p[i].t,cs,used,ghost,before:st.rows,spin:!isHard(st.rows,cs,ctx.B)});
    S|=1<<i;
  }
  return steps;
}
