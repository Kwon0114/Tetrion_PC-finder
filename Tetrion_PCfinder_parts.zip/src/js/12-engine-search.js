// ================= scan / cull / place =================
// Board search pipeline:
//   1. scan  : place one piece at a time from the start board, stage by stage.  A board knows the queue states (bag contents + hold) it can
//              be reached with and the boards it came from.  Boards are the board AFTER line clears, so equal boards merge.
//   2. cull  : walk back from the final (empty) board and keep only boards that lead to a perfect clear.
//   3. place : scan again over the kept boards only, this time remembering which pieces were placed (in the unrolled picture: a piece placed
//              after a line clear may be split by the cleared rows).  Every surviving piece set is one solution.
// The queue then only has to be checked against the solutions: for each solution every placement order that is playable (spins/tucks, line
// clears) is collected; a queue works when some order of some solution can be played from it with hold.
let RUNID=0;
const MAX_CASES=Infinity;   // no limit on queue cases
const MAX_BAG=13;

class BagM{
  constructor(letters,count){
    this.count=count;this.full=(1<<letters.length)-1;this.masks=new Int32Array(7);
    for(let i=0;i<letters.length;i++) this.masks[TIDX[letters[i]]]|=1<<i;
  }
}
// queue state = 13 bits (pieces of the current bag not drawn yet) + 3 bits (piece in the hold slot)
const qTake=(q,bag,s)=>{const f=q&bag.masks[s];return f?q^(f&-f):-1;};
const qSwap=(q,bag,s)=>{const t=qTake(q,bag,s);return t<0?-1:((t&0x1FFF)|(s<<13));};
// the piece drawn at this stage is either placed (the hold slot keeps its piece) or swapped with the hold slot.
// Without hold the slot just delays the queue by one piece, so only the swap is allowed.
// cache: per-stage Map (q*8+shape -> resulting states); a queue state's result never depends on the board, so it is computed once per stage
function bagTake(qs,bag,shape,isFirst,canHold,cache){
  const out=new Set();
  for(let q of qs){
    const ck=q*8+shape;let r=cache&&cache.get(ck);
    if(!r){
      r=[];let q0=q;
      if(isFirst) q0=(q0&0xE000)|bag.full;
      if((q0>>13)===shape){
        for(let s=0;s<7;s++){if(!bag.masks[s]) continue;const t=qSwap(q0,bag,s);if(t>=0) r.push(t);}
      } else if(canHold){const t=qTake(q0,bag,shape);if(t>=0) r.push(t);}
      if(cache) cache.set(ck,r);
    }
    for(let i=0;i<r.length;i++) out.add(r[i]);
  }
  return out;
}
// ---- compact board store ----------------------------------------------------------------------------------------------------------
// A board is the H rows of the playfield, 10 bits each, packed 5 rows to a number (exact in a double): K1 = rows 0-4, K2 = rows 5-9, K3 = rows 10-11.
// keyOf returns K1 and leaves K2/K3 in the module variables.
let K2=0,K3=0;
function boardKeyFn(H){
  return r=>{let a=0,b=0,c=0;for(let i=0;i<H;i++){const v=r[BUF+i];if(i<5)a=a*1024+v;else if(i<10)b=b*1024+v;else c=c*1024+v;}K2=b;K3=c;return a;};
}
const P1024=[1,1024,1048576,1073741824,1099511627776];
function unpackRows(k1,k2,k3,H,out){
  for(let i=0;i<BUF;i++) out[i]=0;
  for(let i=0;i<H;i++){
    const g=(i/5)|0,j=i-g*5,gs=Math.min(5,H-g*5),V=g===0?k1:g===1?k2:k3;
    out[BUF+i]=Math.floor(V/P1024[gs-1-j])%1024;
  }
  return out;
}
// All boards of one scan step live in typed arrays (about 40 bytes per board instead of several hundred for objects + Sets):
//   board table (open addressing) -> index; per board: key, cleared-line count, alive flag, queue states (linked list in a pool), predecessor edges (linked list).
class Stage{
  constructor(H){
    this.h2=H>5;this.h3=H>10;this.n=0;this.cap=256;this.isNew=false;
    this.k1=new Float64Array(256);this.k2=this.h2?new Float64Array(256):null;this.k3=this.h3?new Int32Array(256):null;
    this.cnt=new Uint8Array(256);this.alive=new Uint8Array(256);
    this.qh=new Int32Array(256).fill(-1);this.eh=new Int32Array(256).fill(-1);
    this.tsz=512;this.tab=new Int32Array(512);
    this.qv=new Uint16Array(1024);this.qn=new Int32Array(1024);this.qc=0;
    this.ef=new Int32Array(1024);this.en=new Int32Array(1024);this.ec=0;
  }
  hash(a,b,c){
    let h=Math.imul(a>>>0,0x9E3779B1)^Math.imul((a/4294967296)>>>0,0x85EBCA6B);
    if(b) h^=Math.imul(b>>>0,0xC2B2AE35)^Math.imul((b/4294967296)>>>0,0x27D4EB2F);
    if(c) h^=Math.imul(c,0x165667B1);
    h^=h>>>15;h=Math.imul(h,0x2C1B3C6D);h^=h>>>12;return h;
  }
  same(i,a,b,c){return this.k1[i]===a&&(!this.h2||this.k2[i]===b)&&(!this.h3||this.k3[i]===c);}
  find(a,b,c){
    const m=this.tsz-1;let s=this.hash(a,b,c)&m;
    for(;;s=(s+1)&m){const t=this.tab[s];if(!t) return -1;if(this.same(t-1,a,b,c)) return t-1;}
  }
  findOrAdd(a,b,c,cn){
    if((this.n+1)*2>this.tsz) this.rehash();
    const m=this.tsz-1;let s=this.hash(a,b,c)&m;
    for(;;s=(s+1)&m){const t=this.tab[s];if(!t) break;if(this.same(t-1,a,b,c)){this.isNew=false;return t-1;}}
    if(this.n===this.cap) this.growNodes();
    const i=this.n++;this.tab[s]=i+1;this.k1[i]=a;if(this.h2) this.k2[i]=b;if(this.h3) this.k3[i]=c;this.cnt[i]=cn;
    this.isNew=true;return i;
  }
  rehash(){
    this.tsz*=2;this.tab=new Int32Array(this.tsz);const m=this.tsz-1;
    for(let i=0;i<this.n;i++){let s=this.hash(this.k1[i],this.h2?this.k2[i]:0,this.h3?this.k3[i]:0)&m;while(this.tab[s]) s=(s+1)&m;this.tab[s]=i+1;}
  }
  growNodes(){
    const nc=this.cap*2,gr=(A,C)=>{const B=new C(nc);B.set(A);return B;};
    this.k1=gr(this.k1,Float64Array);if(this.h2) this.k2=gr(this.k2,Float64Array);if(this.h3) this.k3=gr(this.k3,Int32Array);
    this.cnt=gr(this.cnt,Uint8Array);this.alive=gr(this.alive,Uint8Array);
    const q=new Int32Array(nc).fill(-1);q.set(this.qh);this.qh=q;const e=new Int32Array(nc).fill(-1);e.set(this.eh);this.eh=e;
    this.cap=nc;
  }
  addQ(i,v){
    for(let p=this.qh[i];p>=0;p=this.qn[p]) if(this.qv[p]===v) return;
    if(this.qc===this.qv.length){const nl=this.qv.length*2,a=new Uint16Array(nl);a.set(this.qv);this.qv=a;const b=new Int32Array(nl);b.set(this.qn);this.qn=b;}
    this.qv[this.qc]=v;this.qn[this.qc]=this.qh[i];this.qh[i]=this.qc++;
  }
  qsOf(i,out){out.length=0;for(let p=this.qh[i];p>=0;p=this.qn[p]) out.push(this.qv[p]);return out;}
  // the same predecessor is always added in one go (all placements of one board are processed together), so checking the newest edge is enough to avoid duplicates
  addEdge(i,from){
    const h=this.eh[i];if(h>=0&&this.ef[h]===from) return;
    if(this.ec===this.ef.length){const nl=this.ef.length*2,a=new Int32Array(nl);a.set(this.ef);this.ef=a;const b=new Int32Array(nl);b.set(this.en);this.en=b;}
    this.ef[this.ec]=from;this.en[this.ec]=h;this.eh[i]=this.ec++;
  }
  releaseEdges(){this.ef=this.en=this.eh=null;this.ec=0;}
  releaseQueues(){this.qv=this.qn=this.qh=null;this.qc=0;}
}
// Boards that can never be filled, judged on the hv rows that are still part of the picture (all pieces must stay inside them):
//  - a column whose empty cells are all boxed in horizontally can only take vertical I pieces: its empty count must be a multiple of 4
//  - if every row has a filled cell in one of two neighbouring columns, no piece can cross between them (a row only disappears once it
//    is full): the empty cells on each side must be a multiple of 4 on their own
function illegalBoard(r,B,hv){
  const rb=B-hv;let anyNB=0,anyE=0,both=1023;
  // exactly 4 empty cells left = the last piece: they must form one connected group (a tetromino); lines cleared before can't matter, the piece lands on this very board
  {let ne=0;for(let y=rb;y<B;y++) ne+=10-POP[r[y]];
   if(ne===4){
     let sy=-1,sx=0;
     for(let y=rb;y<B&&sy<0;y++){const e=~r[y]&1023;if(e){sy=y;sx=31-Math.clz32(e&-e);}}
     const seen=new Set([sy*10+sx]),st=[sy*10+sx];
     while(st.length){
       const v=st.pop(),y=(v/10)|0,x=v%10;
       for(let d=0;d<4;d++){
         const ny=y+(d===0?-1:d===1?1:0),nx=x+(d===2?-1:d===3?1:0);
         if(ny<rb||ny>=B||nx<0||nx>9||((r[ny]>>nx)&1)) continue;
         const k=ny*10+nx;if(!seen.has(k)){seen.add(k);st.push(k);}
       }
     }
     if(seen.size!==4) return true;
   }}
  for(let y=rb;y<B;y++){
    const v=r[y],lf=((v<<1)|1)&1023,rf=((v>>1)|512)&1023,e=~v&1023;
    anyE|=e;anyNB|=e&~(lf&rf);both&=(v|(v>>1));
  }
  const iso=anyE&~anyNB;
  if(iso) for(let c=0;c<10;c++) if((iso>>c)&1){let cnt=0;for(let y=rb;y<B;y++) cnt+=((r[y]>>c)&1)^1;if(cnt&3) return true;}
  both&=511;
  if(both) for(let c=0;c<9;c++) if((both>>c)&1){let cnt=0;const m=(2<<c)-1;for(let y=rb;y<B;y++) cnt+=c+1-POP[r[y]&m];if(cnt&3) return true;}
  return false;
}
// every lock placement of piece `shape` on `rows` -> board after the line clears
const PLP=[];
const NRB=new Array(MAXB+8).fill(0),RESB=new Array(MAXB+8).fill(0);   // scratch rows (the scan only needs the key, so it never allocates a board)
function placementsOf(rows,shape,ctx,keyOf,cBase,Lh,full){
  const B=ctx.B,nids=placementIds(rows,TYPES[shape],ctx.u180,B,ctx.spin),ids=ID_OUT,out=[];   // ids are already distinct
  for(let ii=0;ii<nids;ii++){
    const sig=ID_SG[ii],tl=ID_TL[ii],top=(tl/10)|0,left=tl-top*10;
    const d=sig&127,c=(sig>>7)&127,b=(sig>>14)&127,a=sig>>21;
    const nr=NRB;for(let i=0;i<B;i++) nr[i]=rows[i];
    const y0=top+((a/10)|0),x0=left+a%10,y1=top+((b/10)|0),x1=left+b%10,y2=top+((c/10)|0),x2=left+c%10,y3=top+((d/10)|0),x3=left+d%10;
    nr[y0]|=1<<x0;nr[y1]|=1<<x1;nr[y2]|=1<<x2;nr[y3]|=1<<x3;
    // clear full rows (clr: bit k = the row k rows above the floor of the board before the clear)
    const res=full?new Array(B).fill(0):RESB;let w=B-1,clr=0,cnt=0;
    for(let y=B-1;y>=0;y--){const v=nr[y];if(v===1023){clr|=1<<(B-1-y);cnt++;}else res[w--]=v;}
    for(let i=w;i>=0;i--) res[i]=0;
    let ti=0;while(ti<B&&res[ti]===0) ti++;
    if((B-ti)+cBase+cnt>Lh) continue;            // the picture only has Lh rows: nothing may stick out above them
    if(illegalBoard(res,B,Lh-cBase-cnt)) continue;
    const key=keyOf(res);
    if(full){out.push({nrows:res,key,k2:K2,k3:K3,cnt,cy:[y0,y1,y2,y3],cx:[x0,x1,x2,x3],clr});}
    else{const o=PLP[out.length]||(PLP[out.length]={nrows:RESB,key:0,k2:0,k3:0,cnt:0});o.key=key;o.k2=K2;o.k3=K3;o.cnt=cnt;out.push(o);}   // scan: the caller uses the entry right away, so the objects are reused
  }
  return out;
}
const picRow=(cm,k)=>{let z=-1;for(let p=0;;p++){if(!((cm>>p)&1)){z++;if(z===k) return p;}}};
const isEmptyRows=r=>{for(let i=0;i<r.length;i++) if(r[i]) return false;return true;};
// bag description of the first m pieces: one bag per top-level item that can only produce the pieces it lists (a superset is fine, the
// queues are checked exactly afterwards)
function bagSpecs(items,m){
  const specs=[];let pos=0;
  for(const it of items){
    if(pos>=m) break;
    const opts=nodeOptions(it),len=opts[0].q.length,cnt={};
    for(const o of opts){const c={};for(const ch of o.q) c[ch]=(c[ch]||0)+1;for(const ch in c) cnt[ch]=Math.max(cnt[ch]||0,c[ch]);}
    let letters='';for(const t of TYPES) letters+=t.repeat(cnt[t]||0);
    const r=Math.min(len,m-pos);
    if(letters.length>MAX_BAG){
      // does not fit one bag (e.g. [[IOTSZJL] [IOTSZJL]]2): one single-draw bag per queue position holding every piece that can show up there.
      // Only the scan gets looser; every queue is still checked exactly afterwards, so the answer is the same.
      for(let p=0;p<r;p++){
        const seen=new Set();for(const o of opts) seen.add(o.q[p]);
        let sp='';for(const t of TYPES) if(seen.has(t)) sp+=t;
        specs.push({s:sp,n:1});
      }
    } else specs.push({s:letters,n:r});
    pos+=r;
  }
  return specs;
}
// scan + cull + place: every distinct set of pieces that perfect-clears the board
// Parallel split: every stage-m board belongs to exactly one of K parts (well-mixed hash of its key). A part drops the stage-m boards it does not own,
// so the unchanged scan / cull / place afterwards only finds the solutions that pass through its own boards: the parts' solutions partition the full set.
function partOf(k1,k2,k3,K){
  let h=Math.imul((k1|0)^Math.imul(k2|0,40503)^Math.imul(k3|0,9973),-1640531535);
  h^=h>>>15;h=Math.imul(h,-2048144777);h^=h>>>13;h=Math.imul(h,-1028477379);h^=h>>>16;
  return (h>>>0)%K;
}
function* solve3(o,ctx,Lh,specs,n,placeLast,useHold){
  const H=ctx.B-BUF,keyOf=boardKeyFn(H),bags=specs.map(s=>new BagM(s.s,s.n));
  const init=new Set();{const q0=bags[0].full;for(let s=0;s<7;s++){if(o.firsts&&!o.firsts.includes(TYPES[s])) continue;const t=qSwap(q0,bags[0],s);if(t>=0) init.add(t);}}
  const stages=[];let first=true;
  bags.forEach(bag=>{for(let i=0;i<bag.count;i++){if(first){first=false;continue;}stages.push({bag,isFirst:i===0,cache:new Map()});}});
  const total=stages.length+(placeLast?1:0);
  o.qinfo={stages,init,useHold};
  if(o.preTs) return o.preTs;   // second phase of a parallel run: the merged solutions of the parts, no search
  const tick=()=>((++o.nodes)&255)===0;
  // ---- 1. scan
  o.ph='scan';o.sn=total;o.tp[0]=performance.now();
  const B=ctx.B,S=[],qsBuf=[],rowsBuf=new Array(B).fill(0);
  let prev=new Stage(H);
  {const a0=keyOf(ctx.rows0),i0=prev.findOrAdd(a0,K2,K3,0);for(const q of init) prev.addQ(i0,q);}
  S.push(prev);
  for(let si=0;si<total;si++){
    o.si=si+1;
    const next=new Stage(H),last=si>=stages.length;
    for(let ni=0;ni<prev.n;ni++){
      prev.qsOf(ni,qsBuf);
      unpackRows(prev.k1[ni],prev.h2?prev.k2[ni]:0,prev.h3?prev.k3[ni]:0,H,rowsBuf);
      const cb=prev.cnt[ni];
      let shapes;
      if(last){shapes=new Set();for(const q of qsBuf) if((q>>13)<7) shapes.add(q>>13);}
      else shapes=[0,1,2,3,4,5,6];
      for(const sh of shapes){
        let nq=null;
        if(!last){nq=bagTake(qsBuf,stages[si].bag,sh,stages[si].isFirst,useHold,stages[si].cache);if(!nq.size) continue;}
        for(const pl of placementsOf(rowsBuf,sh,ctx,keyOf,cb,Lh,false)){
          if(o.part&&si+1===o.part.m&&partOf(pl.key,pl.k2,pl.k3,o.part.K)!==o.part.j) continue;
          const t=next.findOrAdd(pl.key,pl.k2,pl.k3,cb+pl.cnt);
          if(nq) for(const q of nq) next.addQ(t,q);
          next.addEdge(t,ni);
        }
        if(tick()) yield;
      }
    }
    prev=next;S.push(prev);o.boards=prev.n;
    if(!prev.n) return [];
  }
  // ---- 2. cull
  o.ph='cull';o.tp[1]=performance.now();
  for(let i=0;i<prev.n;i++) if(prev.k1[i]===0&&(!prev.h2||prev.k2[i]===0)&&(!prev.h3||prev.k3[i]===0)) prev.alive[i]=1;   // the empty board
  for(let i=S.length-1;i>=1;i--){
    const st=S[i],ps=S[i-1];
    for(let ni=0;ni<st.n;ni++) if(st.alive[ni]) for(let e=st.eh[ni];e>=0;e=st.en[e]) ps.alive[st.ef[e]]=1;
    st.releaseEdges();st.releaseQueues();
    yield;
  }
  S[0].releaseEdges();S[0].releaseQueues();
  // ---- 3. place
  o.ph='place';o.tp[2]=performance.now();
  const rootB={rows:ctx.rows0.slice(),cm:0,pcs:[],codes:[],qs:init,c:0,id:0};o.dagRoot=rootB;o.nid=0;
  let prevP=new Map([['',rootB]]);
  for(let si=0;si<total;si++){
    o.si=si+1;
    const next=new Map(),last=si>=stages.length,tgt=S[si+1];
    for(const bb of prevP.values()){
      let shapes;
      if(last){shapes=new Set();for(const q of bb.qs) if((q>>13)<7) shapes.add(q>>13);}
      else shapes=[0,1,2,3,4,5,6];
      for(const sh of shapes){
        let nq=null;
        if(!last){nq=bagTake(bb.qs,stages[si].bag,sh,stages[si].isFirst,useHold,stages[si].cache);if(!nq.size) continue;}
        for(const pl of placementsOf(bb.rows,sh,ctx,keyOf,bb.c,Lh,true)){
          const ti=tgt.find(pl.key,pl.k2,pl.k3);
          if(ti<0||!tgt.alive[ti]) continue;
          // the piece in the unrolled picture (rows from the floor, skipping the rows cleared before it)
          const cells=[];let code=[];
          for(let i=0;i<4;i++){const pr=picRow(bb.cm,ctx.B-1-pl.cy[i]);cells.push([pl.cx[i],pr]);code.push(pr*10+pl.cx[i]);}
          code.sort((a,b)=>a-b);
          const pc=sh*1e9+((code[0]*160+code[1])*160+code[2])*160+code[3];
          let cm=bb.cm;for(let k=0;k<ctx.B;k++) if((pl.clr>>k)&1) cm|=1<<picRow(bb.cm,k);
          const codes=bb.codes.concat([pc]).sort((a,b)=>a-b),key=codes.join(',');
          let nb=next.get(key);
          if(!nb){
            nb={rows:pl.nrows,cm,pcs:bb.pcs.concat([{t:sh,cells}]),codes,qs:new Set(),c:bb.c+pl.cnt,id:++o.nid};next.set(key,nb);
          }
          if(nq) for(const q of nq) nb.qs.add(q);
          if(o.seeN!=null){
            const ed=bb.ed||(bb.ed=[]);
            // back-to-back: this placement keeps it if it clears no line, 4 lines, is a spin, or is the final (perfect clear) piece
            let ok=true;
            if(o.b2b) ok=si===total-1||pl.cnt===0||pl.cnt===4||!!(ctx.spin&&spinOK(bb.rows,TYPES[sh],pl.cx.map((x,i)=>[x,pl.cy[i]]),ctx.u180,ctx.B));
            const ex=ed.find(x=>x.sh===sh&&x.nb===nb);
            if(ex){if(ok) ex.ok=true;}else ed.push({sh,nb,pc,ok});
          }
        }
        if(tick()) yield;
      }
    }
    prevP=next;o.boards=prevP.size;
  }
  const sols=[];
  for(const bb of prevP.values()) if(isEmptyRows(bb.rows)) sols.push(bb);
  return sols;
}
// key of a setup = the rows of the picture, exact (10 bits per row) up to 5 rows; a 6-row picture (60 bits) doesn't fit a double, so it is hashed to 53 bits
function sfKeyOf(rows,a,b){
  if(b-a<=5){let k=0;for(let r=a;r<b;r++) k=k*1024+rows[r];return k;}
  let h1=0x9E3779B9|0,h2=0x85EBCA6B|0;
  for(let r=a;r<b;r++){const v=rows[r];h1=Math.imul(h1^v,0x85EBCA6B);h1^=h1>>>13;h1=Math.imul(h1,0xC2B2AE35);h2=Math.imul(h2+v+0x7F4A7C15|0,0x27D4EB2F);h2^=h2>>>15;h2=Math.imul(h2,0x165667B1);}
  return ((h1>>>0)&0x1FFFFF)*4294967296+(h2>>>0);
}
// piece filter applied while searching: the setup must use every piece in `inc` and none of `exc` (bit i = 'IOTSZJL'[i]); the ranking then covers ALL matching setups, not only the top candidates
function sfPicOk(types,inc,exc){let m=0;for(const t of types) m|=1<<'IOTSZJL'.indexOf(t);return (m&inc)===inc&&(m&exc)===0;}
// setup finder, conditional chance: for each wanted setup (key), the weight of the queues whose first pieces CAN build it (any play order, hold, spins),
// whether or not a PC follows. P(PC | the setup is built) = (queues that reach a PC through it) / (queues that can build it).
function sfDen(P,N,holdFilled,seqs0,wanted,limitMs){
  const H=P.H,B=H+BUF,Lh=Math.min(H,MAXL),useHold=P.useHold;
  const ctx={rows0:P.rows0,B,spin:P.spin!==false,u180:P.u180,tio:false,pk:new Map()};
  const Np=Math.min(N+1,seqs0.len),seqs=seqs0.truncate(Np);
  const t0=performance.now(),den=new Map(),cache=new Map(),qb=new Uint8Array(Math.max(Np,1)),zero=()=>0;
  let tot=0,over=false;
  const reach=q=>{
    const out=new Set(),seen=new Set();
    const go=(rows,cb,qi,hd,placed)=>{
      if(over) return;
      if(placed===N){const key=sfKeyOf(rows,B-Lh,B);if(wanted.has(key)) out.add(key);return;}
      const sk=rows.join(',')+'|'+cb+'|'+qi+'|'+hd;if(seen.has(sk)) return;seen.add(sk);
      if((seen.size&1023)===0&&performance.now()-t0>limitMs){over=true;return;}
      const place=(p,qi2,hd2)=>{for(const pl of placementsOf(rows,p,ctx,zero,cb,Lh,true)) go(pl.nrows,cb+pl.cnt,qi2,hd2,placed+1);};
      if(qi<Np) place(q[qi],qi+1,hd);
      if(useHold&&qi<Np){
        if(hd>=0) place(hd,qi+1,q[qi]);
        else if(qi+1<Np) place(q[qi+1],qi+2,q[qi]);
      }
    };
    if(holdFilled&&useHold) go(P.rows0,0,1,q[0],0); else go(P.rows0,0,0,-1,0);
    return [...out];
  };
  for(let k=0;k<seqs.n;k++){
    const qw=seqs.fill(k,qb);tot+=qw;
    let ps='';for(let i=0;i<Np;i++) ps+=qb[i];
    let ks=cache.get(ps);
    if(ks===undefined){ks=reach(qb);if(over) return null;cache.set(ps,ks);}
    for(const key of ks) den.set(key,(den.get(key)||0)+qw);
  }
  return {den,tot};
}
// setup finder: every set of pieces (bitmask) that can stand on the board after the first N placements of a playable order P of solution T
function setupMasks(T,ctx,P,N){
  const n=T.p.length,res=new Set(),memo=new Map();
  const dfs=(k,S)=>{
    if(k===n) return true;
    const key=S*16+k,mv=memo.get(key);if(mv!==undefined) return mv;
    const m=reachMask(T,S,ctx);let ok=false;
    for(let i=0;i<n;i++){
      if(((S>>i)&1)||!((m>>i)&1)||T.p[i].t!==P[k]) continue;
      if(dfs(k+1,S|(1<<i))) ok=true;
    }
    if(ok&&k===N) res.add(S);
    memo.set(key,ok);return ok;
  };
  dfs(0,0);return res;
}
// every order (as a string of piece types) in which the pieces of a solution can be placed, spins / tucks included, and that the bags /
// hold of the queue can deliver (same queue states as the scan, so unreachable orders are never built)
function orderSet(T,ctx,qi,safe){
  const n=T.p.length,{stages,init,useHold}=qi;
  let layer=new Map();
  for(const q of init) layer.set(q,new Set(['']));
  for(let step=0;step<n;step++){
    const nx=new Map(),last=step>=stages.length,rmc=new Map();
    for(const [key,strs] of layer){
      const S=Math.floor(key/65536),q=key%65536;
      let m=rmc.get(S);if(m===undefined){m=safe?b2bMask(T,S,ctx):reachMask(T,S,ctx);rmc.set(S,m);}
      for(let i=0;i<n;i++){
        if(!((m>>i)&1)||((S>>i)&1)) continue;
        const t=T.p[i].t,sh=TIDX[t];
        let nqs;
        if(last){if((q>>13)!==sh) continue;nqs=[0];}     // the last piece is the one in the hold slot
        else nqs=bagTake(new Set([q]),stages[step].bag,sh,stages[step].isFirst,useHold,stages[step].cache);
        for(const nq of nqs){
          const k2=(S|(1<<i))*65536+nq;let tg=nx.get(k2);if(!tg) nx.set(k2,tg=new Set());
          for(const x of strs) tg.add(x+t);
        }
      }
    }
    layer=nx;
  }
  const out=new Set();
  for(const strs of layer.values()) for(const x of strs) out.add(x);
  return out;
}
