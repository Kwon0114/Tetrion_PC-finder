// Fewest solutions that still cover every queue group (a group = the solutions one set of queues can use; a solution covers it when it is in the set).
// Exact minimum hitting set. Steps: (1) reduce the instance until nothing changes: a group with one solution forces it, a solution whose groups are all
// covered by another solution is dropped, a group that contains another group is dropped; (2) split into independent components (groups sharing no solution)
// and solve each alone; (3) per component: iterative deepening on the size k (greedy answer = upper bound, k = 1,2,.. until a hit set of size k exists,
// so the first success is the proven minimum) with branching on the unhit group with fewest candidates, earlier siblings banned in later branches,
// and a lower bound from pairwise disjoint unhit groups (smallest first). After limitMs it stops and keeps the best found (exact=false).
// Picks come back in greedy order (most queue weight first, ties: more spins).
function* minCoverG(gl0,spOf,limitMs){
  const gl=gl0.filter(g=>g[0].length),total=gl0.reduce((a,g)=>a+g[1],0),ng=gl.length;
  if(!ng) return {picks:[],exact:true,total,covered:0,lb:0};
  const sg=new Map();gl.forEach((g,gi)=>{for(const s of g[0]){let a=sg.get(s);if(!a) sg.set(s,a=[]);a.push(gi);}});
  // greedy cover. Same choices as re-summing every solution's gain each round, but the gains are kept up to date instead: a group that gets
  // covered is subtracted once from its solutions (cnt = integer number of uncovered groups, so a solution with none left is never picked);
  // the gain that is reported for a pick is summed fresh, exactly as before.
  const greedy=allowed=>{
    const left=new Uint8Array(ng).fill(1);let rem=ng,covered=0;const picks=[];
    const ss=[],arrs=[],pos=new Map();
    for(const [s,arr] of sg){if(allowed&&!allowed.has(s)) continue;pos.set(s,ss.length);ss.push(s);arrs.push(arr);}
    const n=ss.length,gain=new Float64Array(n),cnt=new Int32Array(n);
    for(let p=0;p<n;p++){const arr=arrs[p];let w=0;for(let i=0;i<arr.length;i++) w+=gl[arr[i]][1];gain[p]=w;cnt[p]=arr.length;}
    const gpos=new Array(ng);
    while(rem>0){
      let bp=-1,bw=0;
      for(let p=0;p<n;p++){
        if(!cnt[p]) continue;
        const w=gain[p];
        if(w>bw+1e-12||(w>0&&Math.abs(w-bw)<=1e-12&&spOf(ss[p])>spOf(bp<0?null:ss[bp]))){bw=w;bp=p;}
      }
      if(bp<0) break;
      const best=ss[bp],arr=arrs[bp];
      let fw=0;for(let i=0;i<arr.length;i++) if(left[arr[i]]) fw+=gl[arr[i]][1];
      picks.push({idx:best,gain:fw});covered+=fw;
      for(const gi of arr) if(left[gi]){
        left[gi]=0;rem--;
        let gp=gpos[gi];
        if(!gp){gp=[];for(const s of gl[gi][0]){const q=pos.get(s);if(q!==undefined) gp.push(q);}gpos[gi]=gp;}
        const wg=gl[gi][1];
        for(let j=0;j<gp.length;j++){gain[gp[j]]-=wg;cnt[gp[j]]--;}
      }
    }
    return {picks,covered};
  };
  const g0=greedy(null);
  let best=g0.picks.map(p=>p.idx),exact=true,prog_lb=0;
  if(best.length>1){
    const approxMs=isFinite(limitMs)?Math.min(600,limitMs*0.15):0,t0=performance.now(),late=()=>performance.now()-t0>limitMs-approxMs;   // the last slice of the budget is kept for the approximation below
    // ---- compact ids + mutable group/solution sets
    const ev=[],eid=new Map();
    const gs=gl.map(g=>{const st=new Set();for(const x of g[0]){let i=eid.get(x);if(i===undefined){i=ev.length;eid.set(x,i);ev.push(x);}st.add(i);}return st;});
    const NG=ng,NE=ev.length,eg=Array.from({length:NE},()=>new Set());
    gs.forEach((st,gi)=>{for(const x of st) eg[x].add(gi);});
    const gOn=new Uint8Array(NG).fill(1),forced=[],sp=x=>spOf(ev[x]);
    const killG=gi=>{gOn[gi]=0;for(const x of gs[gi]) eg[x].delete(gi);};
    // ---- 1. reduce to a fixpoint (each rule keeps a minimum hit set of the same size)
    const stampG=new Int32Array(NG);let sgn=0,ops=0;const OPS=8e6;
    for(let round=0;round<30&&!late()&&ops<OPS;round++){
      let changed=false;
      // forced: a group with a single solution
      for(let gi=0;gi<NG;gi++) if(gOn[gi]&&gs[gi].size===1){
        const x=gs[gi].values().next().value;forced.push(x);changed=true;
        for(const hg of [...eg[x]]) killG(hg);
      }
      // solution dominance: drop x when another solution y is in every group x is in
      for(let x=0;x<NE&&ops<OPS;x++){
        const ex=eg[x];if(!ex.size) continue;
        let g1=-1,m=1e9;for(const gi of ex) if(gs[gi].size<m){m=gs[gi].size;g1=gi;}
        for(const y of gs[g1]){
          if(y===x) continue;ops+=ex.size;
          const ey=eg[y];if(ey.size<ex.size) continue;
          let ok=true;for(const gi of ex) if(!ey.has(gi)){ok=false;break;}
          if(!ok) continue;
          if(ey.size>ex.size||sp(y)>sp(x)||(sp(y)===sp(x)&&y<x)){for(const gi of [...ex]) gs[gi].delete(x);ex.clear();changed=true;break;}
        }
      }
      // group dominance: drop a group that contains another group
      const order=[];for(let gi=0;gi<NG;gi++) if(gOn[gi]) order.push(gi);
      order.sort((a,b)=>gs[a].size-gs[b].size);
      for(const gi of order){
        if(!gOn[gi]||ops>=OPS) continue;
        const g=gs[gi];sgn++;let dom=false;
        for(const x of g){
          for(const h of eg[x]){
            ops++;
            if(h===gi||!gOn[h]||stampG[h]===sgn) continue;stampG[h]=sgn;
            const hs=gs[h];if(hs.size>g.size||(hs.size===g.size&&h>gi)) continue;
            let sub=true;for(const y of hs) if(!g.has(y)){sub=false;break;}
            if(sub){dom=true;break;}
          }
          if(dom) break;
        }
        if(dom){killG(gi);changed=true;}
      }
      if(!changed) break;
    }
    // ---- 2. independent components
    const par=new Int32Array(NG);for(let i=0;i<NG;i++) par[i]=i;
    const find=a=>{while(par[a]!==a){par[a]=par[par[a]];a=par[a];}return a;};
    for(let x=0;x<NE;x++){let f=-1;for(const gi of eg[x]){if(f<0) f=gi;else par[find(gi)]=find(f);}}
    const cm=new Map();for(let gi=0;gi<NG;gi++) if(gOn[gi]){const r=find(gi);let a=cm.get(r);if(!a) cm.set(r,a=[]);a.push(gi);}
    const comp=[...cm.values()].sort((a,b)=>a.length-b.length).map(gis=>{
      const eIds=[],lid=new Map();
      const ga=gis.map(gi=>{const a=[];for(const x of gs[gi]){let l=lid.get(x);if(l===undefined){l=eIds.length;lid.set(x,l);eIds.push(x);}a.push(l);}return a;});
      const ea=eIds.map(()=>[]);ga.forEach((a,i)=>a.forEach(l=>ea[l].push(i)));
      // greedy upper bound (most groups first, ties: more spins)
      const gu=new Uint8Array(ga.length),cu=new Int32Array(ea.length);let rem=ga.length;const ub=[];
      for(let l=0;l<ea.length;l++) cu[l]=ea[l].length;
      while(rem>0){
        let bx=-1,bc=0;
        for(let l=0;l<ea.length;l++){const c=cu[l];if(c>bc||(c>0&&c===bc&&sp(eIds[l])>sp(eIds[bx]))){bc=c;bx=l;}}
        ub.push(bx);for(const i of ea[bx]) if(!gu[i]){gu[i]=1;rem--;const a=ga[i];for(let j=0;j<a.length;j++) cu[a[j]]--;}
      }
      return {ga,ea,eIds,ub,lb:1,res:ub};
    });
    const forcedV=forced.map(x=>ev[x]);
    const prog={nodes:0,best:0,lb:0,rb:0,rn:0,ids:[]};
    const sync=()=>{const ids=forcedV.slice();let l=forced.length;for(const c of comp){for(const bx of c.res) ids.push(ev[c.eIds[bx]]);l+=c.lb;}prog.ids=ids;prog.best=ids.length;prog.lb=l;};
    sync();yield prog;
    // ---- 3. exact search per component: iterative deepening on k
    let nodes=0,timeout=false;
    for(const c of comp){
      if(timeout) break;
      if(c.ub.length<=1){c.lb=c.ub.length;continue;}
      const {ga,ea}=c,n=ga.length,ne=ea.length;
      // incremental state: hit[g] = chosen solutions in g, fc[g] = free (not banned) solutions in g, cov[x] = unhit groups x would hit,
      // act[0..asz) = unhit groups (sparse set, restored in LIFO order on backtrack)
      const hit=new Uint16Array(n),banned=new Uint8Array(ne),used=new Int32Array(ne),chosen=[];let stp=0;
      const fc=new Int32Array(n),cov=new Int32Array(ne),act=new Int32Array(n),pos=new Int32Array(n);let asz=n;
      let maxc=1;for(let l=0;l<ne;l++) if(ea[l].length>maxc) maxc=ea[l].length;
      const hist=new Int32Array(maxc+2),pk=new Float64Array(n);
      const reset=()=>{hit.fill(0);banned.fill(0);chosen.length=0;asz=n;for(let i=0;i<n;i++){fc[i]=ga[i].length;act[i]=i;pos[i]=i;}for(let l=0;l<ne;l++) cov[l]=ea[l].length;};
      const apply=x=>{chosen.push(x);const a=ea[x];for(let j=0;j<a.length;j++){const gi=a[j];if(hit[gi]++===0){
        const p=pos[gi],lst=asz-1,o=act[lst];act[p]=o;pos[o]=p;act[lst]=gi;pos[gi]=lst;asz=lst;
        const s=ga[gi];for(let q=0;q<s.length;q++) cov[s[q]]--;}}};
      const unapply=()=>{const x=chosen.pop(),a=ea[x];for(let j=a.length-1;j>=0;j--){const gi=a[j];if(--hit[gi]===0){
        asz++;const s=ga[gi];for(let q=0;q<s.length;q++) cov[s[q]]++;}}};
      const ban=x=>{banned[x]=1;const a=ea[x];for(let j=0;j<a.length;j++) fc[a[j]]--;};
      const unban=x=>{banned[x]=0;const a=ea[x];for(let j=0;j<a.length;j++) fc[a[j]]++;};
      const dfs=function*(k,top){
        if(timeout) return false;
        if((++nodes&511)===0){if(late()){timeout=true;return false;}prog.nodes=nodes;yield prog;}
        const base=chosen.length;let fail=false,pg=-1;
        // unit propagation: an unhit group with one free solution forces it; a group with none fails
        for(;;){
          let pl=1e9,fx=-1;pg=-1;
          for(let i=0;i<asz;i++){
            const gi=act[i],f=fc[gi];
            if(f===0){fail=true;break;}
            if(f===1){const es=ga[gi];for(let j=0;j<es.length;j++) if(!banned[es[j]]){fx=es[j];break;}break;}
            if(f<pl){pl=f;pg=gi;}
          }
          if(fail||fx<0) break;
          apply(fx);
          if(chosen.length>k){fail=true;break;}
        }
        if(!fail&&asz===0) return true;
        if(!fail){
          const r=k-chosen.length;
          if(r<=0) fail=true;
          else{
            // bound A: the r best solutions must be able to hit all unhit groups (sum of the r largest cov among free solutions)
            let mc=0;
            for(let x=0;x<ne;x++){if(banned[x]) continue;const c=cov[x];if(c>0){hist[c]++;if(c>mc) mc=c;}}
            let need=asz,rr=r;
            for(let c=mc;c>=1;c--){const h=hist[c];if(h){if(rr>0){const t=h<rr?h:rr;need-=t*c;rr-=t;}hist[c]=0;}}
            if(need>0) fail=true;
            else{
              // bound B: pairwise disjoint unhit groups (smallest first) each need their own solution
              let m=0;for(let i=0;i<asz;i++){const gi=act[i];pk[m++]=fc[gi]*1048576+gi;}
              const sub=pk.subarray(0,m).sort();
              const sT=++stp;let packs=0;
              for(let i=0;i<m;i++){
                const gi=sub[i]%1048576,es=ga[gi];let free=true;
                for(let j=0;j<es.length;j++){const x=es[j];if(!banned[x]&&used[x]===sT){free=false;break;}}
                if(free){packs++;if(packs>r){fail=true;break;}for(let j=0;j<es.length;j++) if(!banned[es[j]]) used[es[j]]=sT;}
              }
            }
          }
        }
        if(fail){while(chosen.length>base) unapply();return false;}
        const cands=[];for(const x of ga[pg]) if(!banned[x]) cands.push(x);
        cands.sort((p,q)=>cov[q]-cov[p]);
        const bannedHere=[];let bi=0,found=false;
        for(const x of cands){
          if(top){prog.rb=++bi;prog.rn=cands.length;}
          apply(x);
          if(yield* dfs(k,false)){found=true;break;}
          unapply();
          if(timeout) break;
          ban(x);bannedHere.push(x);
        }
        for(const x of bannedHere) unban(x);
        if(found) return true;
        while(chosen.length>base) unapply();
        return false;
      };
      for(let k=Math.max(1,c.lb);k<c.ub.length;k++){
        reset();
        const ok=yield* dfs(k,true);
        if(timeout) break;
        if(ok){c.res=chosen.slice();c.lb=k;sync();yield prog;break;}
        c.lb=k+1;sync();yield prog;
      }
      prog.rb=0;prog.rn=0;
      if(timeout) exact=false;else c.lb=c.res.length;
      sync();
    }
    // ---- 4. only when the exact search ran out of time: improve the components that are not proven yet with randomized greedy + redundancy removal + 2-for-1 swaps
    //         (the result is then not proven minimal, unless it meets the proven lower bound)
    if(timeout&&approxMs>0){
      const until=performance.now()+approxMs;let rs=12345;const rnd=()=>(rs=(Math.imul(rs,1664525)+1013904223)>>>0)/4294967296;
      for(const c of comp){
        if(c.res.length<=c.lb) continue;
        const {ga,ea,eIds}=c,n=ga.length,ne=ea.length,spS=r=>r.reduce((s,l)=>s+sp(eIds[l]),0);
        let bestR=c.res.slice(),bestS=spS(bestR);
        const grd=noise=>{
          const cnt=new Int32Array(ne),done=new Uint8Array(n);let rem=n;const out=[];
          for(let l=0;l<ne;l++) cnt[l]=ea[l].length;
          while(rem>0){let bx=-1,bv=-1;for(let l=0;l<ne;l++){if(!cnt[l]) continue;const v=cnt[l]+rnd()*noise;if(v>bv){bv=v;bx=l;}}
            out.push(bx);for(const i of ea[bx]) if(!done[i]){done[i]=1;rem--;const q=ga[i];for(let j=0;j<q.length;j++) cnt[q[j]]--;}}
          return out;
        };
        const prune=out=>{
          const cc=new Int32Array(n);for(const l of out) for(const i of ea[l]) cc[i]++;
          for(let t=out.length-1;t>=0;t--){const l=out[t];if(ea[l].every(i=>cc[i]>1)){for(const i of ea[l]) cc[i]--;out.splice(t,1);}}
          return out;
        };
        const swap=out=>{
          let cur=out,imp=true;
          while(imp&&performance.now()<until){
            imp=false;const cc=new Int32Array(n);for(const l of cur) for(const i of ea[l]) cc[i]++;
            const inCur=new Uint8Array(ne);for(const l of cur) inCur[l]=1;
            outer:for(let i=0;i<cur.length;i++){
              if(performance.now()>=until) break;
              for(let j=i+1;j<cur.length;j++){
                const x=cur[i],y=cur[j],need=[];
                for(const g of ea[x]){let o=cc[g]-1;if(ga[g].includes(y)) o--;if(!o) need.push(g);}
                for(const g of ea[y]){if(ga[g].includes(x)) continue;if(cc[g]-1===0) need.push(g);}
                if(!need.length) continue;
                let bz=-1,bsp=-1;
                for(const z of ga[need[0]]){if(z===x||z===y||inCur[z]) continue;let ok=true;for(let q=1;q<need.length;q++) if(!ga[need[q]].includes(z)){ok=false;break;}
                  if(ok&&sp(eIds[z])>bsp){bsp=sp(eIds[z]);bz=z;}}
                if(bz>=0){cur=cur.filter(l=>l!==x&&l!==y);cur.push(bz);imp=true;break outer;}
              }
            }
          }
          return cur;
        };
        for(let it=0;performance.now()<until&&bestR.length>c.lb;it++){
          const r=swap(prune(grd(it?3:0)));
          const s=spS(r);if(r.length<bestR.length||(r.length===bestR.length&&s>bestS)){bestR=r;bestS=s;}
        }
        c.res=bestR;
      }
      exact=comp.every(c=>c.res.length<=c.lb);
      sync();
    }
    best=prog.ids;prog_lb=prog.lb;
  }
  const r=best.length===g0.picks.length&&exact?g0:greedy(new Set(best));
  return {picks:r.picks,exact,total,covered:r.covered,lb:exact?r.picks.length:Math.min(r.picks.length,best.length>1?prog_lb:best.length)};
}
// order the given solutions greedily (most queue weight first, ties: more spins) and report what they cover
function coverOrder(gl0,spOf,ids){
  const gl=gl0.filter(g=>g[0].length),total=gl0.reduce((a,g)=>a+g[1],0),al=new Set(ids),ng=gl.length,sg=new Map();
  gl.forEach((g,gi)=>{for(const x of g[0]) if(al.has(x)){let a=sg.get(x);if(!a) sg.set(x,a=[]);a.push(gi);}});
  const left=new Uint8Array(ng).fill(1),picks=[];let covered=0;
  for(;;){
    let best=null,bw=0;
    for(const [x,arr] of sg){
      let w=0;for(const gi of arr) if(left[gi]) w+=gl[gi][1];
      if(w>bw+1e-12||(w>0&&Math.abs(w-bw)<=1e-12&&spOf(x)>spOf(best))){bw=w;best=x;}
    }
    if(best===null) break;
    picks.push({idx:best,gain:bw});covered+=bw;
    for(const gi of sg.get(best)) left[gi]=0;
  }
  return {picks,total,covered};
}
function minCover(gl0,spOf,limitMs){const g=minCoverG(gl0,spOf,limitMs);let r;while(!(r=g.next()).done);return r.value;}
