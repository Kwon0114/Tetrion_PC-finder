function* search(o){
  try{yield* search0(o);}finally{o.ph='done';o.tEnd=performance.now();}
}
function* search0(o){
  o.runId=++RUNID;
  let {seqs}=o;const {rows0,useHold,u180,H}=o,spin=o.spin!==false,B=H+BUF,Lh=Math.min(H,MAXL);
  o.shapes=[];o.jsPlN=0;o.jsGrp=new Map();o.jsEv=new Map();o.jsEvC=Array.from({length:8},()=>new Map());o.solEv=new Map();o.solEvC=new Map();o.jsEvQ=new Map();o.solEvPC=new Map();o.jsEvPC=new Map();o.jsEvP=new Map();o.solEvP=new Map();o.jsSum=0;o.jsW=0;o.jsUS=0;o.jsUN=0;o.jsMax=0;o.jsMin=null;o.b2bW=0;o.b2bN=0;o.okW=0;o.okN=0;o.doneW=0;o.seqDone=0;o.ns=[];o.nodes=0;o.solN=0;o.boards=0;o.tp=[null,null,null,null,null];o.minimal=null;o.minSkipped=false;
  const filled=rows0.reduce((a,v)=>a+popc(v),0),ns=[];
  for(let n=1;n<=seqs.len;n++) if((filled+4*n)%10===0&&(filled+4*n)/10===Lh) ns.push(n);
  // no piece count fits the board: the single empty queue simply fails
  let n=1,m=0,Ts=[];
  const ctx={rows0,B,spin,u180,tio:!!(o.js&&o.js.tio),pk:new Map()};
  if(ns.length){
    n=ns[0];m=Math.min(useHold?n+1:n,seqs.len);
    seqs=seqs.truncate(m);o.seqsN=seqs.n;o.seeN=(o.see!=null&&o.see+1<m)?o.see:null;o.skipFirsts=(o.seeN==null&&o.seeFirsts)?o.seeFirsts:null;
    if(seqs.n>MAX_CASES){o.err='TOO_MANY';o.errN=seqs.n;return;}
    let specs;
    try{specs=bagSpecs(o.items,m);}catch(e){o.err='TOO_MANY';o.errN=Infinity;return;}
    o.curN=n;
    // ---- scan / cull / place
    const sols=yield* solve3(o,ctx,Lh,specs,n,m===n,useHold);
    if(!sols) return;
    if(o.solveOnly){o.solved=sols.map(bb=>({k:bb.codes.join(','),pcs:bb.pcs}));o.tp[3]=performance.now();return;}   // parallel part: hand the solutions back
    Ts=sols.map(bb=>({p:bb.pcs.map(p=>({t:TYPES[p.t],cells:p.cells.map(([x,pr])=>[x,H-1-pr])})),bb:o.seeN!=null?bb:null,st:new Map(),rm:new Map(),sm:new Map()}));
  } else {seqs=seqs.truncate(0);o.seqsN=seqs.n;}
  o.solN=Ts.length;
  if(o.seeN!=null&&Ts.length&&o.dagRoot){
    yield* seeFinish(o,ctx,Ts,seqs,n,m,useHold,o.seeN,H);
    // back-to-back: the same See evaluation again on the graph restricted to placements that keep back-to-back (probability only)
    if(o.b2b&&o.seeRes&&!o.err){
      const mp=new Map();
      const cl=nd=>{
        let c=mp.get(nd);if(c) return c;
        c={rows:nd.rows,cm:nd.cm,pcs:nd.pcs,codes:nd.codes,qs:nd.qs,c:nd.c,id:nd.id};mp.set(nd,c);
        if(nd.ed){const ed=[];for(const e of nd.ed) if(e.ok) ed.push({sh:e.sh,nb:cl(e.nb),pc:e.pc});c.ed=ed;}
        return c;
      };
      const o2={...o,probOnly:true,solOnly:false,seeRes:null,dagRoot:cl(o.dagRoot),err:null,shapes:[],lo:null,fail:null};
      yield* seeFinish(o2,ctx,[],seqs,n,m,useHold,o.seeN,H);
      if(o2.seeRes&&!o2.err) o.seeRes.pB=o2.seeRes.p;
    }
    return;
  }
  // ---- supporting orders of every solution
  o.ph='orders';o.tp[3]=performance.now();o.si=0;o.sn=Ts.length;
  const orderSol=new Map();
  const b2bOn=!!o.b2b&&!o.solOnly,orderSol2=b2bOn?new Map():null;   // back-to-back: orders in which every line clear keeps it
  for(let i=0;i<Ts.length;i++){
    for(const s of orderSet(Ts[i],ctx,o.qinfo)){let a=orderSol.get(s);if(!a) orderSol.set(s,a=[]);a.push(i);}
    if(b2bOn) for(const s of orderSet(Ts[i],ctx,o.qinfo,true)){let a=orderSol2.get(s);if(!a) orderSol2.set(s,a=[]);a.push(i);}
    o.si=i+1;if((i&7)===0) yield;
  }
  // trie of every playable order prefix: a state holds a trie node instead of a string, so one step is an array lookup (no string building or hashing)
  const root={s:'',id:0,d:0,ch:null,sol:null,sol2:null,in2:true};let tnN=1;
  const addP=(P,two)=>{let nd=root;for(let i=0;i<P.length;i++){const t=TIDX[P[i]];if(!nd.ch) nd.ch=[];let c=nd.ch[t];if(c===undefined) c=nd.ch[t]={s:P.slice(0,i+1),id:tnN++,d:i+1,ch:null,sol:null,sol2:null,in2:false};if(two) c.in2=true;nd=c;}return nd;};
  for(const [P,a] of orderSol) addP(P,false).sol=a;
  if(b2bOn) for(const [P,a] of orderSol2) addP(P,true).sol2=a;
  // ---- every queue: can some supporting order be played from it?
  o.ph='eval';o.tp[4]=performance.now();
  const bagsM=seqs.bags||[],wantLo=!o.probOnly&&!o.solOnly&&bagsM.length>0;
  const loFrom=(qi,h,pref)=>{   // pure remaining pieces: all bag contents minus pieces already spent (drawn from the queue and not sitting in hold)
    const cnt={};
    for(const b of bagsM){
      for(const ch of b.elems) cnt[ch]=(cnt[ch]||0)+1;
      const end=Math.min(b.off+b.len,qi);
      for(let j=b.off;j<end;j++){
        if(j===h) continue;   // still in hold → remains
        const ch=pref[j];
        if(cnt[ch]>0) cnt[ch]--;
      }
    }
    // hold index outside every bag (fixed queue letters, etc.): count it as remaining
    if(h>=0){
      let inBag=false;
      for(const b of bagsM) if(h>=b.off&&h<b.off+b.len){inBag=true;break;}
      if(!inBag){const ch=pref[h];cnt[ch]=(cnt[ch]||0)+1;}
    }
    let r='';for(const t of TYPES) r+=t.repeat(cnt[t]||0);
    return r;
  };
  // state = placement order played so far + queue index of the held piece (-1 none) (+ "must place the next piece" after holding into an empty hold)
  const stepL=(states,qi,b2)=>{
    const ci=qbuf[qi],out=[],seen=new Set();
    const addN=(nd,h,mp)=>{const k=(nd.id*64+(h+1))*2+(mp?1:0);if(seen.has(k)) return;seen.add(k);out.push({nd,h,mp});};
    const addD=(nd,h,q2)=>{const k=-1-((nd.id*64+(h+1))*64+q2);if(seen.has(k)) return;seen.add(k);out.push({done:true,qi:q2,h,nd});};
    for(const s of states){
      if(s.done){addD(s.nd,s.h,s.qi);continue;}
      const ch=s.nd.ch;
      const c=ch?ch[ci]:undefined;
      if(c!==undefined&&(!b2||c.in2)){if(c.d===n) addD(c,s.h,qi+1);else addN(c,s.h,false);}
      if(useHold&&!s.mp){
        if(s.h>=0){
          const c3=ch?ch[qbuf[s.h]]:undefined;
          if(c3!==undefined&&(!b2||c3.in2)){if(c3.d===n) addD(c3,qi,qi+1);else addN(c3,qi,false);}
        } else addN(s.nd,qi,true);
      }
    }
    return out;
  };
  const endsOf=(states,b2)=>{
    const e=[],seen=new Set();
    for(const s of states){
      if(s.done){const k=(s.nd.id*64+(s.h+1))*64+s.qi;if(!seen.has(k)){seen.add(k);e.push([s.qi,s.h,s.nd]);}}
      else if(useHold&&!s.mp&&s.h>=0){
        const c=s.nd.ch&&s.nd.ch[qbuf[s.h]];
        if(c!==undefined&&(!b2||c.in2)&&c.d===n){const k=c.id*4096+m;if(!seen.has(k)){seen.add(k);e.push([m,-1,c]);}}
      }
    }
    return e;
  };
  const wSol=new Float64Array(Ts.length),firstQ=new Array(Ts.length).fill(null);
  const wSol2=new Float64Array(Ts.length),firstQ2=new Array(Ts.length).fill(null),groups2=new Map();   // back-to-back keeping: same bookkeeping as wSol/firstQ/groups
  const groups=new Map();                       // sorted solution indices -> {es, w}: queues that the same solutions solve
  const lsets=new Map(),marg={};let loOkw=0;
  const qbuf=new Uint8Array(Math.max(m,1)),prevBuf=new Int8Array(Math.max(m,1)).fill(-1);
  const layers=new Array(m+1),prefA=new Array(m+1).fill('');layers[0]=[{nd:root,h:-1,mp:false}];
  const layers2=b2bOn?new Array(m+1):null;if(layers2) layers2[0]=[{nd:root,h:-1,mp:false}];
  const flist=[];let fn=0,fw=0;
  // queues whose playable end states use the same piece orders are solved by the same solutions and score the same, so all of that is worked out once per
  // distinct set of orders (setC / set2C) and the queue only adds its weight
  const setC=new Map(),set2C=new Map(),ordC=new Map();
  const sfN=o.setupN|0,sfReg=sfN?new Map():null;let sfCache=sfN?new Map():null;
  const sfKeys=nds=>{
    const set=new Set();
    for(const nd of nds) for(const i of nd.sol||[]){
      const ck=nd.id*1048576+i;let ks=sfCache.get(ck);
      if(ks===undefined){
        ks=[];
        for(const S of setupMasks(Ts[i],ctx,nd.s,sfN)){
          const st=tState(Ts[i],S,ctx);let cnt=0;
          for(let r=B-Lh;r<B;r++) cnt+=popc(st.rows[r]);
          const key=sfKeyOf(st.rows,B-Lh,B);
          if(!sfReg.has(key)) sfReg.set(key,{rows:st.rows.slice(B-Lh),i,S,cl:Math.round((filled+4*sfN-cnt)/10)});
          ks.push(key);
        }
        if(sfCache.size>300000) sfCache=new Map();
        sfCache.set(ck,ks);
      }
      for(const k of ks) set.add(k);
    }
    return [...set];
  };
  const ndsOf=e=>{const a=[];for(const v of e) if(a.indexOf(v[2])<0) a.push(v[2]);return a;};
  const ekey=e=>{if(e.length===1) return e[0][2].id;const a=ndsOf(e);if(a.length===1) return a[0].id;return 'm'+a.map(x=>x.id).sort((x,y)=>x-y).join(',');};
  const flist2=[];let fn2=0,fw2=0;   // queues that PC but cannot keep back-to-back
  const svSets=wantLo?new Array(Ts.length).fill(null):null;   // per solution: leftover sets (same values as the chips) over every queue that plays it
  // solutions only: no need to classify every queue, stop as soon as each solution has one queue that plays it (that queue gives its example order)
  let needLeft=0;const needSol=o.solOnly?new Set():null;
  if(needSol){for(const a of orderSol.values()) for(const i of a) needSol.add(i);needLeft=needSol.size;}
  for(let k=0;k<seqs.n;k++){
    if(needSol&&needLeft<=0) break;
    const qw=seqs.fill(k,qbuf);
    if(o.skipFirsts&&!o.skipFirsts.includes(TYPES[qbuf[0]])){if((k&255)===0) yield;continue;}
    let c=0;while(c<m&&qbuf[c]===prevBuf[c]) c++;
    for(let Lq=c;Lq<m;Lq++){
      prevBuf[Lq]=qbuf[Lq];prefA[Lq+1]=prefA[Lq]+TYPES[qbuf[Lq]];
      layers[Lq+1]=layers[Lq].length?stepL(layers[Lq],Lq,false):[];
      if(layers2) layers2[Lq+1]=layers2[Lq].length?stepL(layers2[Lq],Lq,true):[];
    }
    const pref=prefA[m],e=layers[m].length?endsOf(layers[m],false):null;
    let b2bOk=false;
    if(layers2&&layers2[m].length){
      const e2=endsOf(layers2[m],true);
      if(e2.length){
        b2bOk=true;o.b2bW+=qw;o.b2bN++;
        if(!o.probOnly&&!o.solOnly){
          const pk2=ekey(e2);let I2=set2C.get(pk2);
          if(!I2){
            const a2=new Set();
            for(const nd of ndsOf(e2)) for(const s of nd.sol2||[]) a2.add(s);
            const es=[...a2].sort((a,b)=>a-b),key=es.join(',');
            for(const s of es) if(firstQ2[s]===null) firstQ2[s]=pref;
            let g=groups2.get(key);if(!g) groups2.set(key,g={es,w:0});
            I2={es:g.es,g,w:0};set2C.set(pk2,I2);
          }
          I2.w+=qw;I2.g.w+=qw;
        }
      }
    }
    o.doneW+=qw;o.seqDone++;
    if(e&&e.length){
      o.okW+=qw;o.okN++;
      if(b2bOn&&!b2bOk){fn2++;fw2+=qw;flist2.push([pref,qw]);}
      const out=new Set(),pk=ekey(e);let I=setC.get(pk);
      if(!I){
        I={nds:ndsOf(e),es:null,g:null,w:0,js:null};
        if(!o.probOnly){
          const all=new Set();
          for(const nd of I.nds) for(const s of nd.sol||[]) all.add(s);
          let es=[...all].sort((a,b)=>a-b);
          const key=es.join(','),g0=o.solOnly?null:groups.get(key);
          if(g0) es=g0.es;
          I.es=es;
          for(const s of es) if(firstQ[s]===null){firstQ[s]=pref;if(needSol&&needSol.has(s)) needLeft--;}
          if(!o.solOnly){if(g0) I.g=g0;else{I.g={es,w:0};groups.set(key,I.g);}}
        }
        if(sfN) I.sk=sfKeys(I.nds);
        setC.set(pk,I);
      }
      I.w+=qw;
      if(wantLo) for(const [qi,h,nd] of e){const x=loFrom(qi,h,pref);out.add(x);for(const s of nd.sol||[]){(svSets[s]||(svSets[s]=new Set())).add(x);}}
      if(o.js){   // Jstris: the best score this queue can reach over every solution and playable order (worked out once per set of orders)
        let J=I.js;
        if(!J){
        let bs=-1,evm=0,bestS=-1,bestP=null;const qpm=new Set(),qpc=new Set(),cq=[0,0,0,0,0,0,0,0],pqm=new Map(),pem=new Map();
        for(const nd of I.nds){const P=nd.s;for(const s of nd.sol||[]){const v=jsBest(Ts[s],P,o.js.b2b,ctx,o.js.cb||0);if(v>=0){const pv=pqm.get(s);if(pv===undefined||v>pv) pqm.set(s,v);}if(v>bs){bs=v;bestS=s;bestP=P;}const em=jsEvents(Ts[s],P,ctx);if(em>0){evm|=em;pem.set(s,(pem.get(s)||0)|em);{const cc=jsEvCounts(Ts[s],P,ctx);if(cc){let sa=o.solEvC.get(s);if(!sa) o.solEvC.set(s,sa=new Int8Array(8));for(let k=0;k<8;k++){if(cc[k]>cq[k]) cq[k]=cc[k];if(cc[k]>sa[k]) sa[k]=cc[k];}}}o.solEv.set(s,(o.solEv.get(s)||0)|em);const pv=jsEvPlaysC(Ts[s],P,ctx);let sp=o.solEvP.get(s),sc=o.solEvPC.get(s);if(!sp) o.solEvP.set(s,sp=new Set());if(!sc) o.solEvPC.set(s,sc=new Set());for(const v of pv){const m=vecMask(v);qpm.add(m);sp.add(m);qpc.add(v);sc.add(v);}}}}
          J=I.js={bs,bestS,bestP,evm,cq,pq:bs>=0?pqk(pqm,pem):'',pm:bs>=0?maxMasks(qpm).join(','):'',pc:bs>=0?paretoVecs([...qpc]).join(','):''};
        }
        const {evm,cq,bestS,bestP}=J;let bs=J.bs;
        if(bs>=0){if(!o.jsPQ) o.jsPQ=new Map();if(o.jsPQ.size<150000||o.jsPQ.has(J.pq)){const k=J.pq;o.jsPQ.set(k,(o.jsPQ.get(k)||0)+qw);}else o.jsPQover=true;bs+=(o.js.pre||0);o.jsSum+=qw*bs;o.jsW+=qw;o.jsUS+=bs;o.jsUN++;o.jsEv.set(evm,(o.jsEv.get(evm)||0)+qw);for(let k=0;k<8;k++) if(cq[k]>0){const mp=o.jsEvC[k];mp.set(cq[k],(mp.get(cq[k])||0)+qw);}{const qk=cq.join(',');o.jsEvQ.set(qk,(o.jsEvQ.get(qk)||0)+qw);}{const pmk=J.pm;o.jsEvP.set(pmk,(o.jsEvP.get(pmk)||0)+qw);const pck=J.pc;o.jsEvPC.set(pck,(o.jsEvPC.get(pck)||0)+qw);}{const key=Math.round(bs);let g=o.jsGrp.get(key);if(!g){g={n:0,w:0,list:[],pl:[]};o.jsGrp.set(key,g);}g.n++;g.w+=qw;g.list.push(pref);
        // the play behind the best score of this queue (kept for the first queues of each score only)
        if(g.pl.length<150&&(o.jsPlN=(o.jsPlN|0))<4000&&bestS>=0){
          try{const T=Ts[bestS],ok0=bestS+'|'+bestP;let ord=ordC.get(ok0);if(ord===undefined){ord=jsBestOrder(T,bestP,o.js.b2b,ctx,o.js.cb||0);ordC.set(ok0,ord);}const fl=ord&&holdFlags(pref,bestP,useHold);
            if(ord&&fl){g.pl.push({q:pref,steps:buildSteps(T,ord.map((i,j)=>[i,fl[j]]),ctx),pic:T.p.map(x=>({t:x.t,cells:x.cells}))});o.jsPlN++;}}catch(_){}
        }}if(bs>o.jsMax) o.jsMax=bs;if(o.jsMin===null||bs<o.jsMin) o.jsMin=bs;}
      }
      if(I.g) I.g.w+=qw;
      if(wantLo){
        loOkw+=qw;
        const ms=new Set();
        for(const x of out){lsets.set(x,(lsets.get(x)||0)+qw);for(const ch of x) ms.add(ch);}
        for(const ch of ms) marg[ch]=(marg[ch]||0)+qw;
      }
    } else if(!o.solOnly){
      fn++;fw+=qw;
      if(!sfN) flist.push([pref,qw]);
    }
    if((k&255)===0) yield;
  }
  for(const I of setC.values()) if(I.es) for(const i of I.es) wSol[i]+=I.w;
  for(const I of set2C.values()) for(const i of I.es) wSol2[i]+=I.w;
  if(wantLo) o.lo={sets:[...lsets],marg,okw:loOkw};
  if(o.okN>0) o.ns=[n];
  if(!o.solOnly) o.fail={n:fn,w:fw,list:flist,cap:false};
  o.fail2=b2bOn?{n:fn2,w:fw2,list:flist2,cap:false}:null;
  if(sfN){
    const W=new Map();
    for(const I of setC.values()) if(I.sk) for(const k of I.sk) W.set(k,(W.get(k)||0)+I.w);
    let arr=[...W].sort((a,b)=>b[1]-a[1]);
    o.sfTotal=arr.length;
    if(o.sfInc||o.sfExc) arr=arr.filter(([k])=>{const r=sfReg.get(k);return r&&sfPicOk(Ts[r.i].p.filter((_,j)=>(r.S>>j)&1).map(q=>q.t),o.sfInc|0,o.sfExc|0);});
    if(o.mass!=null){const f=new Float64Array(arr.length*2);arr.forEach(([k,w],j)=>{f[2*j]=k;f[2*j+1]=w;});o.sfAll=f;}   // worker part: every setup weight, summed over the parts later
    o.setups=arr.slice(0,300).map(([k,w])=>{const r=sfReg.get(k),T=Ts[r.i];return{k,w,rows:r.rows,cl:r.cl,pic:T.p.filter((_,j)=>(r.S>>j)&1).map(q=>({t:q.t,cells:q.cells}))};});
  }
  if(o.probOnly) return;
  // ---- example order (steps for the viewer) of every solution that some queue needs
  const shapes=[];
  for(let i=0;i<Ts.length;i++){
    if(!(wSol[i]>0)) continue;
    const T=Ts[i],path=seqPath(T,firstQ[i],'',useHold,ctx);
    if(!path) continue;
    T.steps=buildSteps(T,path,ctx);T.q=firstQ[i];T.sp=T.steps.reduce((a,s)=>a+(s.spin?1:0),0);
    shapes.push({idx:i,w:wSol[i],sp:T.sp,q:T.q,n,steps:T.steps,T,mn:0,mg:0,sv:wantLo?[...svSets[i]]:[]});
  }
  o.shapes=shapes;
  if(groups.size){const pos=new Map(shapes.map((s,k)=>[s.idx,k]));o.grp=[...groups.values()].map(g=>[g.es.map(i=>pos.get(i)).filter(k=>k!==undefined),g.w]);}
  // ---- minimal solution set: fewest solutions that still cover every queue that can clear (greedy set cover weighted by queue probability;
  //      ties go to the solution with more spins)
  if(groups.size){
    const shOf=new Map(shapes.map(s=>[s.idx,s])),gl=[...groups.values()].map(g=>[g.es.filter(i=>shOf.has(i)),g.w]);
    o.minPending=true;   // solutions are shown first; the page then computes the minimal set in the background
  }
  // ---- back-to-back keeping: example play (every line clear keeps B2B) per solution, and the minimal set of such solutions
  if(b2bOn&&groups2.size){
    const shOf2=new Map(shapes.map(s=>[s.idx,s]));
    for(const s of shapes){
      if(!(wSol2[s.idx]>0)) continue;
      const path=seqPath(s.T,firstQ2[s.idx],'',useHold,ctx,true);
      if(!path) continue;
      s.bsteps=buildSteps(s.T,path,ctx);s.bq=firstQ2[s.idx];s.b2w=wSol2[s.idx];
    }
    const gl2=[...groups2.values()].map(g=>[g.es.filter(i=>shOf2.has(i)&&shOf2.get(i).bsteps),g.w]);
    const r2=minCover(gl2,i=>i===null?-1:shOf2.get(i).sp,500);
    r2.picks.forEach((p,i)=>{const s=shOf2.get(p.idx);s.bn=i+1;s.bg=p.gain;});
    const pos=new Map(shapes.map((s,k)=>[s.idx,k]));
    o.grp2=[...groups2.values()].map(g=>[g.es.map(i=>pos.get(i)).filter(k=>k!==undefined),g.w]);
    o.b2bMin={n:r2.picks.length,tot:r2.total,cov:r2.covered,exact:r2.exact};
  }
}
