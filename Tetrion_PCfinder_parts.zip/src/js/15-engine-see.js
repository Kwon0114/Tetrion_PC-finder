// ================= See N =================
// The player sees the current piece and the next N pieces (plus the hold) and plays the best move from that; later pieces are unknown and
// follow the queue's own distribution (queue items are independent, so the unknown part is only the unseen rest of the item being drawn).
// Expectimax over the "place" graph of solve3 (a node = the set of pieces placed so far, an edge = one more piece), so every finished play is a
// concrete solution. A policy (best move per observation) is then walked to get per-solution probability, example play, leftover bag pieces,
// failing prefixes, and the minimal set of solutions that keeps the same probability.
let SEEST=0;
function* seeFinish(o,ctx,Ts,seqs,n,m,useHold,N,H){
  const parts=seqs.parts,bagsM=seqs.bags||[],wantLo=!o.probOnly&&!o.solOnly&&bagsM.length>0;
  const P=parts.map(p=>p.map(op=>({s:op.q.join(''),w:op.w})));
  const offs=[];{let a=0;for(const p of parts){offs.push(a);a+=p[0].q.length;}}
  const partOf=d=>{let j=parts.length-1;while(j>0&&offs[j]>d) j--;return j;};
  // a part whose options are all permutations of one multiset with equal weight (a bag) is exchangeable: what is still to come depends only on the
  // letters already drawn, not on their order, so states that differ only in that order can share one cached value
  const exch=P.map(op=>{
    if(op.length<2) return false;
    const srt=x=>x.split('').sort().join(''),k0=srt(op[0].s),w0=op[0].w;
    let perm=1,cnt={},len=k0.length;for(const ch of k0) cnt[ch]=(cnt[ch]||0)+1;
    for(let q=2;q<=len;q++) perm*=q;for(const ch in cnt) for(let q=2;q<=cnt[ch];q++) perm/=q;
    return op.length===perm&&op.every(x=>srt(x.s)===k0&&Math.abs(x.w-w0)<1e-12);
  });
  const cc=new Map();
  const canon=(j,s)=>{
    if(!exch[j]) return j+':'+s;
    const k=j+':'+s;let r=cc.get(k);if(r) return r;
    r=j+'~'+s.split('').sort().join('');cc.set(k,r);return r;
  };
  const dc=new Map();
  const dist=(j,s)=>{
    const k=j+':'+s;let r=dc.get(k);if(r) return r;
    const w={};let tot=0;
    for(const op of P[j]) if(op.s.startsWith(s)){const x=op.s[s.length];w[x]=(w[x]||0)+op.w;tot+=op.w;}
    r=Object.keys(w).map(x=>[x,w[x]/tot]);dc.set(k,r);return r;
  };
  const root=o.dagRoot;
  Ts.forEach(T=>{T.cidx=new Map();T.bb.pcs.forEach((p,k)=>{const c=p.cells.map(([x,pr])=>pr*10+x).sort((a,b)=>a-b);T.cidx.set(p.t*1e9+((c[0]*160+c[1])*160+c[2])*160+c[3],k);});});
  // observations known at the start: the current piece + N next
  let lvl=[['',1]];
  for(let d=0;d<Math.min(1+N,m);d++){const nx=[],j=partOf(d);for(const [ob,pw] of lvl) for(const [x,pr] of dist(j,ob.slice(offs[j]))) nx.push([ob+x,pw*pr]);lvl=nx;}
  if(o.seeFirsts) lvl=lvl.filter(([ob])=>o.seeFirsts.includes(ob[0]));
  o.ph='eval';o.tp[4]=performance.now();o.seqsN=lvl.length;o.seqDone=0;
  // ---- probability only: fast path. Boards (same stage + same rows) share one cache, states are small integers, no walk over the plays.
  const partLen=P.map(op=>op[0].s.length);
  const maxCnt=x=>{const c={};let mx=0;for(const ch of x){c[ch]=(c[ch]||0)+1;if(c[ch]>mx) mx=c[ch];}return mx;};
  const fastOK=N+1<=8&&P.every((op,j)=>exch[j]?maxCnt(op[0].s)<8:partLen[j]<=7);
  if(o.probOnly&&fastOK){
    const pow8=[1];for(let q=1;q<=9;q++) pow8.push(pow8[q-1]*8);
    const bmap=new Map();let bcount=0;
    // value cache: one open-addressing hash table over (board id, unknown-part id, window/hold/flag) in typed arrays. The old per-board Map used keys above 2^31
    // (heap numbers: slow hashing and a lot of garbage); this has neither, and it is not limited to the 16.7M entries a Map can hold.
    let hCap=1<<16,hMask=hCap-1,hN=0,hB=new Int32Array(hCap),hF=new Int32Array(hCap),hW=new Int32Array(hCap),hV=new Float64Array(hCap);
    const HT_MAX=1<<26;   // slots (20 bytes each): about 1.3 GB at most, then the run is refused instead of crashing the tab
    const hSlot=(bid,fid,wk)=>{let x=Math.imul(bid,0x9E3779B1)^Math.imul(fid,0x85EBCA6B)^Math.imul(wk,0xC2B2AE35);x^=x>>>15;x=Math.imul(x,0x2C1B3C6D);x^=x>>>12;return x&hMask;};
    const hGrow=()=>{
      const ob=hB,of=hF,ow=hW,ov=hV,oc=hCap;
      if(oc>=HT_MAX) throw new Error('See cache full');
      hCap=oc*2;hMask=hCap-1;hB=new Int32Array(hCap);hF=new Int32Array(hCap);hW=new Int32Array(hCap);hV=new Float64Array(hCap);
      for(let i=0;i<oc;i++){const b=ob[i];if(b!==0){let j=hSlot(b,of[i],ow[i]);while(hB[j]!==0) j=(j+1)&hMask;hB[j]=b;hF[j]=of[i];hW[j]=ow[i];hV[j]=ov[i];}}
    };
    const getB=nd=>{
      if(nd.bd) return nd.bd;
      const k=nd.pcs.length+'|'+nd.rows.join(',');let b=bmap.get(k);
      if(!b){b={nd,bid:++bcount,placed:nd.pcs.length,eb:[[],[],[],[],[],[],[]],es:[new Set(),new Set(),new Set(),new Set(),new Set(),new Set(),new Set()]};bmap.set(k,b);}
      nd.bd=b;return b;
    };
    const cmOf=b=>{   // cm[t] = the most pieces of type t that any way of finishing from this board can still place
      if(b.cm) return b.cm;
      const cm=b.cm=new Int8Array(7);
      if(b.placed===n) return cm;
      for(let t=0;t<7;t++) for(const tb of b.eb[t]){const c=cmOf(tb);for(let u=0;u<7;u++){const v=c[u]+(u===t?1:0);if(v>cm[u]) cm[u]=v;}}
      return cm;
    };
    const reqOf=b=>{
      if(b.rq) return b.rq;
      if(b.placed===n) return b.rq=new Int32Array([0]);
      const set=new Set();
      for(let t=0;t<7;t++) for(const tb of b.eb[t]) for(const R of reqOf(tb)) set.add(R+(1<<(3*t)));
      return b.rq=Int32Array.from(set);
    };
    const cnt7=new Int8Array(7);
    const seenN=new Set();
    (function build(nd){
      if(seenN.has(nd)) return;seenN.add(nd);
      const b=getB(nd);
      if(nd.ed) for(const e of nd.ed){build(e.nb);const tb=getB(e.nb);if(!b.es[e.sh].has(tb)){b.es[e.sh].add(tb);b.eb[e.sh].push(tb);}}
    })(root);
    // what is still unknown, as a small object: part index + letters drawn so far in that part (as a multiset for bags)
    const FEND={id:0,j:-1,d:m,s:'',dd:[],nx:[]};let fcount=1;const FM=new Map();
    const mkF=(j,d,s)=>{
      if(d>=m) return FEND;
      let code=0;
      if(exch[j]){for(const ch of s) code+=pow8[TIDX[ch]];}else{for(const ch of s) code=code*8+TIDX[ch]+1;}
      const key=j*2097152+code;let F=FM.get(key);
      if(!F){F={id:fcount++,j,d,s,dd:null,nx:[]};FM.set(key,F);}
      return F;
    };
    const ddOf=F=>F.dd||(F.dd=dist(F.j,F.s).map(([x,pr])=>[TIDX[x],pr]));
    const nextF=(F,x)=>{
      let r=F.nx[x];if(r) return r;
      const s2=F.s+TYPES[x];let j2=F.j,s3=s2;
      if(s2.length===partLen[F.j]){j2=F.j+1;s3='';}
      r=mkF(j2,F.d+1,s3);F.nx[x]=r;return r;
    };
    function tryP(b,t,nh,w2,wl2,F,best){
      const L=b.eb[t];
      for(let q=0;q<L.length;q++){const v=V(L[q],nh,false,w2,wl2,F);if(v>best){best=v;if(best>=1-1e-12) return best;}}
      return best;
    }
    // state = board, hold (0 none, else piece+1), just-held flag, window of known pieces (base-8 digits, current piece first), unknown part
    function V(b,h,mp,w,wl,F){
      if(b.placed===n) return 1;
      {  // exact dead-end test: finishing needs r more placements, which can only use r of the next r+1 pieces (hold included). If the pieces already
         // seen (plus every piece still unseen in that range, counted as usable) cannot supply r placeable pieces, no play from here can succeed.
        const r=n-b.placed,rq=b.rq||reqOf(b);
        let Lq=h>0?r:r+1,uk=0;
        const avail=wl+(m-F.d);if(Lq>avail) Lq=avail;
        for(let t=0;t<7;t++) cnt7[t]=0;
        if(h>0) cnt7[h-1]++;
        const kn=Lq<wl?Lq:wl;
        for(let q=0;q<kn;q++) cnt7[((w>>(3*(wl-1-q)))&7)-1]++;
        uk=Lq-kn;   // pieces of that range that are still unseen: any of them could be the one that is missing
        {const cm=b.cm||cmOf(b);let us=uk;for(let t=0;t<7;t++) us+=cnt7[t]<cm[t]?cnt7[t]:cm[t];if(us<r) return 0;}
        let ok=false;
        for(let z=0;z<rq.length&&!ok;z++){
          const R=rq[z];let def=0;
          for(let t=0;t<7;t++){const d=((R>>(3*t))&7)-cnt7[t];if(d>0) def+=d;}
          if(def<=uk) ok=true;
        }
        if(!ok) return 0;
      }
      const bid=b.bid,fid=F.id,wk=w*16+h*2+(mp?1:0);
      let slot=hSlot(bid,fid,wk);
      for(;;){const kb=hB[slot];if(kb===0) break;if(kb===bid&&hF[slot]===fid&&hW[slot]===wk) return hV[slot];slot=(slot+1)&hMask;}
      const i=F.d-wl,need=Math.min(i+1+N,m);let best=0;
      if(F.d<need){
        const dd=F.dd||ddOf(F);
        for(let q=0;q<dd.length;q++){const x=dd[q][0];best+=dd[q][1]*V(b,h,mp,w*8+x+1,wl+1,nextF(F,x));}
      }else{
        const hasCur=wl>0,cur=hasCur?(w>>(3*(wl-1)))-1:-1;   // window = base-8 digits (3 bits each), so shifts and masks replace the divisions
        const w2=hasCur?w&((1<<(3*(wl-1)))-1):w,wl2=hasCur?wl-1:0;
        if(hasCur){
          best=tryP(b,cur,h,w2,wl2,F,0);
          if(useHold&&!mp&&best<1-1e-12){
            if(h>0){if(h-1!==cur) best=tryP(b,h-1,cur+1,w2,wl2,F,best);}
            else{const v=V(b,cur+1,true,w2,wl2,F);if(v>best) best=v;}
          }
        }else if(useHold&&h>0&&!mp) best=tryP(b,h-1,0,w2,wl2,F,0);
      }
      // the recursion above may have grown / filled the table: find the slot again
      slot=hSlot(bid,fid,wk);while(hB[slot]!==0) slot=(slot+1)&hMask;
      hB[slot]=bid;hF[slot]=fid;hW[slot]=wk;hV[slot]=best;
      if(++hN*2>hCap) hGrow();
      return best;
    }
    let lv=[[0,0,mkF(0,0,''),1]];
    for(let d=0;d<Math.min(1+N,m);d++){const nx=[];for(const [w,wl,F,pw] of lv) for(const [x,pr] of ddOf(F)) nx.push([w*8+x+1,wl+1,nextF(F,x),pw*pr]);lv=nx;}
    if(o.seeFirsts) lv=lv.filter(([w,wl])=>o.seeFirsts.includes(TYPES[Math.floor(w/pow8[wl-1])-1]));
    o.ph='eval';o.tp[4]=performance.now();o.seqsN=lv.length;o.seqDone=0;
    const rootB=getB(root);let tot=0;
    // ---- setup finder: the player aims at a setup S (the board after the first sfN placements), choosing the way to build it from the pieces he can see
    // (current + N next, hold included), and from there plays the normal See value. weight(S) = sum over starts of P(start) * best value over the ways to build S.
    const sfN=o.setupN|0,sfW=sfN?new Map():null;let bidN=0;
    const setupObs=(w,wl,F,pw)=>{
      const win=[];for(let i=0;i<wl;i++) win.push(Math.floor(w/pow8[wl-1-i])%8-1);
      const seen=new Set(),best=new Map();
      const dfs=(b,h,mp,ptr)=>{
        if(b.sid===undefined) b.sid=++bidN;
        const sk=((b.sid*8+h)*2+(mp?1:0))*16+ptr;
        if(seen.has(sk)) return;seen.add(sk);
        if(b.placed===sfN){
          const v=V(b,h,false,w%pow8[wl-ptr],wl-ptr,F);
          if(v>(best.get(b)||0)) best.set(b,v);
          return;
        }
        if(ptr>=wl) return;   // the setup needs pieces that are not visible
        const cur=win[ptr];
        for(const tb of b.eb[cur]) dfs(tb,h,false,ptr+1);
        if(useHold&&!mp){
          if(h>0){if(h-1!==cur) for(const tb of b.eb[h-1]) dfs(tb,cur+1,false,ptr+1);}
          else dfs(b,cur+1,true,ptr+1);
        }
      };
      dfs(rootB,0,false,0);
      for(const [b,v] of best) sfW.set(b,(sfW.get(b)||0)+pw*v);
    };
    try{for(const [w,wl,F,pw] of lv){tot+=pw*V(rootB,0,false,w,wl,F);if(sfN) setupObs(w,wl,F,pw);o.seqDone++;yield;}}
    catch(e){if(e&&e.message==='See cache full'){o.err=L('See 분석 과대 · 넥스트 또는 See 값 축소','See analysis too large · reduce Next or See');return;}throw e;}
    if(sfN){
      const Lh=Math.min(H,MAXL),Bn=ctx.B;let filled0=0;for(const r of ctx.rows0) filled0+=popc(r);
      let arr=[];
      for(const [b,w] of sfW){arr.push([sfKeyOf(b.nd.rows,Bn-Lh,Bn),w,b]);}
      arr.sort((a,b)=>b[1]-a[1]);
      o.sfTotal=arr.length;
      if(o.sfInc||o.sfExc) arr=arr.filter(e=>sfPicOk(e[2].nd.pcs.map(q=>TYPES[q.t]),o.sfInc|0,o.sfExc|0));
      if(o.mass!=null){const f=new Float64Array(arr.length*2);arr.forEach((e,j)=>{f[2*j]=e[0];f[2*j+1]=e[1];});o.sfAll=f;}
      o.setups=arr.slice(0,300).map(([k,w,b])=>{
        const rows=b.nd.rows.slice(Bn-Lh);let cnt=0;for(const v of rows) cnt+=popc(v);
        return{k,w,rows,cl:Math.round((filled0+4*sfN-cnt)/10),pic:b.nd.pcs.map(q=>({t:TYPES[q.t],cells:q.cells.map(([x,pr])=>[x,H-1-pr])}))};
      });
    }
    const pv=Math.min(1,tot);
    o.seeRes={N,p:pv};o.okW=pv;o.doneW=1;o.ns=[n];o.solN=Ts.length;o.shapes=[];
    return;
  }
  if(o.setupN){o.err='SETUP_SEE';return;}   // the setup finder needs the fast See evaluation
  // One solver; its values are cached on the nodes themselves (nd.mm). A = set of final nodes (solutions) the player may aim for, null = all.
  // Changing A only invalidates the nodes that can still reach a changed solution, so the minimal-set search re-evaluates a small part of the graph.
  const ONE={v:1,a:null};
  function makeSolver(){
    let A=null,st=++SEEST;
    const okn=nd=>{if(nd.rs===st) return nd.rv;let r=false;if(nd.pcs.length===n) r=!A||A.has(nd);else if(nd.ed) for(const e of nd.ed) if(okn(e.nb)){r=true;break;}nd.rs=st;nd.rv=r;return r;};
    // value depends on: the node (board), hold, the visible window, and what is still unknown (the unseen rest of the item being drawn)
    const keyOf=(h,mp,i,obs)=>{const d=obs.length;let f='e';if(d<m){const j=partOf(d);f=canon(j,obs.slice(offs[j]));}return (h||'-')+(mp?'!':'')+'|'+obs.slice(i)+'|'+f;};
    function E(nd,h,mp,i,obs){
      if(nd.pcs.length===n) return ONE;
      const key=keyOf(h,mp,i,obs);let mm=nd.mm;if(!mm) mm=nd.mm=new Map();
      let en=mm.get(key);if(en!==undefined) return en;
      const d=obs.length,need=Math.min(i+1+N,m);let best=0,ba=null;
      if(d<need){const j=partOf(d);for(const [x,pr] of dist(j,obs.slice(offs[j]))) best+=pr*E(nd,h,mp,i,obs+x).v;}
      else{
        let eb=nd.eb;if(!eb){eb=nd.eb=[[],[],[],[],[],[],[]];if(nd.ed) for(const e of nd.ed) eb[e.sh].push(e);}
        const cur=i<m?obs[i]:null;
        // k: 0 place the current piece, 1 swap with hold and place the held piece, 2 hold into an empty slot, 3 queue exhausted: place the held piece
        const tp=(t,nh,k)=>{const L=eb[TIDX[t]];for(let q=0;q<L.length;q++){const e=L[q];if(A&&!okn(e.nb)) continue;const v=E(e.nb,nh,false,i+1,obs).v;if(v>best+1e-12){best=v;ba={k,e,nh};if(best>=1-1e-12) return;}}};
        if(cur!==null){
          tp(cur,h,0);
          if(useHold&&!mp&&best<1-1e-12){
            if(h!==null){if(h!==cur) tp(h,cur,1);}
            else{const v=E(nd,cur,true,i+1,obs).v;if(v>best+1e-12){best=v;ba={k:2,nh:cur};}}
          }
        } else if(useHold&&h!==null&&!mp) tp(h,null,3);
      }
      en={v:best,a:ba};mm.set(key,en);if(capOn&&++memoN>MEMO_CAP) throw SEE_CAP;return en;
    }
    // anc = the nodes whose answer can change because of this one edit of A (every node that can reach the changed solution): only their okn marks are dropped
    return {E,setA(x,anc){A=x;if(anc){for(const nd of anc) nd.rs=0;}else st=++SEEST;}};
  }
  let capOn=true,memoN=0;const MEMO_CAP=1500000,SEE_CAP={seeCap:1};
  const S=makeSolver();
  function* total(){o.seqDone=0;let t=0;for(const [ob,pw] of lvl){t+=pw*S.E(root,null,false,0,ob).v;o.seqDone++;yield;}return Math.min(1,t);}
  // follow the best moves (path = linked list, only the first play of each solution is ever turned into an array)
  function* walk(acc){
    const rec=(nd,h,hi,mp,i,obs,pw,path)=>{
      if(nd.pcs.length===n){acc.leaf(nd,obs,i,hi,pw,path);return;}
      const en=S.E(nd,h,mp,i,obs);
      if(en.v<=1e-15){if(acc.fail) acc.fail(obs,pw);return;}
      const d=obs.length,need=Math.min(i+1+N,m);
      if(d<need){const j=partOf(d);for(const [x,pr] of dist(j,obs.slice(offs[j]))) rec(nd,h,hi,mp,i,obs+x,pw*pr,path);return;}
      const a=en.a;
      if(a.k===2){rec(nd,a.nh,i,true,i+1,obs,pw,path);return;}
      rec(a.e.nb,a.nh,a.k===0?hi:a.k===1?i:-1,false,i+1,obs,pw,acc.path?{pc:a.e.pc,u:a.k===0?mp:true,p:path}:null);
    };
    o.seqDone=0;
    for(const [ob,pw] of lvl){rec(root,null,-1,false,0,ob,pw,null);o.seqDone++;yield;}
  }
  const loFrom=(qi,h,pref)=>{   // pure remaining pieces: all bag contents minus pieces already spent (drawn from the queue and not sitting in hold)
    const cnt={};
    for(const b of bagsM){
      for(const ch of b.elems) cnt[ch]=(cnt[ch]||0)+1;
      const end=Math.min(b.off+b.len,qi);
      for(let j=b.off;j<end;j++){
        if(j===h) continue;   // still in hold → remains
        const ch=pref[j];
        if(cnt[ch]>0) cnt[ch]--;
      }
    }
    // hold index outside every bag (fixed queue letters, etc.): count it as remaining
    if(h>=0){
      let inBag=false;
      for(const b of bagsM) if(h>=b.off&&h<b.off+b.len){inBag=true;break;}
      if(!inBag){const ch=pref[h];cnt[ch]=(cnt[ch]||0)+1;}
    }
    let r='';for(const t of TYPES) r+=t.repeat(cnt[t]||0);
    return r;
  };
  let Vf;
  try{Vf=yield* total();}
  catch(err){
    if(err!==SEE_CAP) throw err;
    // the full See analysis (solution list, failing queues) needs too much memory: free it and fall back to the probability-only evaluation
    const seen=new Set(),clr=nd=>{if(seen.has(nd)) return;seen.add(nd);nd.mm=null;nd.rs=0;if(nd.ed) for(const e of nd.ed) clr(e.nb);};clr(root);
    if(!fastOK){o.err=L('See 분석 과대 · 넥스트 또는 See 값 축소','See analysis too large · reduce Next or See');return;}
    o.probOnly=true;o.capped=true;
    yield* seeFinish(o,ctx,Ts,seqs,n,m,useHold,N,H);return;
  }
  capOn=false;
  o.seeRes={N,p:Vf};o.okW=Vf;o.doneW=1;o.ns=[n];o.solN=Ts.length;o.shapes=[];
  const needWalk=!o.probOnly;   // probability only: just the value, no walk over the plays
  const solW=new Map(),ex=new Map(),lsets=new Map(),marg={},fl=[],svSets=new Map();let fn=0,fw=0,loOkw=0;
  if(needWalk) yield* walk({path:!o.probOnly,
    leaf(nd,obs,i,hi,pw,path){
      solW.set(nd,(solW.get(nd)||0)+pw);if(path&&!ex.has(nd)) ex.set(nd,{path,obs});
      if(wantLo){
        const x=loFrom(Math.min(i,m),hi,obs);loOkw+=pw;
        lsets.set(x,(lsets.get(x)||0)+pw);for(const ch of new Set(x)) marg[ch]=(marg[ch]||0)+pw;let ss=svSets.get(nd);if(!ss) svSets.set(nd,ss=new Set());ss.add(x);
      }
    },
    fail:o.solOnly?null:(obs,pw)=>{fn++;fw+=pw;fl.push([obs,pw]);}});
  if(needWalk&&!o.solOnly) o.fail={n:fn,w:fw,list:fl,cap:false};
  if(wantLo) o.lo={sets:[...lsets],marg,okw:loOkw};
  if(o.probOnly) return;
  const shapes=[];
  Ts.forEach((T,i)=>{
    const w=solW.get(T.bb);if(!(w>0)) return;
    const e=ex.get(T.bb),path=[];for(let q=e.path;q;q=q.p) path.push([T.cidx.get(q.pc),q.u]);path.reverse();
    T.steps=buildSteps(T,path,ctx);T.q=e.obs;T.sp=T.steps.reduce((a,s)=>a+(s.spin?1:0),0);
    shapes.push({idx:i,w,sp:T.sp,q:T.q,n,steps:T.steps,T,mn:0,mg:0,sv:wantLo?[...svSets.get(T.bb)]:[]});
  });
  o.shapes=shapes;o.okN=shapes.length;
  if(!shapes.length) return;
  o.grp=shapes.map((s,k)=>[[k],s.w]);   // under See one play ends in exactly one solution
  // minimal solution set: start from the solutions the best play uses and drop them one by one (least likely first) while the See probability stays the same
  let cur=null,exact=true;
  if(shapes.length>1){
    const t0=performance.now();cur=new Set(shapes.map(s=>s.T.bb));
    // every node and its parents, built once; the nodes that can still reach `target` are then found by walking up from it (all nodes when target is null)
    const allN=[],par=new Map(),seenA=new Set([root]);
    {const stk=[root];while(stk.length){const nd=stk.pop();allN.push(nd);if(nd.ed) for(const e of nd.ed){let ps=par.get(e.nb);if(!ps) par.set(e.nb,ps=[]);ps.push(nd);if(!seenA.has(e.nb)){seenA.add(e.nb);stk.push(e.nb);}}}}
    const sweep=(target)=>{
      if(target===null) return allN;
      const seen=new Set([target]),list=[target],stk=[target];
      while(stk.length){const nd=stk.pop(),ps=par.get(nd);if(ps) for(const p of ps) if(!seen.has(p)){seen.add(p);list.push(p);stk.push(p);}}
      return list;
    };
    sweep(null).forEach(nd=>{nd.mm=null;});S.setA(cur);
    for(const s of shapes.slice().sort((a,b)=>a.w-b.w)){
      if(performance.now()-t0>1000){exact=false;break;}
      const tg=s.T.bb,anc=sweep(tg);
      cur.delete(tg);S.setA(cur,anc);anc.forEach(nd=>{nd.mm=null;});
      const v=yield* total();
      if(v<Vf-1e-9){cur.add(tg);S.setA(cur,anc);anc.forEach(nd=>{nd.mm=null;});}
    }
  }
  const mgW=new Map();
  if(cur) yield* walk({leaf(nd,obs,i,hi,pw){mgW.set(nd,(mgW.get(nd)||0)+pw);}});
  else mgW.set(shapes[0].T.bb,shapes[0].w);
  const inA=shapes.filter(s=>!cur||cur.has(s.T.bb)).sort((a,b)=>(mgW.get(b.T.bb)||0)-(mgW.get(a.T.bb)||0)||b.sp-a.sp);
  inA.forEach((s,k)=>{s.mn=k+1;s.mg=mgW.get(s.T.bb)||0;});
  o.minimal=inA.map(s=>({idx:s.idx,gain:s.mg}));o.minTotal=Vf;o.minCov=Math.min(1,inA.reduce((a,s)=>a+s.mg,0));o.minExact=true;
  o.seeRes.minLimit=!exact;
}
// seconds spent in each phase so far: [scan, cull, place, orders, check]
function passTimes(o){
  const n=performance.now(),t=o.tp||[],r=[];
  for(let i=0;i<5;i++){
    const a=t[i];if(a==null){r.push(null);continue;}
    let b=t.slice(i+1).find(v=>v!=null);if(b==null) b=o.ph==='done'?(o.tEnd||n):n;
    r.push((b-a)/1000);
  }
  return r;
}
// key of one queue's per-solution best scores (queues with identical vectors merge into one entry)
function pqk(m,e){return [...m].sort((a,b)=>a[0]-b[0]).map(x=>x[0]+':'+x[1]+':'+(e.get(x[0])||0)).join(',');}
function snapshot(o){
  const shapes=(o.shapes||[]).map(s=>({w:s.w,sp:s.sp,q:s.q,n:s.n,steps:s.steps,pic:s.T.p.map(q=>({t:q.t,cells:q.cells})),mn:s.mn||0,mg:s.mg||0,sv:s.sv||[],bsteps:s.bsteps||null,bq:s.bq||null,b2w:s.b2w||0,bn:s.bn||0,bg:s.bg||0,ev:(o.solEv&&o.solEv.get(s.idx))||0,evc:(o.solEvC&&o.solEvC.get(s.idx))?Array.from(o.solEvC.get(s.idx)):null,evp:(o.solEvP&&o.solEvP.get(s.idx))?maxMasks(o.solEvP.get(s.idx)):[],evpc:(o.solEvPC&&o.solEvPC.get(s.idx))?paretoVecs([...o.solEvPC.get(s.idx)]):null}));
  return {pt:passTimes(o),shapes,okW:o.okW||0,okN:o.okN||0,b2bW:o.b2bW||0,b2bN:o.b2bN||0,b2b:!!o.b2b,doneW:o.doneW||0,seqDone:o.seqDone||0,minN:o.minimal?o.minimal.length:0,minTot:o.minTotal||0,minCov:o.minCov||0,minExact:o.minExact!==false,minLB:o.minLB,minT:o.minT,minPending:!!o.minPending,minPending:!!o.minPending,minSkipped:false,tot:o.seqsN||0,probOnly:!!o.probOnly,setups:o.setups||null,sfW:o.sfAll||null,sfN:o.setupN|0,sfInc:o.sfInc|0,sfExc:o.sfExc|0,sfTotal:o.sfTotal||0,ns:(o.ns||[]).slice(),err:o.err,errN:o.errN||0,lo:o.lo||null,grp:o.grp||null,grp2:o.grp2||null,fail2:o.fail2||null,bmin:o.b2bMin||null,fail:o.fail||null,solN:o.solN||0,see:o.seeRes||null,mass:o.mass==null?1:o.mass,capped:!!o.capped,solOnly:!!o.solOnly&&o.see==null,js:o.js?{pqo:!!o.jsPQover,pq:(()=>{if(!o.jsPQ||o.jsPQover) return null;const pos=new Map((o.shapes||[]).map((x,k)=>[x.idx,k])),out=[];for(const [k,w] of o.jsPQ){const a=[];for(const t of k.split(',')){const [i,v,e]=t.split(':').map(Number);const q=pos.get(i);if(q!==undefined) a.push([q,v,e]);}out.push([w,a]);}return out;})(),tio:!!o.js.tio,b2b:!!o.js.b2b,pre:o.js.pre||0,cb:o.js.cb||0,sum:o.jsSum||0,w:o.jsW||0,us:o.jsUS||0,un:o.jsUN||0,max:o.jsMax||0,min:o.jsMin,grp:[...o.jsGrp].sort((a,b)=>b[0]-a[0]),ev:[...o.jsEv],evp:[...(o.jsEvP||[])],evc:(o.jsEvC||[]).map(m=>[...m]),evq:[...(o.jsEvQ||[])],evpc:[...(o.jsEvPC||[])]}:null};
}
