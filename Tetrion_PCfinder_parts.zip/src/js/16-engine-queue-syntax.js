
//LOGIC_END

// Queue syntax. A group "[ ... ]" holds elements (single pieces or nested groups) separated freely by spaces.
//   [IOT]      pick 1 at random (1/3 each)      [IOT]!    all elements, random order
//   [IOTS]2    pick 2, written order            [IOTS]2!  pick 2, random order   (number first, then !)
//   [[SZ]! [LJ]!]2!   both sub-groups (each internally random), in random order
function parseQ(s){
  s=s.toUpperCase();let i=0;
  const warns=parseQ.warns=[];   // non-fatal notes about the order rules (shown under the queue box)
  const fail=m=>{throw new Error(m);};
  const lettersOf=x=>x.c?x.c:x.g.map(lettersOf).join('');
  function warnCons(e){
    const has=new Set(lettersOf(e).split('')),miss=new Set();
    for(const ch of e.cons) for(const grp of ch) for(const c of grp) if(!has.has(c)) miss.add(c);
    if(miss.size){const m=[...miss].join(', ');warns.push(L(`순서 조건 ${m}: 묶음에 없어 무시`,`Order rule ${m}: not in group, ignored`));}
    const k=Math.min(e.k,e.g.length);
    if(k<e.g.length) warns.push(L(`묶음 ${e.g.length}개 중 ${k}개만 뽑아 나머지는 순서 조건 제외`,`Only ${k} of ${e.g.length} picked; the rest skip the order rule`));
  }
  function mods(){
    let d='',bang=false,isBag=false,hasB=false,hasP=false;
    while(/[0-9]/.test(s[i]||'')) d+=s[i++];
    while((s[i]==='!'&&!hasB)||(s[i]==='%'&&!hasP)){bang=true;if(s[i]==='%'){isBag=true;hasP=true;}else hasB=true;i++;}   // ! and % may be combined (!% or %!), each once
    if(/[0-9]/.test(s[i]||'')) fail(L('숫자는 !·%보다 앞에 써야 합니다. 예: [IOTSZJL]3!','A number must come before ! or %. e.g. [IOTSZJL]3!'));
    if(d&&+d<1) fail(L('뽑는 개수는 1 이상이어야 합니다.','The pick count must be at least 1.'));
    return {k:d?+d:null,r:bang,b:isBag};
  }
  // order rule after a group: {LJ<SZ} = every piece of LJ comes before every piece of SZ (other pieces are free); {SZ>LJ} says the same the other way round.
  // chains A<B<C or A>B>C, several rules separated by commas; a chain may mix < and > (A<B>C = A and C both before B), it is then split into runs
  function consClause(){
    if(s[i]!=='{') return null;
    i++;
    const chains=[];let cur=[],ops=[],grp='';
    const flush=()=>{if(grp){cur.push(grp);grp='';}};
    const end=()=>{
      flush();
      if(cur.length===1) fail(L('순서 조건은 A<B처럼 두 묶음 이상이어야 합니다. 예: {LJ<SZ}','An order rule needs two or more groups, e.g. {LJ<SZ}'));
      if(cur.length&&ops.length!==cur.length-1) fail(L('< > 앞뒤에는 피스가 있어야 합니다. 예: {LJ<SZ}','Pieces are needed on both sides of < and >, e.g. {LJ<SZ}'));
      if(cur.length){
        // cut into runs of one direction; each run is written earliest-first
        let run=[cur[0],cur[1]],dir=ops[0];
        const push=()=>chains.push(dir==='>'?run.slice().reverse():run);
        for(let j=1;j<ops.length;j++){
          if(ops[j]===dir) run.push(cur[j+1]);
          else{push();run=[cur[j],cur[j+1]];dir=ops[j];}
        }
        push();
      }
      cur=[];ops=[];
    };
    while(i<s.length&&s[i]!=='}'){
      const ch=s[i++];
      if('IOTSZJL'.includes(ch)) grp+=ch;
      else if(ch==='<'||ch==='>'){if(!grp) fail(L('< > 앞뒤에는 피스가 있어야 합니다. 예: {LJ<SZ}','Pieces are needed on both sides of < and >, e.g. {LJ<SZ}'));flush();ops.push(ch);}
      else if(ch===',') end();
      else if(ch!==' ') fail(L('{ } 안에는 피스(IOTSZJL), <, >, 쉼표만 쓸 수 있습니다.','Only pieces (IOTSZJL), <, > and commas are allowed inside { }.'));
    }
    if(s[i]!=='}') fail(L('닫히지 않은 { 가 있습니다.','There is an unclosed {.'));
    i++;end();
    return chains.length?chains:null;
  }
  function list(close){
    const els=[];
    while(i<s.length){
      const ch=s[i];
      if(ch===']'){ if(!close) fail(L('짝이 없는 ] 가 있습니다.','There is an unmatched ].')); return els; }
      i++;
      if(ch==='['){
        let neg=false;{let j=i;while(s[j]===' ') j++;if(s[j]==='^'){neg=true;i=j+1;}}   // [^TI] = the full bag without the written pieces
        let g=list(true);
        if(s[i]!==']') fail(L('닫히지 않은 [ 가 있습니다.','There is an unclosed [.'));
        if(neg){
          if(g.some(e=>!e.c)) fail(L('[^ ] 안에는 피스(IOTSZJL)만 쓸 수 있습니다. 예: [^TI]','Only pieces (IOTSZJL) may follow [^. e.g. [^TI]'));
          const ex=new Set(g.map(e=>e.c));
          g='IOTSZJL'.split('').filter(c=>!ex.has(c)).map(c=>({c}));
          if(!g.length) fail(L('모든 피스를 제외할 수 없습니다.','Excluding every piece leaves nothing to pick.'));
        }
        i++;
        const m=mods(),cons=consClause();
        if(g.length){const is7=g.length===7&&g.every(e=>e.c)&&new Set(g.map(e=>e.c)).size===7;   // [IOTSZJL] (any order) is the same as []: with ! it is a 7-bag
          els.push({g,k:m.k===null?(m.r?g.length:1):m.k,r:m.r,b:(is7&&m.r)?!m.b:m.b,cons});}
        else{
          // [] with nothing inside stands for all seven pieces. Plain [] (or []3) is an ordinary group: [] picks 1 of the 7 at random, []3 picks 3 in written order.
          // With ! it is a 7-bag ([]! = [IOTSZJL]!: random order, no repeats; []3! keeps the first 3); a % releases the bag ([]%, []!%, []3%): same random order, no leftover-bag report
          const bag='IOTSZJL'.split('').map(c=>({c}));
          if(m.r) els.push({g:bag,k:m.k===null?7:m.k,r:true,b:!m.b,cons});
          else els.push({g:bag,k:m.k===null?1:m.k,r:false,b:false,cons});
        }
        {const e=els[els.length-1];if(e&&e.cons) warnCons(e);}
      }
      else if('IOTSZJL'.includes(ch)) els.push({c:ch});
      else if(/[0-9!%]/.test(ch)) fail(L('숫자와 !, %는 ] 바로 뒤에만 쓸 수 있습니다. 예: [IOTSZJL]3!','A number, ! or % may only follow ]. e.g. [IOTSZJL]3!'));
      else if(ch==='{'||ch==='}'||ch==='<'||ch==='>') fail(L('순서 조건 { }은 ] 바로 뒤에만 쓸 수 있습니다. 예: []!{LJ<SZ}','An order rule { } may only follow ]. e.g. []!{LJ<SZ}'));
      else if(ch==='^') fail(L('^는 [ 바로 뒤에만 쓸 수 있습니다. 예: [^TI]','^ may only come right after [. e.g. [^TI]'));
      else if(!/\s/.test(ch)) fail(L(`입력할 수 없는 문자 '${ch}' 가 ${i}번째에 있습니다. 피스는 I O T S Z J L 만 쓸 수 있습니다.`,`Invalid character '${ch}' at position ${i}. Only the pieces I O T S Z J L are allowed.`));
    }
    if(close) fail(L('닫히지 않은 [ 가 있습니다.','There is an unclosed [.'));
    return els;
  }
  return list(false);
}
// Every distinct sequence a node can produce, with its probability.
// Each choice of element indices is equally likely; duplicates are merged exactly.
function nodeOptions(n){
  if(n.opts) return n.opts;   // parallel partition: a pre-filtered option list
  if(n.c) return [{q:[n.c],w:1}];
  const eo=n.g.map(nodeOptions), m=n.g.length, k=Math.min(n.k,m);
  const acc=new Map(), used=Array(m).fill(false);let total=0;
  function emit(idxs){
    let combos=[{q:[],w:1}];
    for(const i of idxs){
      const nx=[];
      for(const c of combos) for(const o of eo[i]) nx.push({q:c.q.concat(o.q),w:c.w*o.w});
      combos=nx;
    }
    for(const c of combos){const key=c.q.join('');acc.set(key,(acc.get(key)||0)+c.w);}
    total++;
  }
  (function rec(start,cur){
    if(cur.length===k){emit(cur);return;}
    if(n.r){for(let i=0;i<m;i++){if(used[i])continue;used[i]=true;rec(0,cur.concat(i));used[i]=false;}}
    else for(let i=start;i<=m-(k-cur.length);i++) rec(i+1,cur.concat(i));
  })(0,[]);
  let res=[...acc].map(([s,w])=>({q:s.split(''),w:w/total}));
  if(n.cons){
    res=res.filter(o=>consOk(o.q,n.cons));
    if(!res.length) throw new Error(L('순서 조건을 만족하는 큐가 없습니다.','No queue satisfies the order rule.'));
    const sw=res.reduce((a,o)=>a+o.w,0);res=res.map(o=>({q:o.q,w:o.w/sw}));
  }
  return res;
}
// order rule check: for every chain, each piece of an earlier group comes before each piece of a later group (pieces missing from the queue are ignored)
function consOk(q,chains){
  for(const ch of chains){
    for(let a=0;a<ch.length;a++) for(let b=a+1;b<ch.length;b++){
      let mx=-1,mn=1e9;
      q.forEach((c,j)=>{if(ch[a].includes(c)&&j>mx) mx=j;if(ch[b].includes(c)&&j<mn) mn=j;});
      if(mx>=0&&mn<1e9&&mx>mn) return false;
    }
  }
  return true;
}
// All orderings are generated on demand (mixed-radix index), so any number of combinations is allowed.
// Upper bound on how many distinct sequences one top-level item can produce, computed WITHOUT enumerating them
// (so something like [[][][][][][][][][]]! is refused up front instead of freezing the page)
function estOptions(n){
  if(n.opts) return n.opts.length;
  if(n.c) return 1;
  const m=n.g.length,k=Math.min(n.k,m);
  const ch=n.g.map(estOptions).sort((a,b)=>b-a);
  let prod=1;for(let i=0;i<k;i++) prod*=ch[i];
  let sets=1;
  if(n.r){for(let i=0;i<k;i++) sets*=(m-i);}
  else{for(let i=0;i<k;i++) sets=sets*(m-i)/(i+1);}
  return sets*prod;
}
function buildSeqs(items){
  // bag items (top-level []! or ...%) made only of single pieces carry their element list, so the search can tell what is left in the bag after the PC
  const bagElems=it=>it.b&&it.g&&it.g.every(e=>e.c)?it.g.map(e=>e.c).sort().join(''):null;
  return makeSeqs(items.map(nodeOptions),items.map(bagElems));
}
function makeSeqs(ps,meta){
  let n=1;
  for(const p of ps) n*=p.length;
  const len=ps.reduce((a,p)=>a+p[0].q.length,0);
  const pn=ps.map(p=>p.map(o=>({qn:o.q.map(c=>TYPES.indexOf(c)),w:o.w})));
  const off=[];{let a=0;for(const p of ps){off.push(a);a+=p[0].q.length;}}
  const cho=new Array(ps.length);
  const bags=[];{let a=0;ps.forEach((p,i)=>{const l=p[0].q.length;if(meta&&meta[i]) bags.push({off:a,len:l,elems:meta[i]});a+=l;});}
  return {n,len,bags,parts:ps,
  // The search only ever looks at the first m pieces of a queue, so queues that agree on those m pieces are one case.
  // Drops everything after piece m and merges the options of the item that straddles the cut (weights add up).
  truncate(m){
    if(m>=len) return this;
    const nps=[],nmeta=[];let a=0;
    for(let i=0;i<ps.length&&a<m;i++){
      const l=ps[i][0].q.length;
      if(a+l<=m){nps.push(ps[i]);nmeta.push(meta?meta[i]:null);a+=l;continue;}
      const r=m-a,mp=new Map();
      for(const o of ps[i]){const key=o.q.slice(0,r).join('');mp.set(key,(mp.get(key)||0)+o.w);}
      nps.push([...mp].map(([k,w])=>({q:k.split(''),w})));nmeta.push(meta?meta[i]:null);a=m;
    }
    return makeSeqs(nps,nmeta);
  },
  // writes queue number k into buf (piece indexes into TYPES) and returns its probability weight (same product order as at())
  fill(k,buf){
    for(let i=ps.length-1;i>=0;i--){
      const lst=pn[i],r=k%lst.length;k=(k-r)/lst.length;
      const o=lst[r];cho[i]=o;const qn=o.qn,b=off[i];
      for(let j=0;j<qn.length;j++) buf[b+j]=qn[j];
    }
    let w=1;for(let i=0;i<ps.length;i++) w*=cho[i].w;
    return w;
  },
  at(k){
    const idx=Array(ps.length);let w=1;
    for(let i=ps.length-1;i>=0;i--){idx[i]=k%ps[i].length;k=Math.floor(k/ps[i].length);}
    const q=[];ps.forEach((p,i)=>{q.push(...p[idx[i]].q);w*=p[idx[i]].w;});
    return {q,w};
  }};
}
self.__ENGINE_END=1;
