
const $=id=>document.getElementById(id);
// 180° kick tests (numbers 2-6) switched OFF for the Jstris preset: only test #1 (in place) stays on. TETR.IO preset = all on.
const JSTRIS_KICKS_OFF=[2,3,4,5,6];
const tioMode=()=>$('kmode').value==='tio';
const M0=()=>tioMode()?'TETR.IO Blitz':'Jstris Ultra';
const u180v=()=>{setJSI(!tioMode());if(!$('u180').checked) return 0;let m=31;if(!tioMode()) for(const k of JSTRIS_KICKS_OFF) m&=~(1<<(k-2));return 64+m;};
const ed=$('ed'), vw=$('vw');
let H=4, board=[], gen=null, running=false, sols=[], cur=null, step=0, timer=null;
let tint=[], curColor='G';   // tint: cosmetic colour per filled cell (does not affect the search)
const resetBoard=()=>{board=Array.from({length:H},()=>Array(COLS).fill(0));tint=Array.from({length:H},()=>Array(COLS).fill(null));drawEd();};
function size(cv){cv.width=COLS*CELL;cv.height=H*CELL;}
function cell(c,x,y,color,a){
  c.globalAlpha=a||1;c.fillStyle=color;c.fillRect(x*CELL+1,y*CELL+1,CELL-2,CELL-2);
  c.fillStyle='rgba(255,255,255,.22)';c.fillRect(x*CELL+1,y*CELL+1,CELL-2,4);c.globalAlpha=1;
}
function grid(c){
  c.clearRect(0,0,COLS*CELL,H*CELL);c.strokeStyle='#161b3a';c.lineWidth=1;c.beginPath();
  for(let i=0;i<=COLS;i++){c.moveTo(i*CELL+.5,0);c.lineTo(i*CELL+.5,H*CELL);}
  for(let j=0;j<=H;j++){c.moveTo(0,j*CELL+.5);c.lineTo(COLS*CELL,j*CELL+.5);}
  c.stroke();
}
var pcSyncLock=false;
function drawEd(){
  if(!pcSyncLock&&!SMODE&&pcSrc&&suBoards&&suBoards.includes(pcSrc)){pcSrc.H=H;pcSrc.board=board.map(r=>r.slice());pcSrc.tint=tint.map(r=>r.slice());}   // both modes share the same boards
  size(ed);const c=ed.getContext('2d');grid(c);if(typeof updQInfo==='function'&&$('qinfo')) setTimeout(updQInfo,0);
  board.forEach((r,y)=>r.forEach((v,x)=>v&&cell(c,x,y,(tint[y]&&tint[y][x])||COLORS.G)));
}
let paint=null;
function pos(e){const b=ed.getBoundingClientRect();return[Math.floor((e.clientX-b.left)/b.width*COLS),Math.floor((e.clientY-b.top)/b.height*H)];}
function paintAt(e){if(running) return;const[x,y]=pos(e);if(x<0||y<0||x>=COLS||y>=H)return;const col=COLORS[curColor];if(paint===null)paint=(board[y][x]&&((tint[y][x]||COLORS.G)===col))?0:1;board[y][x]=paint;tint[y][x]=paint?(curColor==='G'?null:col):null;drawEd();}
ed.addEventListener('pointerdown',e=>{paint=null;ed.setPointerCapture(e.pointerId);paintAt(e);});
ed.addEventListener('pointermove',e=>{if(e.buttons)paintAt(e);});
(function(){const pal=$('pal');['G','I','O','T','S','Z','J','L'].forEach(k=>{const b=document.createElement('button');b.type='button';b.className='sw'+(k===curColor?' on':'');b.style.background=COLORS[k];b.dataset.k=k;b.setAttribute('aria-label',k==='G'?L('회색','Gray'):k);b.onclick=()=>{curColor=k;pal.querySelectorAll('.sw').forEach(x=>x.classList.toggle('on',x===b));};pal.appendChild(b);});})();
ed.addEventListener('pointerup',()=>restoreSaved());
ed.addEventListener('pointercancel',()=>restoreSaved());
// 높이를 바꿔도 지형 유지: 아래쪽 기준으로 줄을 늘리거나(위에 빈 줄 추가) 줄인다(위쪽 줄 제거)
const resizeBoard=n=>{
  const nb=Array.from({length:n},()=>Array(COLS).fill(0)),nt=Array.from({length:n},()=>Array(COLS).fill(null));
  for(let i=1;i<=Math.min(n,H);i++){nb[n-i]=board[H-i].slice();nt[n-i]=(tint[H-i]||Array(COLS).fill(null)).slice();}
  H=n;board=nb;tint=nt;drawEd();
};
const hCap=()=>23;   // setup builder: up to a full fumen field (23 rows); PC finder: 12
const setH=v=>{v=Math.max(2,Math.min(hCap(),Math.round(+v)||4));if(running){$('hh').value=H;return;}$('hh').value=v;if(v!==H){resizeBoard(v);}$('hint6').style.display=H>MAXL?'':'none';};
$('hh').onchange=e=>{setH(e.target.value);restoreSaved();};
$('hm').onclick=()=>{setH(H-1);restoreSaved();};
$('hp').onclick=()=>{setH(H+1);restoreSaved();};
$('clr').onclick=()=>{if(running) return;resetBoard();restoreSaved();};
$('q').value='[]!';   // the queue box starts with one full bag in random order

const st=(t,k)=>{const s=$('status');s.textContent=t;s.className=k||'';};
function toRows(){
  const rows=Array(H+BUF).fill(0);
  board.forEach((r,y)=>r.forEach((v,x)=>{if(v)rows[BUF+y]|=1<<x;}));
  return rows;
}
function stopRun(){running=false;$('go').style.display='';$('stop').style.display='none';}
