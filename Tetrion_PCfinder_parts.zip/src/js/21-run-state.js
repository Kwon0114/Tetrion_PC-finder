const fmtT=v=>v.toFixed(1);
const PHN=[['scan','scan'],['cull','cull'],['place','place'],['지원 큐','supporting queues'],['큐 확인','queue check']];
const ptK=R=>{if(!R||!R.pt) return '';const a=[];R.pt.forEach((v,i)=>{if(v!=null) a.push(PHN[i][0]+' '+fmtT(v)+'초');if(i===2&&R.minT!=null) a.push('최소해 '+fmtT(R.minT)+'초');});return a.length?` (${a.join(' · ')})`:'';};
const ptE=R=>{if(!R||!R.pt) return '';const a=[];R.pt.forEach((v,i)=>{if(v!=null) a.push(PHN[i][1]+' '+fmtT(v)+'s');if(i===2&&R.minT!=null) a.push('minimal '+fmtT(R.minT)+'s');});return a.length?` (${a.join(' · ')})`:'';};
let runT0=0;   // start of the current search (for the elapsed time in the status line)
let lastNextOff=2;
let lastSeeOff=2;   // See counts current piece + hold + next: next-count = See - (hold ? 2 : 1)
// See = number of visible pieces incl. the hold slot. Empty hold: current + hold slot + next (See-2 next). Hold already filled (first queue piece = held piece): every See piece is a real queue piece
const holdFilled=()=>$('uh').checked&&!$('he').checked;
function updSeeHint(){
  const el=$('hintSee');if(!el) return;const v=Math.floor(+$('see').value)||0,uh=$('uh').checked;
  if(!v){el.textContent=L('전체 피스를 다 보는 계산','Sees every piece');return;}
  if(!uh){el.textContent=L(`현재 1 + 넥스트 ${Math.max(0,v-1)}`,`current 1 + next ${Math.max(0,v-1)}`);return;}
  el.textContent=holdFilled()?L(`홀드 1 + 현재 1 + 넥스트 ${Math.max(0,v-2)} (7피스 전부 보임: ${v}≥7이면 전체와 동일)`.replace(/ \(7피스.*$/,''),`hold 1 + current 1 + next ${Math.max(0,v-2)}`)
                        :L(`홀드 칸 비어 있음 + 현재 1 + 넥스트 ${Math.max(0,v-2)}`,`empty hold + current 1 + next ${Math.max(0,v-2)}`);
}
const seeOff=()=>$('uh').checked&&!holdFilled()?2:1;
const pct=x=>{if(x>=1-1e-9) return '100%';const p=x*100;let d=2;while(d<8&&(p.toFixed(d)==='100.'+'0'.repeat(d)||(p>0&&+p.toFixed(d)===0))) d++;return p.toFixed(d)+'%';};   // never round a non-certain result up to 100% (or down to 0%)
let shapes=[],multi=false,curQ='',total=0,effLen=0,stopHandler=null;
$('stop').onclick=()=>{if(stopHandler) stopHandler();};
const PROG={scan:['1/3단계 scan: 피스를 한 개씩 놓아 보드를 넓힙니다','Stage 1/3 scan: placing pieces one at a time'],cull:['2/3단계 cull: PC로 이어지지 않는 보드를 지웁니다','Stage 2/3 cull: dropping boards that cannot reach a PC'],place:['3/3단계 place: 남은 보드로 해법을 만듭니다','Stage 3/3 place: building the solutions'],orders:['해법별 지원 큐 계산','Finding the supporting queues of each solution'],eval:['넥스트별 성공 여부 확인','Checking every queue']};
const progText=(p)=>{
  const ph=PROG[p.ph]||['준비 중','Preparing'];
  const d=(p.ph==='scan'||p.ph==='place')?[` · ${p.si||0}/${p.sn||0}피스 · 보드 ${(p.boards||0).toLocaleString()}개`,` · piece ${p.si||0}/${p.sn||0} · ${(p.boards||0).toLocaleString()} boards`]
    :p.ph==='orders'?[` · ${p.si||0}/${p.sn||0}`,` · ${p.si||0}/${p.sn||0}`]
    :p.ph==='eval'?[` · 순서 ${(p.seqDone||0).toLocaleString()}/${(p.tot||total).toLocaleString()}`,` · order ${(p.seqDone||0).toLocaleString()}/${(p.tot||total).toLocaleString()}`]:['',''];
  const el=((performance.now()-runT0)/1000).toFixed(1);
  return L(`탐색 중… ${p.curN||''}피스 · ${ph[0]}${d[0]} · ${el}초`,`Searching… ${p.curN||''}-piece · ${ph[1]}${d[1]} · ${el}s`);
};
// Result of a run (a plain snapshot object, from the Worker or from the main-thread fallback)
const b2bK=R=>R.b2b&&!R.solOnly&&R.doneW?L(` · 백투백 유지 PC ${pct(R.b2bW/R.doneW)} (${R.b2bN}가지)`,` · B2B-keeping PC ${pct(R.b2bW/R.doneW)} (${R.b2bN})`):'';
// ---- setup finder result: the boards reachable after the first N placements, ranked by the chance that the queue still gets a PC from them ----
// "chance once built" runs in its own Worker (the search workers are already finished); the list is drawn first and redrawn when it arrives
let sfDenW=null,sfTok=0,sfdURL=null;
function sfDenWorkerURL(){
  if(sfdURL) return sfdURL;
  const code=engineSrc()+'self.onmessage=e=>{try{const m=e.data;setJSI(m.ji);const r=sfDen({H:m.H,rows0:m.rows0,useHold:m.useHold,spin:m.spin,u180:m.u180},m.N,m.hf,buildSeqs(parseQ(m.q)),new Set(m.keys),m.limit);self.postMessage(r?{den:[...r.den],tot:r.tot}:{den:null});}catch(err){self.postMessage({den:null});}};';
  return sfdURL=URL.createObjectURL(new Blob([code],{type:'text/javascript'}));
}
function sfDenCancel(){sfTok++;if(sfDenW){try{sfDenW.terminate();}catch(_){}sfDenW=null;}}
function sfDenStart(R,sec){
  const {P,N,hf}=lastSF,keys=R.setups.map(t=>t.k),tok=++sfTok;
  let w=null;try{w=new Worker(sfDenWorkerURL());}catch(_){}
  if(!w){let dn=null;try{dn=sfDen(P,N,hf,lastSF.seqs,new Set(keys),30000);}catch(_){}return {sync:true,dn};}   // no Workers here: compute on the page
  sfDenW=w;
  const fin=dn=>{try{w.terminate();}catch(_){}if(sfDenW===w) sfDenW=null;if(tok===sfTok) renderSetups(R,sec,dn||false);};
  w.onmessage=e=>{const m=e.data;fin(m.den?{den:new Map(m.den),tot:m.tot}:null);};
  w.onerror=ev=>{if(ev&&ev.preventDefault) ev.preventDefault();fin(null);};
  w.postMessage({ji:P.ji,q:P.q,H:P.H,rows0:P.rows0,useHold:P.useHold,spin:P.spin,u180:P.u180,N,hf,keys,limit:30000});
  return {sync:false};
}
