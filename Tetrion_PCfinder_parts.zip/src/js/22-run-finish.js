function renderSetups(R,sec,dn0){
  if(!R.sfF&&lastSF&&(lastSF.P.sfInc||lastSF.P.sfExc)) R.sfF=true;   // a single (non-split) run never went through mergeSetups, so the flag was missing
  const el=$('sfres'),N=R.sfN,base=R.doneW?R.okW/R.doneW:0;
  if(!R.setups||!R.setups.length){
    el.style.display='none';
    if(R.sfF) return st(L(`맞는 셋업 없음 · 미노 조건 또는 셋업 피스 수 변경 (${sec.toFixed(1)}초)`,`No matching setup · change the piece filter or setup count (${sec.toFixed(1)}s)`),'bad');
    return st(L(`해 없음 · 넥스트 증가 또는 홀드·스핀·180° 켜기 (${sec.toFixed(1)}초)`,`No solution · try more Next or hold/spin/180° (${sec.toFixed(1)}s)`),'bad');
  }
  // conditional chance: PC chance given that the setup is built (needs the queues that can build it, counted separately)
  let dn=dn0||null,pend=false;
  if(dn0===undefined&&lastSF&&lastSF.P.see==null&&lastSF.N===N&&R.doneW){
    const r=sfDenStart(R,sec);if(r.sync) dn=r.dn;else pend=true;
  }
  if(dn){
    for(const t of R.setups){const d=dn.den.get(t.k)||0;t.bd=dn.tot?d/dn.tot:0;t.cd=d>0?Math.min(1,(t.w/R.doneW)/t.bd):null;}
    R.setups=R.setups.filter(t=>t.cd!=null).sort((a,b)=>b.cd-a.cd||b.w-a.w);
  }
  st(L(`셋업 ${N}피스 · 전체 PC 성공 확률 ${pct(base)} · ${R.sfF?'미노 조건에 맞는 셋업 상위 '+R.setups.length+'개':'서로 다른 셋업 '+R.sfTotal.toLocaleString()+'개'} · ${sec.toFixed(1)}초`,`Setup ${N}-piece · overall PC success ${pct(base)} · ${R.sfF?'top '+R.setups.length+' setups matching the pieces':R.sfTotal.toLocaleString()+' distinct setups'} · ${sec.toFixed(1)}s`),'ok');
  el.innerHTML='';el.style.display='';
  const top=R.setups,GS=50;let gBody=null;top.forEach((s,k)=>{s.rk=k;});
  const hd=document.createElement('div');hd.className='hint';hd.style.margin='0 0 8px';
  hd.textContent=dn?L(`셋업 상위 ${top.length}개 — 그 셋업을 지었을 때의 PC 확률 순`,`Top ${top.length} setups by PC chance once the setup is built`)
    :L(`PC 확률이 높은 셋업 상위 ${top.length}개`,`Top ${top.length} setups by PC chance`)
      +(pend?L(' · 셋업을 지었을 때의 PC 확률을 계산하는 중…',' · calculating the chance once built…'):'')+(dn0===false?L(' · 지었을 때의 PC 확률 계산 실패 · 전체 확률 순',' · chance-once-built not computed · ordered by overall chance'):'');
  el.appendChild(hd);
  // piece filter: tap a piece to require it, tap again to exclude it, again to clear
  const fb=document.createElement('div');fb.style.cssText='display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:0 0 8px';
  const fst={},fcnt=document.createElement('span');fcnt.className='hint';fcnt.style.margin='0 0 0 4px';
  const listBox=document.createElement('div');
  const lbl=document.createElement('span');lbl.className='hint';lbl.style.margin='0';lbl.textContent=L('미노 검색','Pieces');fb.appendChild(lbl);
  const paintF=(x,p)=>{const s=fst[p]|0;x.textContent=p+(s===1?' ✓':'');x.style.cssText='padding:5px 10px;font-size:13px;touch-action:manipulation;border:2px solid '+COLORS[p]+(s?';background:'+COLORS[p]+';color:#000'+(s===2?';filter:brightness(.4)':''):'');};
  'IOTSZJL'.split('').forEach(p=>{const x=document.createElement('button');x.type='button';paintF(x,p);x.onclick=()=>{fst[p]=((fst[p]|0)+1)%3;paintF(x,p);render();};fb.appendChild(x);});
  fb.appendChild(fcnt);el.append(fb,listBox);
  const CS=15;
  const render=()=>{
  listBox.innerHTML='';gBody=null;
  const flt=top.filter(s=>{const has=new Set(s.pic.map(q=>q.t));for(const p in fst){if(fst[p]===1&&!has.has(p)) return false;if(fst[p]===2&&has.has(p)) return false;}return true;});
  const act=Object.values(fst).some(v=>v);
  fcnt.textContent=act?L(`${flt.length} / ${top.length}개`,`${flt.length} / ${top.length}`):'';
  if(!flt.length){const e=document.createElement('div');e.className='hint';e.textContent=L('맞는 셋업 없음','No matching setup');listBox.appendChild(e);return;}
  flt.forEach((s,k)=>{
    if(k%GS===0){   // groups of 50: a header button that folds / unfolds the group (the first one starts open)
      const g0=k,g1=Math.min(k+GS,flt.length),open0=false;
      const gh=document.createElement('button');gh.type='button';gh.className='fold';gh.style.margin='8px 0 0';
      const gb=document.createElement('div');gb.style.display=open0?'':'none';
      const setGh=o=>{gh.textContent=(o?'▾ ':'▸ ')+`#${g0+1}–${g1}`+L(` (${g1-g0}개)`,` (${g1-g0})`);gh.setAttribute('aria-expanded',o);};
      setGh(open0);
      gh.onclick=()=>{const o=gb.style.display==='none';gb.style.display=o?'':'none';setGh(o);};
      listBox.append(gh,gb);gBody=gb;
    }
    const row=document.createElement('div');row.style.cssText='display:flex;gap:12px;align-items:center;padding:6px 0;border-top:1px solid var(--line)';
    const cv=document.createElement('canvas');const HR=s.rows.length;cv.width=COLS*CS;cv.height=HR*CS;cv.style.cssText='flex:none;width:'+(COLS*CS)+'px;height:'+(HR*CS)+'px';
    const c=cv.getContext('2d');c.fillStyle='#0c0f1e';c.fillRect(0,0,cv.width,cv.height);
    const fillC=(x,y,col)=>{c.fillStyle=col;c.fillRect(x*CS+1,y*CS+1,CS-2,CS-2);};
    if(sfBase) sfBase.b.forEach((r,y)=>r.forEach((v,x)=>{if(v) fillC(x,y,(sfBase.t[y]&&sfBase.t[y][x])||COLORS.G);}));   // the starting terrain
    s.pic.forEach(q=>q.cells.forEach(([x,y])=>fillC(x,y,COLORS[q.t])));   // pieces as placed, cleared lines left in place
    const info=document.createElement('div');info.style.cssText='flex:1;min-width:0';
    const types=s.pic.map(q=>q.t).sort().join('');
    const detail=`${dn?`<div>${L('총 구축 확률','Total build chance')} <b style="color:var(--ink)">${pct(s.bd)}</b> · ${L('전체 기준 PC','Overall PC')} <b style="color:var(--ink)">${pct(s.w/R.doneW)}</b></div>`:''}<div>${types}${s.cl?L(` · 줄 삭제 ${s.cl}`,` · ${s.cl} line clear`):''}</div>`;
    info.innerHTML=`<div style="font:800 15px system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:var(--mint)">#${s.rk+1} · ${dn?pct(s.cd):pct(s.w/R.doneW)}</div><div class="hint sfd" style="margin:4px 0 0;display:none">${detail}</div>`;
    const tg=info.firstChild;tg.style.cursor='pointer';tg.insertAdjacentHTML('beforeend',`<span class="hint" style="display:block;margin:2px 0 0;font-weight:400;white-space:nowrap">${L('▸ 자세히','▸ details')}</span>`);
    tg.onclick=()=>{const d=info.querySelector('.sfd'),on=d.style.display==='none';d.style.display=on?'':'none';tg.lastChild.textContent=on?L('▾ 접기','▾ hide'):L('▸ 자세히','▸ details');};
    const b=document.createElement('button');b.type='button';b.textContent=L('보드에 적용','Use as board');
    const mkSnap=()=>{
      const bd=Array.from({length:H},(_,y)=>Array.from({length:COLS},(_,x)=>((s.rows[y]>>x)&1)?1:0)),tn=Array.from({length:H},()=>Array(COLS).fill(null));
      // colours: paint the picture (terrain + pieces, cleared lines left in place), then drop the full rows so the colours fall like the blocks
      const gr=Array.from({length:H},()=>Array(COLS).fill(null));
      if(sfBase) sfBase.b.forEach((r,y)=>r.forEach((v,x)=>{if(v&&y<H) gr[y][x]=(sfBase.t[y]&&sfBase.t[y][x])||COLORS.G;}));
      s.pic.forEach(q=>q.cells.forEach(([x,y])=>{if(y>=0&&y<H) gr[y][x]=COLORS[q.t];}));
      const keep=gr.filter(r=>!r.every(v=>v));
      while(keep.length<H) keep.unshift(Array(COLS).fill(null));
      const okT=keep.length===H&&keep.every((r,y)=>r.every((v,x)=>!!v===!!bd[y][x]));   // only trust it when it matches the real board
      if(okT) for(let y=0;y<H;y++) for(let x=0;x<COLS;x++) tn[y][x]=keep[y][x];
      return {H,board:bd,tint:tn};
    };
    // choose where the setup goes: the field being edited, an existing board (overwritten) or a new board
    b.onclick=()=>{
      if(running||SMODE) return;
      let pk=info.querySelector('.sfpick');
      if(pk){pk.remove();return;}
      pk=document.createElement('div');pk.className='sfpick';pk.style.cssText='display:flex;flex-wrap:wrap;gap:6px;margin:8px 0 0';
      const mk=(txt,color,fn)=>{const x=document.createElement('button');x.type='button';x.textContent=txt;x.style.cssText='padding:5px 10px;font-size:12px;touch-action:manipulation;border:2px solid '+color;x.onclick=()=>{if(running||SMODE) return;fn();pk.remove();};pk.appendChild(x);};
      const show=()=>{drawEd();};
      mk(L('편집 중인 보드','Current field'),'#8790b8',()=>{const sn=mkSnap();board=sn.board;tint=sn.tint;show();});
      if(suBoards&&suSets) suBoards.forEach(bd=>bd.def||!bvis(bd,false)||mk(bname(bd),suCol(suSetOfB(bd)),()=>{
        const sn=mkSnap();bd.H=sn.H;bd.board=sn.board;bd.tint=sn.tint;
        if(pcSrc===bd){loadSnap(bd);pcChips();suBorder();} else pcPick(bd);
        show();}));
      mk(L('+ 새 보드','+ New board'),'#39ff9a',()=>{const nb=pcMakeBoard(mkSnap());if(nb){pcPick(nb);show();}});
      info.appendChild(pk);
    };
    row.append(cv,info,b);gBody.appendChild(row);
  });
  };
  render();
}
function finishRun(R,stopped,sec){
  finishRun0(R,stopped,sec);
  try{chPcDone(R,stopped,sec);}catch(_){}
  try{if(!stopped&&!R.err&&R.minPending&&R.grp&&!R.minN&&lastR===R) startMin(R);}catch(_){}   // solutions first; the minimal set is computed afterwards: best-so-far shown after 1 s, final result when proven
}
function finishRun0(R,stopped,sec){
  stopRun();stopHandler=null;
  if(R.err==='TOO_MANY') return st(L(
    `경고: 확인해야 할 경우의 수가 ${R.errN.toLocaleString()}가지로 너무 많아 탐색하지 않습니다. (한도 ${MAX_CASES.toLocaleString()}가지) 넥스트를 줄이거나 [ ] 대신 고정된 피스를 쓰세요.`,
    `Warning: ${R.errN.toLocaleString()} cases to check is too many, so the search was not run (limit ${MAX_CASES.toLocaleString()}). Shorten the queue or use fixed pieces instead of [ ] groups.`
  ),'bad');
  if(R.err==='SETUP_SEE') return st(L('이 큐에서는 See 셋업 파인더 불가 · See 비우기 또는 큐 고정 필요','See setup finder unavailable for this queue · clear See or fix more of the queue'),'bad');
  if(R.err) return st(R.err,'bad');
  if(stopped){st(L('중지됨','Stopped.'));return;}
  if(R.sfN){renderSetups(R,sec);return;}
  const ns=R.ns.slice().sort((a,b)=>a-b).join('·');
  if(R.see){
    const sp=R.see.p,N=R.see.N;
    const b2bS=R.see.pB!=null?L(` · 백투백 유지 ${pct(R.see.pB)}`,` · B2B-keeping ${pct(R.see.pB)}`):'';
    const base=L(`See ${N+lastSeeOff}: ${ns}피스 PC 성공 확률 ${pct(sp)} (보이는 넥스트 ${N+lastSeeOff-lastNextOff}개 안에서 최선 선택)`,`See ${N+lastSeeOff}: ${ns}-piece PC success ${pct(sp)} (best play with ${N+lastSeeOff-lastNextOff} visible next)`);
    if(R.probOnly||!R.shapes.length){
      st(base+b2bS+` · ${sec.toFixed(1)}${L('초','s')}${R.capped?L(' · 조건이 커서 메모리 보호를 위해 확률만 계산했어요(해 목록·실패 큐 없음)',' · too large for the full analysis, so only the probability was computed (no solutions / failing queues)'):R.probOnly?L(' · 확률만 계산(해 목록·실패 큐 없음)',' · probability only (no solutions / failing queues)'):''}`,sp>0?'ok':'bad');
      if(R.fail) renderFail(R,$('fq2'));return;
    }
    st(base+b2bS+L(` · ${sec.toFixed(1)}초${ptK(R)}`,` · ${sec.toFixed(1)}s${ptE(R)}`),'ok');
    showSols(R);saveResult(R);return;
  }
  if(R.solOnly&&R.shapes.length){
    st(L(`${ns}피스 · ${sec.toFixed(1)}초${ptK(R)} · 해법만 표시 (확률·실패 큐는 계산하지 않음)`,`${ns}-piece · ${sec.toFixed(1)}s${ptE(R)} · solutions only (probabilities and failing queues are not calculated)`),'ok');
    showSols(R);saveResult(R);return;
  }
  if(R.probOnly&&R.okW){
    st(L(
      `${ns}피스 PC 성공 확률 ${pct(R.okW/R.doneW)} (순서 ${R.seqDone}가지 중 ${R.okN}가지)${b2bK(R)} · 해법 후보 ${R.solN.toLocaleString()}개 · ${sec.toFixed(1)}초${ptK(R)} · 확률만 계산(해 목록 없음)`,
      `${ns}-piece PC success ${pct(R.okW/R.doneW)} (${R.okN}/${R.seqDone} orders)${b2bK(R)} · ${R.solN.toLocaleString()} candidate solutions · ${sec.toFixed(1)}s${ptE(R)} · probability only (no solution list)`
    ),'ok');
    renderFail(R,$('fq2'));
    return;
  }
  if(R.shapes.length){
    st(L(
      `${ns}피스 PC 성공 확률 ${pct(R.okW/R.doneW)} (순서 ${R.seqDone}가지 중 ${R.okN}가지)${b2bK(R)} · ${sec.toFixed(1)}초${ptK(R)}`,
      `${ns}-piece PC success ${pct(R.okW/R.doneW)} (${R.okN}/${R.seqDone} orders)${b2bK(R)} · ${sec.toFixed(1)}s${ptE(R)}`
    ),'ok');
    showSols(R);saveResult(R);
  } else{st(L(`해 없음 · 넥스트 증가 또는 홀드·스핀·180° 켜기 (${sec.toFixed(1)}초${ptK(R)})`,`No solution. Try a longer next queue, or enable hold/spin/180°. (${sec.toFixed(1)}s${ptE(R)})`),'bad');}
}
