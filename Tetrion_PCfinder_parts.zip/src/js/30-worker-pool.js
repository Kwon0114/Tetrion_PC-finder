// ---- Worker engine -------------------------------------------------------------------------------------------
// The search runs in Web Workers built from this page's own engine code (ENGINE_START..ENGINE_END). Workers live in a small
// persistent POOL (spawned lazily, reused between runs, dropped after 30 s idle). A run is a list of tasks (one first piece each);
// idle workers pull the next task, so the load balances itself. Everything falls back to the main thread if Workers are unavailable.
function engineSrc(){
  const src=document.getElementById('app').textContent;
  // cut between two marker STATEMENTS (not comments: a minifier that strips comments would leave the workers without an engine)
  const m0='self.__ENGINE'+'_START=1',a0=src.indexOf(m0),b=src.indexOf('self.__ENGINE'+'_END=1');
  if(a0<0||b<0) throw new Error('engine');
  let a=a0+m0.length;if(src[a]===';'||src[a]===',') a++;
  return '"use strict";\nlet __KO=false;const L=(ko,en)=>__KO?ko:en;\n'+src.slice(a,b)+'\n';
}
function workerMain(){
  let o=null,gen=null,T0=0,id=0;
  const post=m=>{m.id=id;self.postMessage(m);};
  function finish(){
    try{
      if(o.solveOnly&&!o.err) post({type:'solved',sols:o.solved||[],pt:passTimes(o)});
      else post({type:'done',snap:snapshot(o),sec:(performance.now()-T0)/1000});
    }
    catch(err){post({type:'err',msg:String(err&&err.message||err)});}
    o=null;gen=null;
  }
  // a stop is a terminate() from the page, so a slice only has to run, report and reschedule
  function step(){
    if(!o) return;
    try{
      const s=performance.now();let done=false;
      while(performance.now()-s<60){if(gen.next().done){done=true;break;}}
      if(done) return finish();
      post({type:'p',pt:passTimes(o),tot:o.seqsN||0,ph:o.ph,si:o.si,sn:o.sn,boards:o.boards,curN:o.curN,seqDone:o.seqDone});
      setTimeout(step,0);
    }catch(err){post({type:'err',msg:String(err&&err.message||err)});o=null;gen=null;}
  }
  self.onmessage=e=>{
    const m=e.data;
    if(m.type!=='run') return;
    id=m.id;__KO=!!m.ko;
    try{
      const items=parseQ(m.q);
      let mass=1,seeFirsts=null;
      if(m.firsts){
        if(m.see==null){const it=items[0],sub=nodeOptions(it).filter(x=>m.firsts.includes(x.q[0]));mass=sub.reduce((a,x)=>a+x.w,0);it.opts=sub;}
        else seeFirsts=m.firsts;   // See: the queue stays whole (keeps the bag shortcuts); this part only evaluates the starts whose first piece is in firsts
      }
      if(m.dims&&m.see==null) for(const [ni,fs] of m.dims){   // queue split on further items (item ni keeps only the options whose first piece is in fs)
        const it=items[ni],sub=nodeOptions(it).filter(x=>fs.includes(x.q[0]));mass*=sub.reduce((a,x)=>a+x.w,0);it.opts=sub;
      }
      const seqs=buildSeqs(items);
      setJSI(m.ji);o={mass,seeFirsts,rows0:m.rows0,seqs,items,firsts:m.firsts||null,useHold:m.useHold,u180:m.u180,spin:m.spin,H:m.H,probOnly:m.probOnly,solOnly:m.solOnly,b2b:m.b2b,js:m.js,see:m.see,setupN:m.setupN|0,sfInc:m.sfInc|0,sfExc:m.sfExc|0,part:m.part||null,solveOnly:!!m.solveOnly,preTs:m.preTs||null,nodes:0,curN:0,seqDone:0};
      gen=search(o);T0=performance.now();
      setTimeout(step,0);
    }catch(err){post({type:'err',msg:String(err&&err.message||err)});o=null;gen=null;}
  };
  post({type:'ready'});
}
let wURL=null;
function workerURL(){
  if(wURL) return wURL;
  return wURL=URL.createObjectURL(new Blob([engineSrc()+'('+workerMain.toString()+')();'],{type:'text/javascript'}));
}
const POOL={ws:[],blocked:false,idleT:0,rid:0};   // blocked: Workers proved unusable in this page (blocked viewer / sandbox)
function poolClear(){clearTimeout(POOL.idleT);for(const s of POOL.ws){try{s.w.terminate();}catch(_){}}POOL.ws=[];}
const poolIdle=()=>{clearTimeout(POOL.idleT);POOL.idleT=setTimeout(poolClear,30000);};   // free the workers' memory when nothing runs
let curO=null;
const GH_URL='https://github.com/Kwon0114/Tetrion_PC-finder';
const parInfo=(t,c,link)=>{const e=document.getElementById('parInfo');if(e){e.textContent=t||'';e.style.color=c||'var(--mint)';
  if(link){e.appendChild(document.createTextNode(' '));const a=document.createElement('a');a.href=GH_URL;a.target='_blank';a.rel='noopener';a.textContent=GH_URL.replace('https://','');a.style.color='inherit';a.style.textDecoration='underline';e.appendChild(a);}}};
// ---- parallel run: the queues are split by their first piece (each part searches only the queues that start with its pieces), then the snapshots are merged
// duplicate solutions found by several parts: weights, clear types, B2B weight and the leftover sets (sv) of all parts are combined
function mergeSetups(S,R){   // setup finder: a setup's weight is the sum over the parts (their queues are disjoint)
  const W=new Map(),rep=new Map();
  for(const x of S){
    const a=x.sfW;if(a) for(let i=0;i<a.length;i+=2) W.set(a[i],(W.get(a[i])||0)+a[i+1]);
    for(const t of (x.setups||[])) if(!rep.has(t.k)) rep.set(t.k,t);
  }
  const arr=[...W].filter(e=>rep.has(e[0])).sort((a,b)=>b[1]-a[1]);
  R.sfN=S[0].sfN;R.sfTotal=W.size;R.sfF=!!(S[0].sfInc||S[0].sfExc);R.setups=arr.slice(0,300).map(([k,w])=>({...rep.get(k),w}));
}
function mergeSnaps(S){
  if(S.length===1) return S[0];
  const bad=S.find(x=>x.err);if(bad) return bad;
  if(S.some(x=>x.see)) return mergeSee(S);
  const R={...S[0]};
  R.pt=[0,1,2,3,4].map(i=>{const v=S.map(x=>x.pt&&x.pt[i]).filter(x=>x!=null);return v.length?Math.max(...v):null;});
  for(const k of ['okW','okN','b2bW','b2bN','doneW','seqDone','tot','solN']) R[k]=S.reduce((a,x)=>a+(x[k]||0),0);
  R.solN=Math.round(R.solN/S.length);   // every part found (mostly) the same solutions: the shown candidate count = sum / number of parts
  if(S[0].js) R.js={tio:!!S[0].js.tio,b2b:S[0].js.b2b,pre:S[0].js.pre||0,cb:S[0].js.cb||0,sum:S.reduce((a,x)=>a+(x.js?x.js.sum:0),0),w:S.reduce((a,x)=>a+(x.js?x.js.w:0),0),us:S.reduce((a,x)=>a+(x.js?x.js.us:0),0),un:S.reduce((a,x)=>a+(x.js?x.js.un:0),0),max:Math.max(...S.map(x=>x.js?x.js.max:0)),min:Math.min(...S.map(x=>x.js&&x.js.min!=null?x.js.min:Infinity))};
  if(R.js){   // score groups and clear-type masks of every part (weights are absolute, so they just add up)
    const gm=new Map(),em=new Map(),ep=new Map(),ec=[],eq=new Map(),epc=new Map();
    for(const x of S) if(x.js){
      for(const [sc,g] of (x.js.grp||[])){let a=gm.get(sc);if(!a){a={n:0,w:0,list:[],pl:[]};gm.set(sc,a);}a.n+=g.n;a.w+=g.w;for(const q of g.list) a.list.push(q);for(const p of (g.pl||[])) if(a.pl.length<150) a.pl.push(p);}
      for(const [m,w] of (x.js.ev||[])) em.set(m,(em.get(m)||0)+w);
      for(const [k,w] of (x.js.evp||[])) ep.set(k,(ep.get(k)||0)+w);
      for(const [k,w] of (x.js.evq||[])) eq.set(k,(eq.get(k)||0)+w);
      for(const [k,w] of (x.js.evpc||[])) epc.set(k,(epc.get(k)||0)+w);
      (x.js.evc||[]).forEach((l,k)=>{const mp=ec[k]||(ec[k]=new Map());for(const [c,w] of l) mp.set(c,(mp.get(c)||0)+w);});
    }
    R.js.grp=[...gm].sort((a,b)=>b[0]-a[0]);R.js.ev=[...em];R.js.evp=[...ep];R.js.evc=Array.from({length:8},(_,k)=>[...(ec[k]||[])]);R.js.evq=[...eq];R.js.evpc=[...epc];
  }
  R.ns=[...new Set(S.flatMap(x=>x.ns||[]))].sort((a,b)=>a-b);
  const key=sh=>sh.pic.map(p=>p.t+p.cells.map(c=>c.join(':')).sort().join(',')).sort().join('|');
  const gmap=new Map(),shapes=[],loc=[];
  for(const x of S){
    const m=[];
    (x.shapes||[]).forEach((sh,i)=>{
      const k=key(sh);let g=gmap.get(k);
      if(g===undefined){g=shapes.length;gmap.set(k,g);shapes.push({...sh,mn:0,mg:0,bn:0,bg:0});}
      else{shapes[g].w+=sh.w;shapes[g].ev=(shapes[g].ev||0)|(sh.ev||0);if(sh.evc) shapes[g].evc=shapes[g].evc?shapes[g].evc.map((v,k)=>Math.max(v,sh.evc[k])):sh.evc;shapes[g].evp=maxMasks([...(shapes[g].evp||[]),...(sh.evp||[])]);if(sh.evpc) shapes[g].evpc=paretoVecs([...(shapes[g].evpc||[]),...sh.evpc]);shapes[g].b2w=(shapes[g].b2w||0)+(sh.b2w||0);shapes[g].sv=[...new Set([...(shapes[g].sv||[]),...(sh.sv||[])])];if(!shapes[g].bsteps&&sh.bsteps){shapes[g].bsteps=sh.bsteps;shapes[g].bq=sh.bq;}}
      m[i]=g;
    });
    loc.push(m);
  }
  R.shapes=shapes;
  if(R.js){const pqs=[];let over=false;S.forEach((x,xi)=>{if(!x.js) return;if(x.js.pqo||!x.js.pq){over=true;return;}for(const [w,a] of x.js.pq) pqs.push([w,a.map(([i,v,e])=>[loc[xi][i],v,e])]);});R.js.pqo=over||pqs.length>400000;R.js.pq=R.js.pqo?null:pqs;}
  const gl=[];
  S.forEach((x,xi)=>{if(x.grp) for(const [es,w] of x.grp) gl.push([es.map(i=>loc[xi][i]),w]);});
  R.grp=gl.length?gl:null;
  R.minN=0;R.minTot=0;R.minCov=0;
  R.minExact=true;R.minLB=null;R.minT=null;
  R.minPending=gl.length>0;   // computed after the solutions are shown
  {
    const g2=[];
    S.forEach((x,xi)=>{if(x.grp2) for(const [es,w] of x.grp2) g2.push([es.map(i=>loc[xi][i]),w]);});
    R.grp2=g2.length?g2:null;R.bmin=null;
    if(g2.length){
      const r=minCover(g2,i=>i===null?-1:shapes[i].sp,500);
      r.picks.forEach((p,i)=>{shapes[p.idx].bn=i+1;shapes[p.idx].bg=p.gain;});
      R.bmin={n:r.picks.length,tot:r.total,cov:r.covered,exact:r.exact};
    }
  }
  const los=S.map(x=>x.lo).filter(Boolean);
  if(los.length){
    const sets=new Map(),marg={};let okw=0;
    for(const l of los){
      for(const [k,w] of l.sets) sets.set(k,(sets.get(k)||0)+w);
      for(const c in l.marg) marg[c]=(marg[c]||0)+l.marg[c];
      okw+=l.okw;
    }
    R.lo={sets:[...sets],marg,okw};
  } else R.lo=null;
  const fs=S.map(x=>x.fail).filter(Boolean);
  if(fs.length){
    const list=[];let n=0,w=0;
    for(const f of fs){n+=f.n;w+=f.w;for(const it of f.list) list.push(it);}
    R.fail={n,w,list,cap:false};
  } else R.fail=null;
  if(S[0].sfN) mergeSetups(S,R);
  return R;
}
// See under a parallel split: each part's See numbers are conditional on its own first pieces, so they are weighted by the part's probability mass
// (parts without a See result have no solution: probability 0, their numbers are already absolute weights). The merged minimal set is the union
// of the parts' minimal sets, ordered by how often the best play uses them.
function mergeSee(S){
  const R={...S[0]};
  const ms=S.map(x=>x.mass==null?1:x.mass),fs=S.map((x,i)=>x.see?ms[i]:1);
  R.pt=[0,1,2,3,4].map(i=>{const v=S.map(x=>x.pt&&x.pt[i]).filter(x=>x!=null);return v.length?Math.max(...v):null;});
  for(const k of ['seqDone','tot','solN']) R[k]=S.reduce((a,x)=>a+(x[k]||0),0);
  R.solN=Math.round(R.solN/S.length);   // same as in mergeSnaps
  R.ns=[...new Set(S.flatMap(x=>x.ns||[]))].sort((a,b)=>a-b);
  let p=0;S.forEach((x,i)=>{if(x.see) p+=ms[i]*x.see.p;});p=Math.min(1,p);
  const first=S.find(x=>x.see);
  R.see={N:first.see.N,p,minLimit:S.some(x=>x.see&&x.see.minLimit)};
  if(S.some(x=>x.see&&x.see.pB!=null)){let pb=0;S.forEach((x,i)=>{if(x.see&&x.see.pB!=null) pb+=ms[i]*x.see.pB;});R.see.pB=Math.min(1,pb);}
  R.okW=p;R.doneW=1;R.solOnly=false;R.capped=S.some(x=>x.capped);
  if(S[0].sfN) mergeSetups(S,R);
  R.minN=0;R.minTot=p;R.minCov=0;R.minExact=true;R.minSkipped=false;
  R.probOnly=S.some(x=>x.probOnly);
  if(R.probOnly){R.shapes=[];R.okN=0;R.grp=null;R.lo=null;R.fail=null;R.minTot=0;return R;}
  const key=sh=>sh.pic.map(q=>q.t+q.cells.map(c=>c.join(':')).sort().join(',')).sort().join('|');
  const gmap=new Map(),shapes=[];
  S.forEach((x,i)=>{
    if(!x.see) return;
    for(const sh of (x.shapes||[])){
      const k=key(sh);let g=gmap.get(k);
      if(g===undefined){g=shapes.length;gmap.set(k,g);shapes.push({...sh,w:0,mn:0,mg:0,_m:false});}
      const t=shapes[g];t.w+=sh.w*ms[i];
      if(sh.mn>0){t._m=true;t.mg+=sh.mg*ms[i];}
    }
  });
  const mins=shapes.filter(s=>s._m).sort((a,b)=>b.mg-a.mg||b.sp-a.sp);
  mins.forEach((s,k)=>{s.mn=k+1;});
  shapes.forEach(s=>{delete s._m;});
  R.shapes=shapes;R.okN=shapes.length;
  R.grp=shapes.length?shapes.map((s,k)=>[[k],s.w]):null;
  R.minN=mins.length;R.minCov=Math.min(1,mins.reduce((a,s)=>a+s.mg,0));
  const lo=[];S.forEach((x,i)=>{if(x.lo) lo.push([x.lo,fs[i]]);});
  if(lo.length){
    const sets=new Map(),marg={};let okw=0;
    for(const [l,f] of lo){
      for(const [k,w] of l.sets) sets.set(k,(sets.get(k)||0)+w*f);
      for(const c in l.marg) marg[c]=(marg[c]||0)+l.marg[c]*f;
      okw+=l.okw*f;
    }
    R.lo={sets:[...sets],marg,okw};
  } else R.lo=null;
  const fl=S.map((x,i)=>x.fail?[x.fail,fs[i]]:null).filter(Boolean);
  if(fl.length){
    const list=[];let n=0,w=0;
    for(const [f,c] of fl){n+=f.n;w+=f.w*c;for(const it of f.list) list.push(it);}
    R.fail={n,w,list,cap:false};
  } else R.fail=null;
  {const f2=S.map(x=>x.fail2).filter(Boolean);
   if(f2.length){const list=[];let n=0,w=0;for(const f of f2){n+=f.n;w+=f.w;for(const it of f.list) list.push(it);}R.fail2={n,w,list,cap:false};}else R.fail2=null;}
  return R;
}
const blockedMsg=()=>parInfo(L('워커 0개 (메인 스레드로 계산)','0 workers (computing on the main thread)'),'var(--gold)');
// Run a plan on up to K pooled workers. plan.tasks = extra run fields per task ({} = the whole search, {firsts:'IO'} = queues starting with those pieces,
// {part,solveOnly} = one part of the board split). plan.phase2(results) (optional) turns the finished tasks into one last task for a single worker
// ({extra, merge(R)}). Idle workers pull the next task. Returns false when no worker can be used.
function runPool(P,seqs,plan,K,retried){
  if(POOL.blocked) return false;
  clearTimeout(POOL.idleT);
  let tasks=plan.tasks;
  const want=Math.min(K,tasks.length);
  while(POOL.ws.length<want){
    try{POOL.ws.push({w:new Worker(workerURL()),alive:false,job:-1,jid:-1});}catch(_){break;}
  }
  if(!POOL.ws.length){POOL.blocked=true;blockedMsg();return false;}
  for(const s of POOL.ws.splice(want)) try{s.w.terminate();}catch(_){}
  const slots=POOL.ws.slice(),k=slots.length,rid=++POOL.rid*64;
  let n=tasks.length,results=new Array(n),prog=new Array(n).fill(null),next=0,finished=0,dead=false,lastRep=0,phase=1,merge=null;
  const ORD=['scan','cull','place','orders','eval'],t0=performance.now();
  const sum=(a,key)=>a.reduce((t,x)=>t+(x[key]||0),0);
  const report=()=>{
    const t=performance.now();if(!running||dead||t-lastRep<80) return;lastRep=t;
    const all=prog.filter(Boolean),act=prog.filter((p,i)=>p&&!results[i]);if(!all.length) return;
    const base=(act.length?act:all).reduce((a,b)=>ORD.indexOf(b.ph)<ORD.indexOf(a.ph)?b:a);
    st(progText({...base,boards:sum(act,'boards'),seqDone:sum(all,'seqDone'),tot:sum(all,'tot')})+(k>1&&phase===1?L(` · ${k}개 병렬`,` · ${k} parallel`):''));
  };
  const assign=s=>{
    if(dead||next>=n){s.job=-1;return;}
    const i=next++;s.job=i;s.jid=rid+i;
    s.w.postMessage({type:'run',id:s.jid,ko:L(true,false),...P,...tasks[i]});
  };
  const abort=()=>{dead=true;poolClear();};
  stopHandler=()=>{if(dead) return;abort();parInfo('');finishRun({},true,0);};   // terminate() is instant, no snapshot needed
  slots.forEach(s=>{
    s.w.onmessage=e=>{
      const m=e.data;s.alive=true;
      if(dead||m.type==='ready'||m.id!==s.jid) return;
      const i=s.job;
      if(m.type==='p'){prog[i]=m;report();}
      else if(m.type==='done'||m.type==='solved'){
        if(m.type==='done'&&phase===1&&plan.phase2){   // a part ended with an error / limit: show it as it is
          dead=true;poolIdle();parInfo('');finishRun(m.snap,false,(performance.now()-t0)/1000);return;
        }
        results[i]=m.type==='solved'?m:m.snap;if(prog[i]) prog[i]={...prog[i],seqDone:prog[i].tot||prog[i].seqDone};s.job=-1;
        if(++finished===n){
          if(phase===1&&plan.phase2){
            const p2=plan.phase2(results);merge=p2.merge;phase=2;
            tasks=[p2.extra];n=1;results=new Array(1);prog=[null];next=0;finished=0;lastRep=0;
            assign(s);   // the worker that finished last runs the final phase (orders / queue check) on the merged solutions
          } else{
            dead=true;poolIdle();
            parInfo(L(`워커 ${k}개로 실행함`,`Ran on ${k} workers`));
            finishRun(merge?merge(results[0]):mergeSnaps(results),false,(performance.now()-t0)/1000);
          }
        } else assign(s);
      }
      else if(m.type==='err'){abort();parInfo('');stopRun();stopHandler=null;st(m.msg,'bad');}
    };
    s.w.onerror=ev=>{
      if(ev&&ev.preventDefault) ev.preventDefault();
      if(dead) return;
      const started=slots.some(x=>x.alive);abort();
      if(!started){POOL.blocked=true;blockedMsg();runMain(P,seqs);return;}
      if(k>1&&!retried){   // a worker died mid-run (often memory): redo it one task at a time
        parInfo(L('워커 중단 → 워커 1개로 다시 계산','Worker stopped → recalculating on one worker'),'var(--gold)');
        if(!runPool(P,seqs,plan,1,true)) runMain(P,seqs);
        return;
      }
      parInfo('');stopRun();stopHandler=null;
      st(L('탐색 오류','An error occurred during the search.')+(ev&&ev.message?` (${ev.message})`:''),'bad');
    };
  });
  parInfo(L(`워커 ${k}개 작동 중`,`${k} workers running`));
  slots.forEach(assign);
  return true;
}
// Board-split plan: K parts search disjoint sets of solutions (scan / cull / place), then ONE worker merges them (same shape found by two parts counts once)
// and does the orders / queue check, which must see all solutions at once: a queue wins if ANY solution works for it, so those results can't be added up.
function splitPlan(K,m){
  return {
    tasks:Array.from({length:K},(_,j)=>({part:{j,K,m},solveOnly:true})),
    phase2(res){
      const seen=new Map();
      for(const r of res) for(const e of r.sols) if(!seen.has(e.k)) seen.set(e.k,e.pcs);
      const pre=[...seen.values()].map(pcs=>({pcs}));
      return {extra:{preTs:pre},merge(R){
        const pt=[0,1,2].map(i=>{const v=res.map(x=>x.pt&&x.pt[i]).filter(x=>x!=null);return v.length?Math.max(...v):null;});
        const o=R.pt||[];R.pt=[pt[0],pt[1],pt[2],o[3]==null?null:o[3],o[4]==null?null:o[4]];
        return R;
      }};
    }
  };
}
// Queue split (the original method): every task runs the whole search on its own share of the queues, then the snapshots are merged.
// A share is "first piece of item i is in this group". Works for any queue with at least two possible queues: the item with the most
// first-piece groups is split first; if that gives fewer tasks than workers, the next item is split as well (tasks = product of the groups).
// firstOnly (See): only item 0 can be split. Returns null when nothing can be split (one single possible queue).
function queueSplitPlan(seqs,cap,firstOnly){
  const dims=[];
  seqs.parts.forEach((p,i)=>{if(firstOnly&&i>0) return;const g=[...new Set(p.map(o=>o.q[0]))].sort();if(g.length>=2) dims.push({i,g});});
  dims.sort((a,b)=>b.g.length-a.g.length||a.i-b.i);
  const use=[];let prod=1;
  for(const d of dims){
    if(prod>=cap) break;
    const B=Math.min(d.g.length,Math.ceil(cap/prod)),bk=Array.from({length:B},()=>'');
    d.g.forEach((c,j)=>{bk[j%B]+=c;});
    use.push({i:d.i,bk});prod*=B;
  }
  if(prod<2) return null;
  let cells=[[]];
  for(const u of use){const nx=[];for(const c of cells) for(const b of u.bk) nx.push(c.concat([[u.i,b]]));cells=nx;}
  return cells.map(c=>{const t={},rest=[];for(const [i,b] of c){if(i===0) t.firsts=b;else rest.push([i,b]);}if(rest.length) t.dims=rest;return t;});
}
// Fallback: same search, driven in small time slices on the main thread
function runMain(P,seqs){
  const o={rows0:P.rows0,seqs,items:parseQ(P.q),useHold:P.useHold,u180:P.u180,spin:P.spin,H:P.H,probOnly:P.probOnly,solOnly:P.solOnly,b2b:P.b2b,js:P.js,see:P.see,setupN:P.setupN|0,sfInc:P.sfInc|0,sfExc:P.sfExc|0,nodes:0,curN:0,seqDone:0};
  curO=o;gen=search(o);running=true;$('go').style.display='none';$('stop').style.display='';
  const t0=performance.now();
  stopHandler=()=>{stopRun();const R=snapshot(o);stopHandler=null;finishRun(R,true,0);};
  (function tick(){
    if(!running) return;
    const s=performance.now();let done=false;
    while(performance.now()-s<14){if(gen.next().done){done=true;break;}}
    if(done){finishRun(snapshot(o),false,(performance.now()-t0)/1000);return;}
    st(progText({...o,pt:passTimes(o),tot:o.seqsN||0}));
    setTimeout(tick,0);
  })();
}
