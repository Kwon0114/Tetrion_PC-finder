let sfBase=null,lastSF=null;   // sfBase: the board the setup search started from (shown under every setup)
// the setup finder is a switch: when it is on, the normal find button searches setups instead of a PC
// piece filter chosen BEFORE the search: tap = must use (✓), tap again = must not use (✕), again = don't care
const sfMs={I:0,O:0,T:0,S:0,Z:0,J:0,L:0};
const sfMustN=()=>Object.values(sfMs).filter(v=>v===1).length;   // minos marked 'must use'
const sfCap=()=>{const v=Math.floor(+$('sfn').value);return v>=1?Math.min(v,7):7;};   // can't require more different minos than the setup has pieces
function sfMinoTrim(){let ex=sfMustN()-sfCap();if(ex<=0) return;for(const p of 'LJZSTOI'.split('')){if(ex<=0) break;if(sfMs[p]===1){sfMs[p]=0;ex--;}}sfMinoRepaint();}
function sfMinoRepaint(){const row=$('sfmino');if(!row) return;[...row.querySelectorAll('button')].forEach((x,i)=>{if(x.id!=='sfmc') sfMinoPaint(x,'IOTSZJL'[i]);});}
function sfMask(v){let m=0;'IOTSZJL'.split('').forEach((p,i)=>{if(sfMs[p]===v) m|=1<<i;});return m;}
const sfMinoPaint=(x,p)=>{const v=sfMs[p];x.textContent=p+(v===1?' ✓':'');x.style.cssText='padding:0 12px;min-width:44px;touch-action:manipulation;border:2px solid '+COLORS[p]+(v?';background:'+COLORS[p]+';color:#000'+(v===2?';filter:brightness(.4)':''):'');};   // used and excluded look the same (filled); excluded is just darker
(()=>{const row=$('sfmino');'IOTSZJL'.split('').forEach(p=>{const x=document.createElement('button');x.type='button';x.title=L('눌러서 사용 필수 → 사용 금지 → 해제','Tap: must use → must not use → off');sfMinoPaint(x,p);x.onclick=()=>{let v=(sfMs[p]+1)%3;if(v===1&&sfMustN()>=sfCap()) v=2;sfMs[p]=v;sfMinoPaint(x,p);};row.appendChild(x);});
  const c=document.createElement('button');c.type='button';c.id='sfmc';c.textContent=L('해제','Clear');c.onclick=()=>{for(const p in sfMs) sfMs[p]=0;sfMinoRepaint();};row.appendChild(c);})();
$('sfn').addEventListener('input',sfMinoTrim);$('sfn').addEventListener('change',sfMinoTrim);
const sfSync=()=>{$('sfn').disabled=!$('sfon').checked;$('sfn').style.opacity=$('sfon').checked?'':'.45';$('sfmino').style.display=$('sfon').checked?'':'none';};
$('sfon').addEventListener('change',sfSync);sfSync();
$('go').onclick=()=>{
  stopMx();minOnly=false;b2bOnly=false;
  let sfN=0;lastSF=null;sfDenCancel();$('sfres').style.display='none';
  if($('sfon').checked){
    const v=Math.floor(+$('sfn').value);
    if(!(v>=1)||v>9) return st(L('셋업 피스 수: 1~9','Enter a setup piece count between 1 and 9.'),'bad');
    sfN=v;sfMinoTrim();
  }
  if(sfN){
    sfBase={b:board.map(r=>r.slice()),t:tint.map(r=>r.slice())};
  }
  let seqs;
  try{seqs=buildSeqs(parseQ($('q').value));}catch(e){return st(e.message,'bad');}
  if(!seqs.len) return st(L('넥스트를 입력해야 합니다. (I O T S Z J L, [ ] 안은 순서 무관)','Enter a next queue. (I O T S Z J L, [ ] for any order)'),'bad');
  const rows0=toRows();
  const f=rows0.reduce((a,v)=>a+popc(v),0);
  if(H>MAXL){
    let hi=0;for(let y=0;y<H-MAXL;y++) hi+=board[y].reduce((a,v)=>a+(v?1:0),0);
    if(hi) return st(L(`맨 아래 ${MAXL}줄 위(위쪽 ${H-MAXL}줄)에 블록 ${hi}칸이 있어 탐색 불가. 블록을 ${MAXL}줄 안으로 옮기거나 높이를 ${MAXL} 이하로 설정`,`${hi} block(s) sit above the bottom ${MAXL} rows, which can't be searched. Move them into the bottom ${MAXL} rows or lower the height to ${MAXL} or less.`),'bad');
  }
  {const Hs=Math.min(H,MAXL);if(sfN&&f%2===0&&(10*Hs-f)%4===0&&sfN>=(10*Hs-f)/4) return st(L(`셋업 피스 수(${sfN})는 PC 필요 피스 수(${(10*Hs-f)/4}) 미만이어야 함`,`The setup piece count (${sfN}) must be smaller than the pieces the PC needs (${(10*Hs-f)/4}).`),'bad');}
  {const T=10*Math.min(H,MAXL)-f;   // cells the pieces must fill: 4n = 10*rows - filled
   if(T<0||T%4) return st(L(`이 보드(${f}칸, 높이 ${Math.min(H,MAXL)})로는 퍼펙트 클리어 불가 (채운 칸 + 4×피스 수 = ${10*Math.min(H,MAXL)} 필요)`,`A perfect clear is impossible on this board (${f} filled, height ${Math.min(H,MAXL)}): filled + 4×pieces must equal ${10*Math.min(H,MAXL)}. Change the cells or the height.`),'bad');
   if(T/4>seqs.len) return st(L(`넥스트가 부족합니다. 이 보드는 피스 ${T/4}개가 필요한데 입력은 ${seqs.len}개입니다.`,`The queue is too short: this board needs ${T/4} pieces but only ${seqs.len} were entered.`),'bad');}
  if(f%2) return st(L('퍼펙트 클리어 불가 (4n + 채운 칸 = 10의 배수 필요)','An odd cell count can\'t perfect clear. (4n + filled cells must be a multiple of 10)'),'bad');
  // only the first pieces that can affect the PC matter (hold on: n+1): cut the queue now so every shown count is the real one
  {let need=0;for(let n=1;n<=seqs.len;n++) if((f+4*n)%10===0&&(f+4*n)/10===Math.min(H,MAXL)) need=Math.max(need,Math.min($('uh').checked?n+1:n,seqs.len));
   seqs=seqs.truncate(need);effLen=need;}
  runT0=performance.now();runKey=boardKey();$('res').style.display='none';$('fq2').style.display='none';$('fmbox').style.display='none';multi=seqs.n>1;total=seqs.n;lastRows0=rows0.slice();
  const P={ji:!tioMode(),q:$('q').value,rows0,hold0:'',useHold:$('uh').checked,u180:u180v(),spin:$('usp').checked,H,probOnly:$('po').checked,solOnly:$('so').checked,b2b:$('b2b').checked,js:($('jsc').checked&&!$('so').checked)?{tio:tioMode(),b2b:jb2on(),pre:jsPreEff(),cb:jsCombo()}:null,see:$('see').value===''?null:Math.max(0,(Math.floor(+$('see').value)||0)-(lastSeeOff=seeOff(),lastNextOff=$('uh').checked?2:1,lastSeeOff))};
  // See large enough that every piece the PC can use is visible (current + N next >= pieces needed): plain full calculation, no See machinery
  if(P.see!=null&&P.see+1>=effLen) P.see=null;
  if(sfN){
    if(P.see!=null&&P.see<sfN){running=false;$('go').style.display='';$('stop').style.display='none';const typed=Math.floor(+$('see').value)||0,need=sfN+lastSeeOff;return st(L(`See(${typed}) 부족: 셋업 ${sfN}피스는 See ${need} 이상 필요 (셋업 중 보이는 피스만 사용)`,`See (${typed}) is too small. To build a ${sfN}-piece setup, set See to ${need} or more (the setup is built from the pieces you can see).`),'bad');}
    P.sfInc=sfMask(1);P.sfExc=sfMask(2);P.setupN=sfN;P.probOnly=true;P.solOnly=false;P.b2b=false;P.js=null;lastSF={P,seqs,N:sfN,hf:holdFilled()};
  }
  running=true;$('go').style.display='none';$('stop').style.display='';$('stop').textContent=L('중지','Stop');
  st(L(`탐색 준비 중… (앞 ${effLen}피스 기준 ${seqs.n.toLocaleString()}가지)`,`Preparing… (first ${effLen} pieces, ${seqs.n.toLocaleString()} cases)`));
  parInfo('');
  let plan={tasks:[{}]},K=1;
  {
    if(POOL.blocked) blockedMsg();
    else{
      const hc=navigator.hardwareConcurrency||2,mob=/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent||'')||(navigator.maxTouchPoints||0)>1;
      const nP=(10*Math.min(H,MAXL)-f)/4,gold=t=>parInfo(L('워커 1개 · ','1 worker · ')+t,'var(--gold)');
      const capQ=Math.min(mob?2:4,hc),capB=Math.min(mob?2:16,hc);   // queue split: every task repeats the pipeline, so few workers (memory); board split: one per core
      if(hc<2) gold(L('병렬 미사용: 코어 1개','Parallel off: one core'));
      else{
        const qt=queueSplitPlan(seqs,capQ,P.see!=null);
        if(qt){K=Math.min(capQ,qt.length);plan={tasks:qt};}
        else if(P.see==null&&nP>=8){K=capB;plan=splitPlan(K,4);}   // one single possible queue: nothing to split by queue, so split the boards instead
        else gold(P.see!=null?L('병렬 미사용: See 모드, 첫 피스 1가지','Parallel off: See mode, one first piece'):L('병렬 미사용: 계산이 작음','Parallel off: search too small'));
      }
    }
  }
  if(!runPool(P,seqs,plan,K)) runMain(P,seqs);
};
