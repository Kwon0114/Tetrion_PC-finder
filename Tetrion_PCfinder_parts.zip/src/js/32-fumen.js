
//FUMEN_START
// Fumen (v115) export: one page per solution, field = the finished stack coloured by piece, comment = "success % : piece order".
const FM_ALPHA='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
const FM_COLOR={I:1,L:2,O:3,Z:4,T:5,J:6,S:7,X:8};
function fumenEncode(pages){
  const out=[];let prev=new Array(240).fill(0),prevComment='';
  const push=(v,n)=>{for(let i=0;i<n;i++){out.push(FM_ALPHA[v%64]);v=Math.floor(v/64);}};
  const emit=(pg,first)=>{
    const esc=pg.comment==null?null:escape(pg.comment), changed=esc!==null&&esc!==prevComment;
    push((first?30720:0)+(changed?61440:0),3);
    if(changed){
      push(esc.length,2);
      for(let a=0;a<esc.length;a+=4){let v=0,m=1;for(let b=0;b<4;b++){v+=(a+b<esc.length?esc.charCodeAt(a+b)-32:0)*m;m*=96;}push(v,5);}
      prevComment=esc;
    }
  };
  pages.forEach((pg,i)=>{
    const f=pg.field;let k=0;
    if(f.every((v,j)=>v===prev[j])) push(8*240+239,2),push(0,1);   // field unchanged (no repeat pages)
    else while(k<240){
      const diff=f[k]-prev[k];let run=1;
      while(k+run<240&&f[k+run]-prev[k+run]===diff) run++;
      push((diff+8)*240+(run-1),2);k+=run;
    }
    emit(pg,i===0);
    // the next page's field is stored as a difference from THIS field after its completed rows are cleared (rows 0..22; row 23 = garbage row, untouched)
    const kept=[];for(let r=0;r<23;r++){const row=f.slice(r*10,r*10+10);if(!row.every(v=>v)) kept.push(row);}
    const cleared=new Array(240).fill(0);
    kept.forEach((row,j)=>{const r=23-kept.length+j;for(let x=0;x<10;x++) cleared[r*10+x]=row[x];});
    for(let x=0;x<10;x++) cleared[230+x]=f[230+x];
    prev=cleared;
  });
  return 'v115@'+out.join('');
}
// boardRows: rows0 of the searched board (BUF rows of padding on top), H rows tall, bottom row = last
function fumenFromShapes(list,label,rows0,H,BUFROWS){
  const pages=list.map(s=>{
    const field=new Array(240).fill(0);
    const set=(x,y,c)=>{const r=22-(H-1-y);if(r>=0&&r<=22&&x>=0&&x<10) field[r*10+x]=c;};   // y: 0 = top of the H-row board
    for(let y=0;y<H;y++) for(let x=0;x<10;x++) if((rows0[BUFROWS+y]>>x)&1) set(x,y,FM_COLOR.X);
    for(const q of s.pic) for(const [x,y] of q.cells) set(x,y,FM_COLOR[q.t]);
    return {field,comment:label(s)+' : '+s.q};
  });
  return fumenEncode(pages);
}
// first page's field of a v115 code -> 240 cell values (row 0 = top ... row 22 = floor row, row 23 = garbage), or null
function fumenFirstField(code){
  const m=String(code).replace(/\s+/g,'').match(/[vV]115@([A-Za-z0-9+\/?]+)/);
  if(!m) return null;
  const s=m[1].replace(/\?/g,'');let p=0;
  const pop=n=>{let v=0;for(let i=0;i<n;i++){const k=FM_ALPHA.indexOf(s[p++]);if(k<0) throw new Error('bad');v+=k*Math.pow(64,i);}return v;};
  const f=new Array(240).fill(0);let idx=0;
  while(idx<240){
    const v=pop(2),diff=Math.floor(v/240)-8,run=v%240+1;
    for(let k=0;k<run&&idx<240;k++) f[idx++]=diff;
  }
  return f;
}
// every page's field of a v115 code (terrain per page; a piece placed on a page is dropped) -> array of 240-cell fields; null if unreadable
function fumenAllFields(code){
  const m=String(code).replace(/\s+/g,'').match(/[vV]115@([A-Za-z0-9+\/?]+)/);
  if(!m) return null;
  const s=m[1].replace(/\?/g,'');let p=0;
  const pop=n=>{let v=0;for(let i=0;i<n;i++){const k=FM_ALPHA.indexOf(s[p++]);if(k<0) throw new Error('bad');v+=k*Math.pow(64,i);}return v;};
  const pages=[];let prev=new Array(240).fill(0),rep=0;
  while(p<s.length&&pages.length<400){
    let f;
    if(rep>0){f=prev.slice();rep--;}
    else{
      f=prev.slice();let idx=0,first=true,same=false;
      while(idx<240){
        const v=pop(2),diff=Math.floor(v/240)-8,run=v%240+1;
        if(first&&diff===0&&run===240) same=true;
        first=false;
        for(let k=0;k<run&&idx<240;k++){f[idx]+=diff;idx++;}
      }
      rep=same?pop(1):0;
    }
    let v=pop(3);const type=v%8;v=Math.floor(Math.floor(Math.floor(v/8)/4)/240);   // v = flags: 1 raise, 2 mirror, 4 colour, 8 comment, 16 no-lock
    if(v&8){const len=pop(2);for(let a=0;a<len;a+=4) pop(5);}
    pages.push(f);
    const kept=[];for(let r=0;r<23;r++){const row=f.slice(r*10,r*10+10);if(!row.every(x=>x)) kept.push(row);}
    prev=new Array(240).fill(0);
    kept.forEach((row,j)=>{const r=23-kept.length+j;for(let x=0;x<10;x++) prev[r*10+x]=row[x];});
    for(let x=0;x<10;x++) prev[230+x]=f[230+x];
  }
  return pages;
}
