//FUMEN_END
let lastR=null,minOnly=false,b2bOnly=false,lastRows0=null;
// pressing a save (single piece or a whole leftover set) keeps only the solutions that can leave it
let saveSel=[],saveR=null;
// a save x (leftover pieces) matches a selected item: a whole set must be equal, a single piece must be contained
const matchX=x=>saveSel.some(it=>it.t==='set'?x===it.k:x.indexOf(it.k)>=0);
const saveMatch=s=>!saveSel.length||(s.sv||[]).some(matchX);
// clear-type filter (Tetris / T-spin ...): a solution passes if some playable order of it can make at least one of the selected clears
const evMatch=s=>{const q=window.jsEvSel;if(!q||!q.size) return true;let m=0;for(const i of q) m|=1<<i;
  if(window.jsEvMode==='and'){const mn=window.jsEvMin;if(s.evpc) return s.evpc.some(v=>{for(const i of q) if(((v>>>(4*i))&15)<(mn&&mn.get(i)||1)) return false;return true;});   // all selected types (each at least its chosen count) in ONE play
    if(s.evp) return s.evp.some(M=>(M&m)===m);return ((s.ev||0)&m)===m;}   // intersection: all selected clear types in ONE play of the solution
  const mn=window.jsEvMin;   // union: a selected type counts only when the solution can do it at least jsEvMin times (1 by default)
  for(const i of q) if(((s.ev||0)>>i)&1){const c=mn&&mn.get(i)||1;if(c<=1||!s.evc||s.evc[i]>=c) return true;}
  return false;};
// ---- 저장된 결과: 보드 모양·옵션이 같으면 큐를 바꿔도 마지막 결과를 그대로 다시 보여줌 ----
const SAVED=new Map();
const boardKey=()=>toRows().join()+'|'+H+'|'+$('uh').checked+$('he').checked+'|'+u180v()+$('kmode').value+'|'+$('usp').checked+'|'+$('po').checked+$('so').checked+$('b2b').checked+$('jsc').checked+$('jb2').checked+'|'+$('jcb').value+'|'+$('q').value.replace(/\s+/g,'').toUpperCase()+'|'+$('see').value;
let runKey=null;
function saveResult(R){
  if(runKey===null||R.probOnly||!R.shapes||!R.shapes.length) return;
  SAVED.delete(runKey);SAVED.set(runKey,{R,rows0:lastRows0&&lastRows0.slice(),multi,total,effLen,statusText:$('status').textContent,statusCls:$('status').className});
  if(SAVED.size>20) SAVED.delete(SAVED.keys().next().value);
}
function restoreSaved(){
  if(running||SMODE) return;
  const e=SAVED.get(boardKey());
  if(!e){ if(lastR&&lastKeyShown!==null&&lastKeyShown!==boardKey()){$('res').style.display='none';$('fq2').style.display='none';} return; }
  if(lastKeyShown===boardKey()&&$('res').style.display==='') return;   // already showing it
  minOnly=false;b2bOnly=false;multi=e.multi;total=e.total;effLen=e.effLen;lastRows0=e.rows0;
  st(e.statusText,e.statusCls);showSols(e.R);
}
let lastKeyShown=null;
$('po').addEventListener('change',()=>{if($('po').checked) $('so').checked=false;});
$('so').addEventListener('change',()=>{if($('so').checked) $('po').checked=false;});
$('kmode').addEventListener('change',()=>{applyLang();restoreSaved();if(lastR) showSols(lastR);});
['uh','u180','usp','po','so'].forEach(id=>$(id).addEventListener('change',()=>restoreSaved()));
// the "i" buttons fold/unfold the explanation text (the one named by data-t, else the hint inside the same panel)
document.addEventListener('click',e=>{
  const b=e.target.closest&&e.target.closest('button.ib');if(!b) return;
  const t=b.dataset.t?$(b.dataset.t):(b.closest('.lo,#fq,#fq2')||document).querySelector('.hint.ex');
  if(t) t.style.display=t.style.display==='none'?'':'none';
});
