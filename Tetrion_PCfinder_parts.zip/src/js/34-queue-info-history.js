// a changed queue never recalls a saved result: hide the old one and wait for a fresh search
let qiKey='',qiSeqs=null,qiLen=0,qiExact=true,qiEst=1;
let qiWarns=[];
function updQInfo(){
  const el=$('qinfo');if(!el) return;
  const v=$('q').value;
  if(!v.trim()){el.textContent='';return;}
  try{
    if(qiKey!==v){
      const items=parseQ(v);let est=1,len=0,exact=true;
      for(const it of items){
        const e=Math.max(1,estOptions(it));est*=e;if(e>200000) exact=false;   // enumerating a huge group is too slow: show the estimate instead
        len+=(function f(x){if(x.c) return 1;const k=Math.min(x.k,x.g.length);return x.g.slice(0,k).reduce((a,e)=>a+f(e),0);})(it);
      }
      qiSeqs=exact?buildSeqs(items):null;qiLen=len;qiExact=exact;qiEst=est;qiWarns=parseQ.warns.slice();qiKey=v;
    }
    let n=qiExact?qiSeqs.n:qiEst,cut=0;
    // a board the run would refuse (same rules as the run): show why instead of the cases of the whole queue
    if(!SMODE){
      let bad=null;
      try{
        const f=toRows().reduce((x,y)=>x+popc(y),0),hh=Math.min(H,MAXL),T=10*hh-f,len=qiExact?qiSeqs.len:qiLen;
        let hi=0;if(H>MAXL) for(let y=0;y<H-MAXL;y++) hi+=board[y].reduce((x,v)=>x+(v?1:0),0);
        if(hi||T<0||T%4) bad=['이 보드로는 퍼펙트 클리어가 불가능해요','a perfect clear is impossible on this board'];
        else if(T/4>len) bad=[`넥스트 부족 (피스 ${T/4}개 필요)`,`queue too short (needs ${T/4} pieces)`];
      }catch(_){}
      if(bad){
        el.style.color='var(--gold)';el.textContent=L(`피스 ${qiLen}개 · ${bad[0]}`,`${qiLen} pieces · ${bad[1]}`);
        for(const w of qiWarns){const d=document.createElement('div');d.style.cssText='color:var(--gold);margin-top:2px';d.textContent='⚠ '+w;el.appendChild(d);}
        return;
      }
    }
    // the search only looks at the first pieces that can matter for this board (same rule as the run): count those cases
    if(qiExact&&!SMODE){
      try{
        const f=toRows().reduce((a,x)=>a+popc(x),0),hh=Math.min(H,MAXL);let need=0;
        if(f%2===0) for(let k=1;k<=qiSeqs.len;k++) if((f+4*k)%10===0&&(f+4*k)/10===hh) need=Math.max(need,Math.min($('uh').checked?k+1:k,qiSeqs.len));
        if(need>0&&need<qiSeqs.len){n=qiSeqs.truncate(need).n;cut=need;}
      }catch(_){}
    }
    const big=n>=1e6,num=n>=1e15?null:Math.round(n).toLocaleString(),pre=qiExact?'':'최대 ',preE=qiExact?'':'up to ';
    el.style.color=big?'var(--gold)':'';
    el.textContent=L(`피스 ${qiLen}개 · ${cut?`앞 ${cut}피스 기준 `:''}경우의 수 ${pre}${num||'10^15 이상'}가지`,`${qiLen} pieces · ${cut?`first ${cut} pieces: `:''}${preE}${num||'10^15+'} cases`);
    for(const w of qiWarns){const d=document.createElement('div');d.style.cssText='color:var(--gold);margin-top:2px';d.textContent='⚠ '+w;el.appendChild(d);}
  }catch(e){el.style.color='#ff6b6b';el.textContent=e.message;}
}
$('q').addEventListener('input',updQInfo);
updQInfo();
$('q').addEventListener('input',()=>{if(running) return; if(lastKeyShown!==boardKey()){$('res').style.display='none';$('fq2').style.display='none';}});
// Keep queue validation in sync when an input handler adjusts the text/caret.
const refreshQInput=el=>el.dispatchEvent(new Event('input',{bubbles:true}));
// ---- recent calculations: a drop-down next to the queue box. Every finished calculation of the current mode (PC search or build probability) is listed
//      newest first with its result. Picking one puts its inputs back (PC: board, queue and options; build: queue and hold) - the results are not stored ----
const CH_KEY='tetrionCalcHistory',CH_MAX=15;
const chGet=()=>{try{const a=JSON.parse(localStorage.getItem(CH_KEY)||'[]');return Array.isArray(a)?a.filter(e=>e&&typeof e==='object'&&typeof e.q==='string'&&(e.m==='pc'||e.m==='su')):[];}catch(_){return[];}};
function chAdd(e){
  const key=x=>JSON.stringify({...x,t:0,sec:0});
  const rest=chGet().filter(x=>key(x)!==key(e));   // the same inputs with the same result move to the top instead of piling up
  e.t=Date.now();while(rest.some(x=>x.t===e.t)) e.t++;   // t is also the entry's id in the list
  const a=[e].concat(rest).slice(0,CH_MAX);
  try{localStorage.setItem(CH_KEY,JSON.stringify(a));}catch(_){}
  qhRender();
}
function chSnapPc(){   // lower case letter = piece colour, g = grey, . = empty
  const rows=[];for(let y=0;y<H;y++){let r='';for(let x=0;x<COLS;x++) r+=board[y][x]?(tint[y][x]&&INVC[tint[y][x]]?INVC[tint[y][x]].toLowerCase():'g'):'.';rows.push(r);}
  return {m:'pc',q:$('q').value,he:$('he').checked,uh:$('uh').checked,usp:$('usp').checked,po:$('po').checked,so:$('so').checked,b2b:$('b2b').checked,jsc:$('jsc').checked,km:$('kmode').value,see:$('see').value,H,rows};
}
function chPcDone(R,stopped,sec){   // called right after a PC search finished (the board can't change while it runs, so the screen still shows its inputs)
  if(stopped||!R||R.err||R.sfN) return;
  const p=R.see&&R.see.p!=null?R.see.p:(R.doneW?(R.okW||0)/R.doneW:null);
  const sum=!(R.shapes&&R.shapes.length)&&!(R.see&&R.see.p!=null)&&!(R.probOnly&&R.doneW)?L('해 없음','no solution'):(p==null?'—':pct(p));
  chAdd({...chSnapPc(),sum,sec:Math.round(sec*10)/10});
}
function chSuDone(out,ctl,sec){
  if(ctl.stop||!out.length) return;
  const {R,T,multi}=out[0],pr=x=>T.W?x/T.W:0;
  const sum=!multi?suPct(pr(R[0].sw)):L('하나라도 ','Any ')+suPct(pr(T.any))+' · '+L('모두 ','All ')+(T.all==null?'—':suPct(pr(T.all)));
  chAdd({m:'su',q:$('q').value,he:$('he').checked,km:$('kmode').value,sum,sec:Math.round(sec*10)/10});
}
function qhRender(){
  const el=$('qhist');if(!el) return;
  const a=chGet().filter(e=>e.m===(SMODE?'su':'pc'));el.innerHTML='';
  const o0=document.createElement('option');o0.value='';o0.textContent=L('연산 기록','History');el.appendChild(o0);
  const modeTag=e=>{const k=e.km||'';return k==='js'?'JS':k==='tio'?'TT':'';};
  a.forEach(e=>{
    const d=new Date(e.t),hm=String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');
    const tag=modeTag(e),tagS=tag?tag+' · ':'';
    const o=document.createElement('option');o.value=String(e.t);
    o.textContent=hm+' · '+tagS+e.sum+' · '+(e.q.length>16?e.q.slice(0,15)+'…':e.q);
    o.title=(tag?tag+' · ':'')+e.q+(e.sec!=null?' · '+e.sec+L('초','s'):'');el.appendChild(o);
  });
  if(a.length){const oc=document.createElement('option');oc.value='__clear';oc.textContent=L('기록 지우기','Clear history');el.appendChild(oc);}
  el.disabled=!a.length;
}
$('qhist').onchange=()=>{
  const v=$('qhist').value;$('qhist').value='';if(!v||running) return;
  if(v==='__clear'){try{localStorage.removeItem(CH_KEY);}catch(_){}qhRender();return;}
  const e=chGet().find(x=>String(x.t)===v);if(!e) return;
  $('q').value=e.q;$('he').checked=!!e.he;
  if(e.m==='pc'&&!SMODE){
    const bd=e.rows.map(r=>[...r].map(c=>c==='.'?0:1)),tn=e.rows.map(r=>[...r].map(c=>c==='.'||c==='g'?null:COLORS[c.toUpperCase()]||null));
    loadSnap({H:e.H,board:bd,tint:tn});
    $('uh').checked=!!e.uh;$('usp').checked=!!e.usp;$('po').checked=!!e.po;$('so').checked=!!e.so;$('b2b').checked=!!e.b2b;$('jsc').checked=!!e.jsc;
    if(e.see!=null) $('see').value=e.see;
    if(e.km&&$('kmode').value!==e.km&&[...$('kmode').options].some(o=>o.value===e.km)){$('kmode').value=e.km;applyLang();}
    $('hint6').style.display=H>MAXL?'':'none';
  }
  refreshQInput($('q'));updOptSum();restoreSaved();
  if(SMODE){suSetSave();const t=$('sst');t.textContent=L('기록에서 큐와 홀드를 불러왔어요: ','Restored the queue and hold from history: ')+e.sum;t.className='ok';}
  else st(L('기록에서 불러왔어요: ','Restored from history: ')+e.sum+L(' (다시 실행 필요)',' (run again)'),'ok');
};
['focus','mousedown','touchstart'].forEach(ev=>$('qhist').addEventListener(ev,qhRender));   // the list follows the mode (PC / build) each time it is opened
qhRender();
// typing [ inserts ], while ] or } can wrap a preceding expression when needed
$('q').addEventListener('input',e=>{
  if(e.inputType!=='insertText'&&e.inputType!=='insertCompositionText') return;
  const el=e.target,p=el.selectionStart,v=el.value,d=e.data!=null?e.data:v[p-1];
  if(d==='['){el.value=v.slice(0,p)+']'+v.slice(p);el.setSelectionRange(p+1,p+1);refreshQInput(el);}
  else if(d===']'){
    const bf=v.slice(0,p-1);
    if((bf.match(/\[/g)||[]).length<=(bf.match(/\]/g)||[]).length){
      // no open [ for this ]. After an empty pair the letters typed since belong inside it: [][SZ -> typing ] gives [SZ].
      // Otherwise wrap the piece letters just before the ]: typing SZ] gives [SZ]
      const e0=/\[\]([IOTSZJLiotszjl]+)$/.exec(bf);
      if(e0){const s=p-1-e0[0].length;el.value=v.slice(0,s)+'['+e0[1]+']'+v.slice(p);el.setSelectionRange(s+e0[1].length+2,s+e0[1].length+2);refreshQInput(el);}
      else{
        const m=/[IOTSZJLiotszjl]+$/.exec(bf);
        if(m){const s=p-1-m[0].length;el.value=v.slice(0,s)+'['+m[0]+']'+v.slice(p);el.setSelectionRange(p+1,p+1);refreshQInput(el);}
      }
    }
  }
  else if(d==='}'){
    const bf=v.slice(0,p-1);
    if((bf.match(/\{/g)||[]).length<=(bf.match(/\}/g)||[]).length){
      const m=/((?:[IOTSZJLiotszjl]+(?: *[<>] *[IOTSZJLiotszjl]+)+(?: *, *[IOTSZJLiotszjl]+(?: *[<>] *[IOTSZJLiotszjl]+)+)*))$/.exec(bf);
      if(m){const s=p-1-m[0].length;el.value=v.slice(0,s)+'{'+m[1]+'}'+v.slice(p);el.setSelectionRange(s+m[1].length+2,s+m[1].length+2);refreshQInput(el);}
    }
  }
});
$('see').addEventListener('input',()=>{if(running) return;if(lastKeyShown!==boardKey()){$('res').style.display='none';$('fq2').style.display='none';}restoreSaved();});
