
// save probabilities when only the minimal solutions may be used: a queue group can leave the saves of the minimal solutions it can use
function loMin(R,lo0){
  const sets=new Map(),marg={};
  for(const [es,w] of R.grp){
    const ks=new Set();
    for(const k of es){const sh=R.shapes[k];if(!sh.mn) continue;for(const x of (sh.sv||[])) ks.add(x);}
    const cs=new Set();
    for(const x of ks){sets.set(x,(sets.get(x)||0)+w);for(const ch of x) cs.add(ch);}
    for(const ch of cs) marg[ch]=(marg[ch]||0)+w;
  }
  return {sets:[...sets],marg,okw:lo0.okw};
}
function renderLo(R,el0){
  const el=el0||$('lo'),lo0=R.lo;
  if(!lo0||!lo0.okw){el.style.display='none';el.innerHTML='';return;}
  const mm=minOnly&&R.grp&&R.minN,lo=mm?loMin(R,lo0):lo0;
  const chip=c=>`<span class="pc" style="background:${COLORS[c]}">${c}</span>`;
  const tot=R.doneW||1;const p=w=>pct(Math.min(1,w/tot));   // denominator = all queues (not only the successful ones)
  let h=`<h3>${L('PC 후 남는 bag 미노','Bag pieces left after the PC')}${mm?L(' · 최소 해법 기준',' · minimal solutions only'):''}<button type="button" class="ib" aria-label="${L('설명','Details')}">i</button></h3>`;
  const sets=lo.sets.slice().sort((a,b)=>b[1]-a[1]||(a[0]<b[0]?-1:1)).slice();
  // single-piece probability: chance that this piece can be left over after the PC (same basis as the sets below)
  const mg=Object.entries(lo.marg||{}).filter(([c,w])=>w>0&&COLORS[c]).sort((a,b)=>b[1]-a[1]||(a[0]<b[0]?-1:1));
  const on=(t,k)=>saveSel.some(it=>it.t===t&&it.k===k)?' on':'';
  if(mg.length) h+=`<div class="hint" style="margin:0 0 4px">${L('미노별 확률','Per piece')}</div><div class="m">`+mg.map(([c,w])=>`<button type="button" class="sv${on('one',c)}" data-t="one" data-k="${c}">${chip(c)} <b>${p(w)}</b></button>`).join('')+`</div><div class="hint" style="margin:0 0 4px">${L('조합별 확률','Per combination')}</div>`;
  h+=`<div class="ls">`+sets.map(([k,w])=>`<button type="button" class="sv${on('set',k)}" data-t="set" data-k="${k}"><b>${p(w)}</b> ${k?k.split('').map(chip).join(''):L('없음 (bag을 다 씀)','none (bag used up)')}</button>`).join('')+'</div>';
  if(saveSel.length){
    // chance that at least one of the selected saves is possible = weight of the queues whose possible saves meet the selection (overlaps counted once)
    let pu=0;for(const [es,w] of (R.grp||[])) if((mm?es.filter(k=>R.shapes[k].mn):es).some(k=>saveMatch(R.shapes[k]))) pu+=w;
    const ns=R.shapes.filter(x=>saveMatch(x)&&(!mm||x.mn)).length;
    h+=`<div class="hint" style="color:var(--mint);font-size:13px">${L(`선택 ${saveSel.length}개 중 하나라도: <b>${p(pu)}</b> · 해법 ${ns}개`,`Any of ${saveSel.length} selected: <b>${p(pu)}</b> · ${ns} solution(s)`)} <button type="button" class="sv" data-t="clr" style="padding:1px 8px">${L('선택 해제','Clear')}</button></div>`;
  }
  else h+='';
  h+=`<div class="hint ex" style="display:none">`+L(
    `PC 후 남은 피스(홀드·아직 안 쓴 bag 미노). 모든 확률은 전체 순서 기준(성공 여부 무관)입니다.${R.lim?' (해 제한 모드: 일부 조합 누락 가능)':''}`,
    `Pieces left after the PC (hold and any not-yet-spent bag pieces). All percentages are out of all queues, not only the successful ones.${R.lim?' (Limited mode: some sets may be missing.)':''}`
  )+`</div>`;
  const ls0=el.querySelector('.ls'),sc=ls0?ls0.scrollTop:0,ex0=el.querySelector('.hint.ex'),open=ex0&&ex0.style.display!=='none';
  el.innerHTML=h;el.style.display='';
  const ls1=el.querySelector('.ls');if(ls1) ls1.scrollTop=sc;
  if(open){const e1=el.querySelector('.hint.ex');if(e1) e1.style.display='';}
}
function renderFail(R,el,b2bv){
  const f=b2bv?R.fail2:R.fail;
  if(!f||!R.okW){el.style.display='none';el.innerHTML='';return;}
  const open=el.dataset.open==='1';
  const title=b2bv?L('PC는 되지만 백투백이 끊기는 큐','Queues that PC but break back-to-back'):L('PC 실패 큐','Queues with no PC');
  let h=`<h3><button type="button" class="fold" data-fold>${open?'▾':'▸'} ${title} (${f.n.toLocaleString()}${L('개','')})</button>${open&&f.n?`<button type="button" class="ib" aria-label="${L('설명','Details')}">i</button>`:''}</h3>`;
  if(open){
    if(b2bv) h+='';
    if(!f.n) h+=`<div class="hint">${b2bv?L('백투백이 끊기는 큐 없음 · PC 되는 모든 큐가 백투백 유지','No B2B-breaking queue · every PC queue keeps B2B'):L('실패하는 큐 없음 · 모든 큐 PC 가능','No failing queue · every queue can PC')}</div>`;
    else{
      h+=`<textarea readonly rows="8" style="width:100%;background:#0c0f1e;border:1px solid var(--line);color:var(--ink);font:12px monospace;padding:6px;box-sizing:border-box">`+f.list.map(([q,w])=>q).join('\n')+`</textarea>`;
      h+=`<div class="hint ex" style="display:none">${L('PC에 영향을 주는 앞쪽 피스만 표시.','Only the leading pieces that matter are shown.')}${f.cap?L(` 처음 ${f.list.length.toLocaleString()}개만 표시.`,` Only the first ${f.list.length.toLocaleString()} are shown.`):''}</div>`;
    }
  }
  el.innerHTML=h;el.style.display='';
  const fb=el.querySelector('button[data-fold]');if(fb) fb.onclick=()=>{el.dataset.open=open?'0':'1';renderFail(R,el,b2bv);};
}
// 시작 B2B = 이미 T스핀을 한 상태: 보드 높이 5줄 = SPC(T스핀 싱글 800점), 4줄 = DPC(T스핀 더블 1200점). 그 점수를 처음부터 합산하고 백투백이 켜진 채 시작한다.
function jsPre(){return H===5?800:H===4?1200:0;}
// start back-to-back only exists for SPC (5 lines) / DPC (4 lines); any other height starts with it off
const jb2on=()=>$('jb2').checked&&(H===4||H===5);
function jsPreEff(){return jb2on()?jsPre():0;}
// start combo typed by the user: 0 = no streak, N = N clears in a row already made (the next clear scores 50 x N)
function jsCombo(){return Math.min(20,Math.max(0,Math.floor(+$('jcb').value)||0));}
function jwarn(){
  const el=$('jwarn');if(!el) return;
  const jb=$('jb2'),okH=H===4||H===5;if(jb.disabled===okH){jb.disabled=!okH;jb.parentNode.style.opacity=okH?'':'.45';$('jcb').value=okH&&jb.checked?1:0;}   // start B2B (SPC/DPC) not applicable at this height -> combo 0; applicable and checked -> combo 1 (still editable)
  let t='';
  if($('jsc').checked) t=L('⚠ 소프트·하드 드롭 점수 제외','⚠ Soft/hard-drop points excluded');
  if($('jsc').checked&&$('jb2').checked){
    if(t) t+='\n';
    t+=H===5?L('⚠ 높이 5줄 = SPC: T스핀 싱글(800점) 선행, 백투백 켠 채 800점 선합산','⚠ Height 5 = SPC: counts as a T-spin single (800) already done; starts with back-to-back on, 800 added up front.')
     :H===4?L('⚠ 높이 4줄 = DPC: T스핀 더블(1200점) 선행, 백투백 켠 채 1200점 선합산','⚠ Height 4 = DPC: counts as a T-spin double (1200) already done; starts with back-to-back on, 1200 added up front.')
     :L(`⚠ 높이 ${H}줄은 SPC(5줄)·DPC(4줄)가 아니라서 시작 B2B를 쓰지 않습니다 (백투백 꺼진 채 시작).`,`⚠ Height ${H} is neither SPC (5) nor DPC (4): start back-to-back is not used (starts with it off).`);
    if(okH) t+=L(' 높이로만 판별. 선행 T스핀은 B2B 보너스 없이 기본 점수, 콤보는 시작 콤보부터 이어짐',' Decided by height only; the earlier T-spin scores at base (no B2B bonus) and the combo continues from the start combo.');
  }
  if(el.textContent!==t) el.textContent=t;
  el.style.display=t?'':'none';
}
setInterval(jwarn,400);
// ---- Jstris scoring (tetris.wiki/Jstris): single 100 / double 300 / triple 500 / quad 800, T-spin 400·800·1200·1600, mini 100·200 (mini double = T-spin double),
//      back-to-back x1.5 on difficult clears (quad, T-spin clear, mini single included); combo +50 x combo, perfect clear +3000. Soft/hard drop points are not counted.
// T-spin = a T piece that was not hard-dropped with 3 of its 4 corners filled (walls and floor count); mini when both front corners are not filled.
function jsScore(steps,det){
  const NO=[0,100,300,500,800],TS=[400,800,1200,1600,1600];
  let b2b=jb2on(),combo=jsCombo()-1,total=jsPreEff();
  steps.forEach((s,k)=>{
    const rows=s.before,B=rows.length,add={};
    for(const c of s.cs) add[c[1]]=(add[c[1]]|0)|(1<<c[0]);
    let n=0;for(const y in add) if((rows[y]|add[y])===1023) n++;
    let ts=0;
    if(s.t==='T'&&s.spin&&spinOK(s.before,'T',s.cs,u180v(),s.before.length)){
      const cs=s.cs;let ctr=null;
      for(const a of cs){let adj=0;for(const b of cs) if(Math.abs(a[0]-b[0])+Math.abs(a[1]-b[1])===1) adj++;if(adj===3){ctr=a;break;}}
      if(ctr){
        let mx=0,my=0;
        for(const d of [[1,0],[-1,0],[0,1],[0,-1]]) if(!cs.some(c=>c[0]===ctr[0]+d[0]&&c[1]===ctr[1]+d[1])){mx=d[0];my=d[1];}
        const occ=(x,y)=>x<0||x>9||y>=B||(y>=0&&((rows[y]>>x)&1)===1);
        let all=0,front=0;
        for(const dx of [-1,1]) for(const dy of [-1,1]){
          const o=occ(ctr[0]+dx,ctr[1]+dy)?1:0;all+=o;
          if(o&&(dx*-mx+dy*-my)>0) front++;
        }
        if(all>=3) ts=(front===2||spinFull(s.before,cs,u180v(),s.before.length))?2:1;
      }
    }
    const tio=tioMode();
    if(ts===1&&n>=2&&!tio) ts=2;
    const base=ts===2?(tio&&n===4?2600:TS[n]):ts===1?(tio?[100,200,400,800,1600][n]:(n===0?100:200)):NO[n];
    const difficult=n===4||(ts>0&&n>0);
    const bb=difficult&&b2b;let pts=bb?base*1.5:base;
    if(n>0){combo++;pts+=50*combo;b2b=difficult;} else combo=-1;
    const pc=k===steps.length-1;if(pc) pts+=tio?3500:3000;
    total+=pts;
    if(det){
      const nm=ts?(ts===1?L('미니 ','Mini '):'')+L('T스핀 ','T-spin ')+L(['제로','싱글','더블','트리플'][n]||'',['zero','single','double','triple'][n]||''):L(['','싱글','더블','트리플','테트리스'][n],['','Single','Double','Triple','Tetris'][n]);
      det[k]=`${nm||L('클리어 없음','No clear')}${bb?' · B2B':''}${n>0&&combo>0?L(' · 콤보 ',' · combo ')+combo:''}${pc?' · PC':''} +${Math.round(pts)}${L('점','pt')}`;
    }
  });
  return Math.round(total);
}
function renderJs(R){
  const el=$('jsbox'),dt=$('jsdet');
  dt.style.display='none';el.style.cssText='display:none;margin:0 0 10px;color:var(--gold)';el.className='hint';el.onclick=null;
  if(!$('jsc').checked||!R.shapes||!R.shapes.length){el.style.display='none';return;}
  const f=v=>Math.round(v).toLocaleString();
  const f2=v=>v.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});   // averages: 2 decimals
  if(!R.js||!!R.js.tio!==tioMode()||R.js.b2b!==jb2on()||(R.js.pre||0)!==jsPreEff()||(R.js.cb||0)!==jsCombo()){
    el.textContent=L('Jstris 평균 점수는 이 옵션(시작 B2B 포함)을 켜고 다시 찾아야 큐별로 계산 ("해법만"에서는 계산 안 함)','Turn this option on (with the same start B2B) and search again to get per-queue Jstris averages. (Not computed in "Solutions only")');
    el.style.display='';return;
  }
  if(R.js.w>0){
    let J=R.js,mm=false;
    if(minOnly&&R.minN&&J.pq&&!J.pqo){   // minimal solutions only: same box, recomputed from the minimal set
      let sw=0,sm=0,mx=0,mi=Infinity;const em=new Map();
      for(const [w,a] of J.pq){let b=-1,m=0;for(const [i,v,e] of a) if(R.shapes[i]&&R.shapes[i].mn>0){if(v>b) b=v;m|=e;}if(b>=0){b+=(J.pre||0);sw+=w;sm+=w*b;if(b>mx) mx=b;if(b<mi) mi=b;em.set(m,(em.get(m)||0)+w);}}
      if(sw>0){mm=true;J={...J,sum:sm,w:sw,max:mx,min:mi,ev:[...em],evp:null,evc:null,evq:null,evpc:null,grp:null};}
    }
    const a=J.sum/Math.max(R.doneW||0,J.w),mn=(J.min!=null&&isFinite(J.min))?f(J.min):'-';
    const EV=[['테트리스','Tetris'],['T스핀 제로','T-spin zero'],['미니 T스핀 제로','Mini T-spin zero'],['미니 T스핀 싱글','Mini T-spin single'],['T스핀 싱글','T-spin single'],['T스핀 더블','T-spin double'],['T스핀 트리플','T-spin triple'],['미니 T스핀 더블','Mini T-spin double']];
    const sel=window.jsEvSel||(window.jsEvSel=new Set()),andM=window.jsEvMode==='and'&&!mm,emin=window.jsEvMin||(window.jsEvMin=new Map());
    for(const i of [...emin.keys()]) if(!sel.has(i)) emin.delete(i);
    const den=R.doneW||J.w,pc=x=>pct(Math.min(1,x/den));
    const draw=()=>{
      const open=el.dataset.open==='1';
      const opts=(J.b2b?' · '+L('시작 B2B','start B2B')+(J.pre?` (+${J.pre})`:''):'')+(J.cb?' · '+L('시작 콤보 ','start combo ')+J.cb:'');
      let h=`<div style="display:flex;flex-wrap:wrap;align-items:baseline;gap:6px 16px"><div style="font-size:12px;color:var(--dim)">${L(M0()+' 평균 점수(해법 없는 큐는 0점)'+(mm?' · 최소 해법 '+R.minN+'개':''),M0()+' average score (queues with no solution count as 0)'+(mm?' · '+R.minN+' minimal solution(s)':''))}</div><div style="font-size:24px;font-weight:700;color:var(--gold)">${f2(a)}${L('점','')}</div>`
        +`<div style="font-size:12px;color:var(--dim)">${L('PC 되는 큐 기준 · ','PC queues only · ')}${L('최고 ','max ')}${f(J.max)} / ${L('최저 ','min ')}${mn}${opts}</div></div>`;
      h+=`<div class="lo" style="margin:10px 0 0"><div class="hint" style="margin:0 0 4px">${L('할 수 있는 클리어 종류별 확률','Chance per clear type')}</div><div class="m">`;
      EV.forEach((e,i)=>{
        let w=0;for(const [m,x] of J.ev) if((m>>i)&1) w+=x;
        if(!(w>0)){sel.delete(i);return;}   // 0%: no button at all
        h+=`<button type="button" class="sv${sel.has(i)?' on':''}" data-t="ev" data-k="${i}"><b>${pc(w)}</b> ${L(e[0],e[1])}</button>`;
      });
      h+=`</div>`;
      if(!mm) h+=`<div class="m" style="margin-top:6px"><button type="button" class="sv" data-t="evmode" role="switch" aria-checked="${andM}" style="display:inline-flex;align-items:center;gap:8px"><span style="color:${andM?'var(--dim)':'var(--mint)'};font-weight:${andM?400:700}">${L('합집합','Union')}</span><span style="position:relative;display:inline-block;width:34px;height:18px;border-radius:9px;background:${andM?'var(--mint)':'#2a3050'};transition:background .15s"><span style="position:absolute;top:2px;left:${andM?'18px':'2px'};width:14px;height:14px;border-radius:50%;background:#fff;transition:left .15s"></span></span><span style="color:${andM?'var(--mint)':'var(--dim)'};font-weight:${andM?700:400}">${L('교집합','Intersection')}</span></button></div>`;
      if(sel.size){
        let w=0;
        if(andM&&J.evpc){for(const [k,x] of J.evpc){if(!k) continue;if(k.split(',').some(t=>{const v=+t;for(const i of sel) if(((v>>>(4*i))&15)<(emin.get(i)||1)) return false;return true;})) w+=x;}}
        else if(andM&&J.evp){let m0=0;for(const i of sel) m0|=1<<i;for(const [k,x] of J.evp) if(k&&k.split(',').some(M=>((+M)&m0)===m0)) w+=x;}
        else if(!andM&&J.evq&&emin.size){for(const [k,x] of J.evq){const v=k.split(',');let hit=false;for(const i of sel) if(+v[i]>=(emin.get(i)||1)){hit=true;break;}if(hit) w+=x;}}
        else for(const [m,x] of J.ev){let hit=false;for(const i of sel) if((m>>i)&1){hit=true;break;}if(hit) w+=x;}
        const ns=R.shapes.filter(x=>saveMatch(x)&&evMatch(x)).length;
        h+=`<div class="hint" style="color:var(--mint);font-size:13px">${andM?L(`교집합: <b>${pc(w)}</b> · 해법 ${ns}개`,`Intersection: <b>${pc(w)}</b> · ${ns} solution(s)`):L(`합집합: <b>${pc(w)}</b> · 해법 ${ns}개`,`Union: <b>${pc(w)}</b> · ${ns} solution(s)`)} <button type="button" class="sv" data-t="evclr" style="padding:1px 8px">${L('선택 해제','Clear')}</button></div>`;
      }
      if(sel.size&&J.evc){
        for(const i of [...sel].sort((a,b)=>a-b)){
          const lst=(J.evc[i]||[]).slice().sort((a,b)=>a[0]-b[0]);
          const mx=lst.length?lst[lst.length-1][0]:0;
          if(mx<2){emin.delete(i);continue;}   // can only happen once: nothing more to show
          let rows='';
          for(let c=1;c<=mx;c++){
            let ex=0,ge=0;for(const [k,w] of lst){if(k===c) ex+=w;if(k>=c) ge+=w;}
            const on=(emin.get(i)||1)===c;   // click = keep only solutions that can do this type at least c times in one play (union mode)
            rows+=`<div style="display:flex;gap:10px;align-items:baseline"><button type="button" class="sv${on?' on':''}" data-t="evmin" data-k="${i}:${c}" style="min-width:44px;padding:2px 8px"><b>${c}${L('회','×')}</b></button><span style="color:var(--mint)">${L('이상 가능','at least')} <b>${pc(ge)}</b></span><span style="color:var(--dim)">${L(`최대가 ${c}회인 큐`,`queues whose max is ${c}`)} ${pc(ex)}</span></div>`;
          }
          h+=`<div style="margin-top:6px;padding:6px 10px;border:1px solid var(--line);border-radius:6px;font-size:13px"><div style="color:var(--gold);margin-bottom:2px">${L(EV[i][0],EV[i][1])} ${L('횟수별 확률 (한 번의 플레이에서)','chance by count (in one play)')}</div>${rows}</div>`;
        }
      }
      h+=`</div>`;
      if(J.grp&&J.grp.length){   // only the best score and one queue that reaches it
        const [score,g]=J.grp[0],x=g.pl&&g.pl[0];
        h+=`<div style="margin-top:10px;display:flex;flex-wrap:wrap;align-items:center;gap:8px"><span style="color:var(--gold);font-weight:700">${L('최고점','Best')} ${score.toLocaleString()}${L('점','pt')}</span>`
          +(x?`<button type="button" class="sv${window.jsPlay&&window.jsPlay.score===score&&window.jsPlay.k===0?' on':''}" data-pl="${score}:0" style="padding:3px 8px;letter-spacing:.12em">${x.q}</button>`:`<span style="letter-spacing:.12em">${g.list[0]}</span>`)+`</div>`;
      }
      el.innerHTML=h;
      const b=el.querySelector('button[data-open]');if(b) b.onclick=()=>{el.dataset.open=el.dataset.open==='1'?'0':'1';draw();};
      el.querySelectorAll('button[data-pl]').forEach(pb=>pb.onclick=()=>{const [sc,k]=pb.dataset.pl.split(':').map(Number),g=J.grp.find(x=>x[0]===sc),pl=g&&g[1].pl[k];if(pl){showPlay(pl,sc,k);draw();}});
      el.querySelectorAll('button[data-g]').forEach(gb=>gb.onclick=()=>{const k=+gb.dataset.g,go=window.jsGrpOpen;if(go.has(k)) go.delete(k);else go.add(k);draw();});
    };
    el.className='';el.style.cssText='margin:0 0 10px;padding:10px 12px;border:1px solid var(--line);border-radius:8px;background:#0c0f1e;font-size:13px';
    draw();
    return;
  }
  const sc=R.shapes.map(s=>jsScore(s.steps));
  const best=Math.max(...sc),worst=Math.min(...sc);
  let t;
  if(R.grp&&R.grp.length&&R.doneW){
    let sw=0,sm=0;
    for(const g of R.grp){let m=0;for(const k of g[0]) if(sc[k]>m) m=sc[k];sw+=g[1];sm+=g[1]*m;}
    t=L(`${M0()} 평균 점수 ${f2(sm/sw)}점 (PC 되는 큐 기준, 큐마다 가장 높은 해법 선택)`,`${M0()} average score ${f2(sm/sw)} (queues that PC, best solution per queue)`);
  } else if(R.doneW&&R.shapes.length>1){
    let sw=0,sm=0;R.shapes.forEach((s,i)=>{sw+=s.w;sm+=s.w*sc[i];});
    t=L(`${M0()} 평균 점수 ${f2(sm/sw)}점 (해법을 확률 가중 평균)`,`${M0()} average score ${f2(sm/sw)} (solutions weighted by probability)`);
  } else t=L(`${M0()} 점수 ${f(best)}점 (가장 높은 해법)`,`${M0()} score ${f(best)} (best solution)`);
  el.textContent=t+L(` · 해법 점수 최고 ${f(best)} / 최저 ${f(worst)} · 예시 순서${jb2on()?'·시작 B2B':''} 기준, T스핀은 회전 경로·3코너·5번째 킥 규칙으로 판정`,` · solution scores max ${f(best)} / min ${f(worst)} · example order${jb2on()?', start B2B':''}, T-spin uses rotation-path, 3-corner, and 5th-kick rules`);
  el.style.display='';
}
const fmLabel=s=>lastR.solOnly?'':(b2bOnly&&lastR.bmin)?pct(s.bg/lastR.bmin.tot):minOnly?pct(s.mg/lastR.minTot):pct(s.w/lastR.doneW);
var curPlay=false;
function showPlay(pl,score,k){
  curPlay=true;window.jsPlay={score,k,q:pl.q};
  curPic=pl.pic;cur=pl.steps;curQ=pl.q;step=0;stopPlay();
  [...$('sols').children].forEach(b=>(b.firstChild||b).classList.remove('on'));
  draw();
  try{$('vw').scrollIntoView({block:'center',behavior:'smooth'});}catch(_){}
}
function renderPlayDet(){
  const dt=$('jsdet');
  if(!curPlay||!cur){dt.style.display='none';return;}
  const det=[],total=jsScore(cur,det);
  dt.style.cssText='margin:0 0 10px;padding:8px 12px;border:1px solid var(--line);border-radius:8px;background:#0c0f1e;font-size:13px';
  dt.innerHTML=`<div style="color:var(--gold);font-weight:800;margin-bottom:4px">${L('최고점 플레이','Best play')} · <span style="letter-spacing:.12em">${curQ}</span> · ${total.toLocaleString()}${L('점','')}</div>`
    +cur.map((s,k)=>`<div style="color:${k===step?'var(--mint)':'var(--dim)'};${k===step?'font-weight:800':''}">${k+1}. ${s.t}${s.used?L(' (홀드)',' (hold)'):''} — ${det[k]}</div>`).join('');
}
function showSols(R){
  if(R!==saveR){saveR=R;saveSel=[];if(window.jsEvSel) window.jsEvSel.clear();if(window.jsEvMin) window.jsEvMin.clear();if(window.jsGrpOpen) window.jsGrpOpen.clear();}
  lastR=R;lastKeyShown=boardKey();$('res').style.display='';$('fq2').style.display='none';renderLo(R);renderFail(R,$('fq'),b2bOnly&&!!R.bmin);
  renderJs(R);
  let arr=R.shapes.filter(saveMatch).filter(evMatch);
  if(b2bOnly&&R.bmin) arr=arr.filter(s=>s.bn&&s.bsteps).sort((a,b)=>a.bn-b.bn).map(s=>({...s,steps:s.bsteps,q:s.bq}));
  else if(minOnly) arr=arr.filter(s=>s.mn).sort((a,b)=>a.mn-b.mn);
  else if(R.solOnly) arr.sort((a,b)=>b.sp-a.sp);
  else arr.sort((a,b)=>b.w-a.w||b.sp-a.sp);   // likelier first, then more spins
  shapes=arr;
  {const sc=$('solcnt'),nAll=R.shapes.length,nShow=arr.length,fmt=v=>v.toLocaleString();
    sc.style.display='flex';
    sc.innerHTML=`<span style="font-size:12px;color:var(--dim)">${L('서로 다른 해법','Distinct solutions')}</span><span style="font-size:28px;font-weight:800;color:var(--gold);line-height:1">${fmt(nAll)}</span><span style="font-size:13px;color:var(--gold)">${L('개','')}</span>`
      ;}
  $('mn').style.display=R.minN?'':'none';
  $('mn').textContent=minOnly?L('전체 해법 보기','Show all solutions'):L(`최소 해법 ${R.minN}개만 보기`,`Show minimal ${R.minN} solution(s) only`);
  $('mnh').textContent=R.minN?(minOnly?L(
    `성공한 순서의 ${pct(R.minCov/R.minTot)}를 ${R.minN}개로 모두 커버합니다. 앞쪽 해법일수록 더 많은 순서를 담당해요. ${R.minExact?'(엄격한 최소: 이보다 적은 조합은 없음)':'(최소 보장 못함)'}${R.minT!=null?' · 최소해 계산 '+fmtT(R.minT)+'초':''}`,
    `These ${R.minN} solutions together cover ${pct(R.minCov/R.minTot)} of successful orders. Earlier ones cover more. ${R.minExact?'(Strict minimum: no smaller set exists.)':'(Not guaranteed minimal)'}${R.minT!=null?' · minimal calc '+fmtT(R.minT)+'s':''}`
  ):''):(R.minSkipped?L('순서가 너무 많아 최소 해법 계산 생략','Too many orders — the minimal-solution calculation was skipped.'):'');
  if(R.see&&R.minN&&minOnly) $('mnh').textContent=L(`이 ${R.minN}개 해법만 써도 See 확률 ${pct(R.minCov)} 유지`,`Playing best with only these ${R.minN} solutions still gives the See probability ${pct(R.minCov)}.`);
  {const mx=$('mnx');mx.style.display=((R.minN&&R.minExact===false&&R.grp)||(mxW&&mxR===R))?'':'none';const on=mxW&&mxR===R;mx.textContent=on?mxLabel():L('제한 없이 다시 계산','Recalculate without limit');mx.style.borderColor=on?'var(--gold)':'';if(on) $('mnh').textContent=mxDetail();}
  {const bv=$('bv');bv.style.display=R.bmin?'':'none';
    if(R.bmin){
      bv.textContent=b2bOnly?L('모든 해법 보기','Show all solutions'):L(`백투백 유지 해법 ${R.bmin.n}개 보기`,`Show ${R.bmin.n} B2B-keeping solution(s)`);
      bv.style.borderColor=b2bOnly?'var(--gold)':'';
      if(b2bOnly){
        $('mnh').textContent=L(`백투백이 유지되는 PC 순서의 ${pct(R.bmin.cov/R.bmin.tot)}를 이 ${R.bmin.n}개 해법이 커버. 예시 큐와 순서는 백투백 유지 기준. ${R.bmin.exact?'(엄밀한 최소)':'(시간 제한으로 최소가 아닐 수 있음)'}`,`These ${R.bmin.n} solutions cover ${pct(R.bmin.cov/R.bmin.tot)} of the orders that keep back-to-back. The example queue and order shown keep B2B. ${R.bmin.exact?'(Strict minimum.)':'(Time limit reached: not guaranteed minimal.)'}`);
        $('mnx').style.display='none';
      }
    }}
  const box=$('sols');box.innerHTML='';
  if(!shapes.length){
    cur=null;stopPlay();$('cap').textContent=L('해당 세이브의 해법 없음','No solution for this save.');$('cap').style.color='';
    vw.getContext('2d').clearRect(0,0,vw.width,vw.height);return;
  }
  shapes.forEach((s,i)=>{
    const b=document.createElement('button');b.className='sol';
    b.innerHTML=(b2bOnly&&R.bmin?`<b>#${s.bn} +${pct(s.bg/R.bmin.tot)}</b> `:minOnly?`<b>#${s.mn} +${pct(s.mg/R.minTot)}</b> `:(R.solOnly?'':`<b>${pct(s.w/R.doneW)}</b> `))+s.steps.map(p=>`<span class="pc${!multi&&p.used?' h':''}${!multi&&p.spin?' s':''}" style="background:${COLORS[p.t]}">${p.t}</span>`).join('');
    b.style.flex='1';b.style.minWidth='0';b.onclick=()=>pick(i);
    const wr=document.createElement('div');wr.style.cssText='display:flex;gap:6px;align-items:stretch';
    const cb=document.createElement('button');cb.type='button';const IC='<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="1"/><path d="M5 15V5a1 1 0 0 1 1-1h10"/></svg>',CK='<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="var(--mint)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';cb.innerHTML=IC;cb.title=L('이 해법의 후멘 복사','Copy this solution as fumen');cb.setAttribute('aria-label',cb.title);cb.style.cssText='padding:4px 10px;flex:none;display:flex;align-items:center;justify-content:center;min-width:40px';
    cb.onclick=e=>{e.stopPropagation();if(!lastRows0) return;
      const code=fumenFromShapes([s],fmLabel,lastRows0,H,BUF);
      const done=()=>{cb.innerHTML=CK;setTimeout(()=>{cb.innerHTML=IC;},1500);};
      const fb=()=>{const box=$('fmbox');box.value=code;box.style.display='';box.select();try{document.execCommand('copy');done();}catch(_){}};
      if(navigator.clipboard&&navigator.clipboard.writeText) navigator.clipboard.writeText(code).then(done,fb);else fb();};
    wr.append(b,cb);box.appendChild(wr);
  });
  pick(0);
}
$('mn').onclick=()=>{minOnly=!minOnly;if(minOnly) b2bOnly=false;if(lastR) showSols(lastR);};
$('bv').onclick=()=>{b2bOnly=!b2bOnly;if(b2bOnly) minOnly=false;if(lastR) showSols(lastR);};
$('jb2').addEventListener('change',()=>{$('jcb').value=$('jb2').checked?1:0;});   // start B2B on presets the start combo to 1, off presets 0 (still editable)
for(const id of ['jsc','jb2','jcb']) $(id).addEventListener('change',()=>{$('jsopt').style.display=$('jsc').checked?'':'none';jwarn();if(lastR) showSols(lastR);});
