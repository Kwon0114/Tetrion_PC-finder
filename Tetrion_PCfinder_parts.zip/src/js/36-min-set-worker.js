// minimal-solution search ran into its time limit: run it again in its own Worker with no limit (can be cancelled)
let mxW=null,mxURL=null,mxT0=0,mxTimer=null,mxR=null,mxP=null;
const mxLabel=()=>L(`계산 중… ${Math.floor((performance.now()-mxT0)/1000)}초 (누르면 취소)`,`Calculating… ${Math.floor((performance.now()-mxT0)/1000)}s (tap to cancel)`);
function minWorkerURL(){
  if(mxURL) return mxURL;
  const code=engineSrc()+'self.onmessage=e=>{try{const {gl,sps}=e.data;const g=minCoverG(gl,i=>i===null?-1:sps[i],Infinity);let r,last=0;while(!(r=g.next()).done){const t=performance.now();if(t-last>300){last=t;self.postMessage({p:r.value});}}self.postMessage(r.value);}catch(err){self.postMessage({err:String(err&&err.message||err)});}};';
  return mxURL=URL.createObjectURL(new Blob([code],{type:'text/javascript'}));
}
const mxDetail=()=>mxP?L(`현재 최선 ${mxP.best}개 · 최소 ${mxP.lb}개 이상 · 탐색 ${mxP.nodes.toLocaleString()}회${mxP.rn?` · 첫 분기 ${mxP.rb}/${mxP.rn}`:''} · 경과 ${((performance.now()-mxT0)/1000).toFixed(1)}초 (최선이 하한과 같아지면 확정)`,`Best so far ${mxP.best} · at least ${mxP.lb} · ${mxP.nodes.toLocaleString()} nodes${mxP.rn?` · top branch ${mxP.rb}/${mxP.rn}`:''} · ${((performance.now()-mxT0)/1000).toFixed(1)}s elapsed (done when best = lower bound)`):L('시작하는 중…','Starting…');
function stopMx(){if(mxW){try{mxW.terminate();}catch(_){}mxW=null;}clearInterval(mxTimer);mxTimer=null;mxP=null;}
function applyMx(R,r,exact=true){
  R.minPending=false;if(mxT0) R.minT=(performance.now()-mxT0)/1000;
  try{if(lastR===R&&R.minT!=null){const se=$('status'),t=se.textContent;{const n=t.replace(/ · 최소해 [\d.]+초| · minimal [\d.]+s/,'').replace(/(place [\d.]+초)/,'$1 · 최소해 '+fmtT(R.minT)+'초').replace(/(place [\d.]+s)/,'$1 · minimal '+fmtT(R.minT)+'s');if(n!==t) se.textContent=n;}}}catch(_){}
  R.shapes.forEach(x=>{x.mn=0;x.mg=0;});
  r.picks.forEach((p,i)=>{const x=R.shapes[p.idx];x.mn=i+1;x.mg=p.gain;});
  R.minN=r.picks.length;R.minTot=r.total;R.minCov=r.covered;R.minExact=exact;R.minLB=exact?r.picks.length:(r.lb!=null?r.lb:(mxP&&mxP.lb?mxP.lb:R.minLB));
  if(lastR===R) showSols(R);
}
// same computation on the page itself, in small time slices (used when a Worker can't be started)
function runMxMain(R){
  let stop=false;const me={terminate(){stop=true;}};mxW=me;mxR=R;
  const g=minCoverG(R.grp,i=>i===null?-1:R.shapes[i].sp,Infinity);
  (function tick(){
    if(stop||mxW!==me) return;
    const t=performance.now();let r=null;
    while(performance.now()-t<20){r=g.next();if(r.done) break;if(r.value) mxP={...r.value};}
    if(r&&r.done){stopMx();applyMx(R,r.value);}else setTimeout(tick,0);
  })();
}
$('mnx').onclick=()=>{
  if(mxW&&mxR===lastR){
    // stop: keep the best set found so far (if it beats the current one), not guaranteed minimal
    const R0=lastR,p=mxP;stopMx();
    if(p&&p.ids&&p.ids.length&&(!R0.minN||p.ids.length<R0.minN)) {const rr=coverOrder(R0.grp,i=>i===null?-1:R0.shapes[i].sp,p.ids);rr.lb=p.lb;applyMx(R0,rr,false);}
    else showSols(R0);
    return;
  }
  startMin(lastR);
};
function startMin(R){
  stopMx();
  if(!R||!R.grp) return;
  mxT0=performance.now();
  mxP=null;mxTimer=setInterval(()=>{if(mxW&&mxR===lastR&&!R.minN&&performance.now()-mxT0>=1000&&mxP&&mxP.ids&&mxP.ids.length){const rr=coverOrder(R.grp,i=>i===null?-1:R.shapes[i].sp,mxP.ids);rr.lb=mxP.lb;applyMx(R,rr,false);stopMx();showSols(R);return;}   // after 4 s: show the best set so far as an approximation and stop (the 'Recalculate without limit' button continues)
    if(mxW&&mxR===lastR){$('mnx').textContent=mxLabel();$('mnh').textContent=mxDetail();}},500);
  let w=null;
  try{w=new Worker(minWorkerURL());}catch(_){w=null;}
  if(!w) runMxMain(R);
  else{
    mxW=w;mxR=R;
    const fallback=()=>{if(mxW!==w) return;try{w.terminate();}catch(_){}mxW=null;runMxMain(R);};
    w.onmessage=e=>{
      if(mxW!==w) return;
      const r=e.data;
      if(r&&r.p){mxP=r.p;return;}
      if(!r||r.err||!r.picks) return fallback();
      stopMx();applyMx(R,r);
    };
    w.onerror=ev=>{if(ev&&ev.preventDefault) ev.preventDefault();fallback();};
    w.postMessage({gl:R.grp,sps:R.shapes.map(x=>x.sp)});
  }
  showSols(R);
}
document.addEventListener('click',e=>{
  const b=e.target.closest&&e.target.closest('button.sv');if(!b||!lastR||!b.dataset.t) return;   // only the save / clear-type chips (data-t) belong here; queue-replay buttons (data-pl) and setup chips (data-c) have their own handlers
  const t=b.dataset.t,k=b.dataset.k;
  if(t==='evmode'){window.jsEvMode=window.jsEvMode==='and'?'or':'and';showSols(lastR);return;}
  if(t==='ev'||t==='evclr'){const q=window.jsEvSel||(window.jsEvSel=new Set());const em=window.jsEvMin||(window.jsEvMin=new Map());if(t==='evclr'){q.clear();em.clear();}else{const i=+k;if(q.has(i)){q.delete(i);em.delete(i);}else q.add(i);}showSols(lastR);return;}
  if(t==='evmin'){const [i,c]=k.split(':').map(Number),q=window.jsEvSel||(window.jsEvSel=new Set()),em=window.jsEvMin||(window.jsEvMin=new Map());q.add(i);if(c<=1||em.get(i)===c) em.delete(i);else em.set(i,c);showSols(lastR);return;}
  if(t==='clr') saveSel=[];
  else{const i=saveSel.findIndex(it=>it.t===t&&it.k===k);if(i>=0) saveSel.splice(i,1);else saveSel.push({t,k});}
  showSols(lastR);
});
