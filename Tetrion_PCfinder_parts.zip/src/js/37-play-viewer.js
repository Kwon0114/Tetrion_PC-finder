let curPic=null;
function pick(i){
  curPlay=false;window.jsPlay=null;curPic=shapes[i].pic;cur=shapes[i].steps;curQ=shapes[i].q;step=0;stopPlay();
  [...$('sols').children].forEach((b,j)=>(b.firstChild||b).classList.toggle('on',i===j));
  draw();
}
function draw(){
  renderPlayDet();
  size(vw);const c=vw.getContext('2d');grid(c);
  if(step>=cur.length){
    // last frame: show where every piece ended up (the finished solution on the starting board)
    if(lastRows0) for(let y=0;y<H;y++) for(let x=0;x<COLS;x++) if((lastRows0[BUF+y]>>x)&1) cell(c,x,y,COLORS.G);
    if(curPic) curPic.forEach(q=>q.cells.forEach(([x,y])=>cell(c,x,y,COLORS[q.t])));
    $('cap').textContent=L('PERFECT CLEAR! (최종 배치)','PERFECT CLEAR! (final layout)');$('cap').style.color='var(--mint)';return;
  }
  const s=cur[step];
  s.before.slice(BUF).forEach((v,y)=>{for(let x=0;x<COLS;x++)if((v>>x)&1)cell(c,x,y,COLORS.G);});
  s.ghost.forEach(g=>g.cs.forEach(([x,y])=>cell(c,x,y-BUF,COLORS[g.t],.3)));
  s.cs.forEach(([x,y])=>cell(c,x,y-BUF,COLORS[s.t]));
  $('cap').style.color='';
  $('cap').textContent=`${step+1}/${cur.length}  ${s.t}${!multi&&s.used?L(' (홀드 사용)',' (used hold)'):''}${s.spin?L(' (스핀·틱)',' (spin/tuck)'):''}`+((multi||curPlay)?L('  · 큐 ','  · queue ')+curQ:'');
}
$('nx').onclick=()=>{stopPlay();if(cur&&step<cur.length){step++;draw();}};
$('pv').onclick=()=>{stopPlay();if(cur&&step>0){step--;draw();}};
function stopPlay(){clearInterval(timer);timer=null;$('pl').textContent=L('재생','Play');}
$('pl').onclick=()=>{
  if(timer) return stopPlay();
  if(!cur) return;
  if(step>=cur.length) step=0;
  draw();$('pl').textContent=L('정지','Pause');
  timer=setInterval(()=>{ if(step<cur.length){step++;draw();} else stopPlay(); },700);
};
$('fm').onclick=()=>{
  if(!shapes.length||!lastR||!lastRows0) return;
  const code=fumenFromShapes(shapes,fmLabel,lastRows0,H,BUF);
  const box=$('fmbox');box.value=code;box.style.display='';box.select();
  const done=()=>{$('fm').textContent=L('복사됨','Copied');setTimeout(()=>{$('fm').textContent=L('후멘 복사','Copy fumen');},1500);};
  if(navigator.clipboard&&navigator.clipboard.writeText) navigator.clipboard.writeText(code).then(done,()=>{});
  else{try{document.execCommand('copy');done();}catch(_){}}
};
// copy the field as it is now (the board being edited) as a one-page fumen; pieces keep their colour, grey blocks stay grey
$('fmcur').onclick=()=>{
  const field=new Array(240).fill(0),col={};for(const t of Object.keys(FM_COLOR)) if(t!=='X'&&COLORS[t]) col[String(COLORS[t]).toLowerCase()]=FM_COLOR[t];
  let n=0;
  for(let y=0;y<H;y++) for(let x=0;x<COLS;x++) if(board[y][x]){
    const r=22-(H-1-y);if(r<0) continue;
    const tc=tint[y]&&tint[y][x];field[r*10+x]=(tc&&col[String(tc).toLowerCase()])||FM_COLOR.X;n++;
  }
  const code=fumenEncode([{field,comment:null}]);
  const box=$('fmbox');box.value=code;box.style.display='';box.select();
  const b=$('fmcur'),done=()=>{st(L('현재 필드 후멘 복사됨','Copied the current field as a fumen.'),'ok');b.textContent=L('복사됨','Copied');setTimeout(()=>{b.textContent=L('내보내기','Export fumen');},1500);};
  if(navigator.clipboard&&navigator.clipboard.writeText) navigator.clipboard.writeText(code).then(done,()=>{try{document.execCommand('copy');done();}catch(_){}});
  else{try{document.execCommand('copy');done();}catch(_){}}
};
