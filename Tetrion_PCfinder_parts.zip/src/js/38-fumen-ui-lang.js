// setup mode: copy the whole bundle of the current board as one fumen, one page per board in the shown order (grey = existing block, piece colour = block to build).
// The first page's comment carries the queue, the empty-hold option; the import below reads the pages back as boards
$('bgcopy').onclick=()=>{
  if(running||!SMODE||!suBoards) return;
  const say=(t,k)=>{const e=$('sst');e.textContent=t;e.className=k||'';};
  suSaveCur();
  const cb=suBoards[suCur];
  if(!cb||!cb.grp) return say(L('묶음에 속한 보드 아님','This board is not in a bundle.'),'bad');
  const col={};for(const t of Object.keys(FM_COLOR)) if(t!=='X'&&COLORS[t]) col[String(COLORS[t]).toLowerCase()]=FM_COLOR[t];
  const pages=[];
  for(const b of suBoards){
    if(!bvis(b,true)||b.grp!==cb.grp) continue;
    if(!b.board.some(r=>r.some(v=>v))) continue;   // empty boards are not worth a page
    const field=new Array(240).fill(0);
    for(let y=0;y<b.H;y++) for(let x=0;x<COLS;x++) if(b.board[y][x]){
      const r=22-(b.H-1-y);if(r<0) continue;
      const tc=b.tint[y]&&b.tint[y][x];field[r*10+x]=(tc&&col[String(tc).toLowerCase()])||FM_COLOR.X;
    }
    pages.push({field,comment:bname(b)});
  }
  if(!pages.length) return say(L('복사할 보드 없음 · 블록 있는 보드 필요','No board to copy: a board needs at least one block.'),'bad');
  pages[0].comment=pages[0].comment+' · '+L('넥스트 ','Next ')+$('q').value+($('he').checked?' · '+L('빈 홀드','empty hold'):'');
  const code=fumenEncode(pages);
  const box=$('fmbox');box.value=code;box.style.display='';box.select();
  const b=$('bgcopy'),done=()=>{say(L(`묶음의 보드 ${pages.length}개를 후멘 하나로 복사`,`Copied ${pages.length} board(s) of the bundle as one fumen.`),'ok');b.textContent=L('복사됨','Copied');setTimeout(()=>{b.textContent=L('묶음 복사','Copy bundle');},1500);};
  if(navigator.clipboard&&navigator.clipboard.writeText) navigator.clipboard.writeText(code).then(done,()=>{try{document.execCommand('copy');done();}catch(_){}});
  else{try{document.execCommand('copy');done();}catch(_){}}
};
// setup mode: every page of the fumen becomes one board (grey = existing block, piece colour = block to build)
function suFumenImport(){
  const say=(t,k)=>{const e=$('sst');e.textContent=t;e.className=k||'';};
  let pages=null,bad=false;
  try{pages=fumenAllFields($('fmin').value);}catch(e){bad=true;}
  if(bad||!pages||!pages.length) return say(L('후멘 코드(v115@…)를 읽지 못함','Could not read that fumen code (v115@…).'),'bad');
  const INVF={1:'I',2:'L',3:'O',4:'Z',5:'T',6:'J',7:'S'},made=[];let skipped=0;
  for(const f of pages){
    let top=-1;for(let r=0;r<23&&top<0;r++) for(let x=0;x<10;x++) if(f[r*10+x]){top=r;break;}
    if(top<0||23-top>hCap()){skipped++;continue;}
    const Hh=Math.max(2,23-top),bd=[],tn=[];
    for(let y=0;y<Hh;y++){
      const r=23-Hh+y;bd.push(Array(COLS).fill(0));tn.push(Array(COLS).fill(null));
      for(let x=0;x<10;x++){const c=f[r*10+x];if(c){bd[y][x]=1;if(c>=1&&c<=7) tn[y][x]=COLORS[INVF[c]];}}
    }
    made.push({H:Hh,board:bd,tint:tn});
  }
  if(!made.length) return say(L('가져올 지형 없음 (빈 페이지이거나 높이가 12줄 초과)','No usable board (empty pages, or taller than 12 rows).'),'bad');
  suSaveCur();
  const empty=suBoards.every(b=>b.board.every(r=>r.every(v=>!v)));
  const list=empty?suBoards.filter(b=>b.def):suBoards.slice();if(empty) suCnt=0;   // the default boards always stay
  const first=list.length;let cut=0;
  for(const b of made){if(list.filter(b=>bvis(b,true)).length>=SU_MAX){cut++;continue;}suCnt++;list.push({num:suNextNum(list),own:'su',set:suSets[suSetCur].id,useSet:!!(suBoards&&suBoards[suCur]&&suBoards[suCur].useSet),...b});}
  suBoards=list;suCur=first;suLoad(suCur);suChips();
  say(L(`후멘 ${pages.length}페이지 → 보드 ${made.length-cut}개 생성`,`Made ${made.length-cut} board(s) from ${pages.length} fumen page(s).`)+(skipped?L(` 빈 페이지·12줄 초과 ${skipped}개는 건너뜀.`,` Skipped ${skipped} empty/too tall page(s).`):'')+(cut?L(` 최대 ${SU_MAX}개라 ${cut}개는 못 넣음.`,` ${cut} not added (max ${SU_MAX}).`):''),'ok');
}
$('fmload').onclick=()=>{
  if(running) return;
  if(SMODE) return suFumenImport();
  let f;try{f=fumenFirstField($('fmin').value);}catch(_){f=null;}
  if(!f) return st(L('후멘 코드(v115@…)를 읽지 못함','Could not read that fumen code (v115@…).'),'bad');
  let top=-1;for(let r=0;r<23&&top<0;r++) for(let x=0;x<10;x++) if(f[r*10+x]) {top=r;break;}
  if(top<0) return st(L('첫 페이지가 비어 있음','The first page is empty.'),'bad');
  const h=23-top;
  if(h>hCap()) return st(L(`쌓인 높이 ${h}줄: ${hCap()}줄 초과로 가져오기 불가`,`The stack is ${h} rows high; the maximum is ${hCap()}.`),'bad');
  setH(Math.max(2,h));resetBoard();
  // keep the colours of the fumen too: grey stays grey, a piece colour stays that piece's colour (cosmetic in this mode, the search ignores it)
  const INVF={1:'I',2:'L',3:'O',4:'Z',5:'T',6:'J',7:'S'};
  for(let y=0;y<H;y++){const r=23-H+y;for(let x=0;x<10;x++){const c=f[r*10+x];if(c){board[y][x]=1;tint[y][x]=(c>=1&&c<=7)?COLORS[INVF[c]]:null;}}}
  drawEd();restoreSaved();
  if($('res').style.display==='none') st(L(`후멘 첫 페이지 가져옴 (높이 ${H}줄)`,`Imported the first fumen page. (${H} rows)`),'ok');
};
// collapsible options panel: the button shows the preset and how many options are switched on
let optClosed=true;   // everything foldable starts folded
function updOptSum(){
  const box=$('optbox');const open=SMODE||!optClosed;box.style.display=open?'':'none';$('optfold').parentNode.style.display=SMODE?'none':'';   // 구축 확률 모드: 접기 없이 항상 펼침
  const n=(SMODE?['he','b2b']:['he','po','so','b2b','jsc']).filter(id=>$(id)&&$(id).checked).length+(SMODE?suConds.length:0);
  const mode=$('kmode').options[$('kmode').selectedIndex].text;
  $('optfold').textContent=(open?'▾ ':'▸ ')+L('옵션','Options')+(n?' · '+L(n+'개 켜짐',n+' on'):'');
  $('optfold').setAttribute('aria-expanded',open);
}
$('optfold').onclick=()=>{optClosed=!optClosed;updOptSum();};
['he','po','so','b2b','jsc','kmode'].forEach(id=>$(id).addEventListener('change',updOptSum));
const STATIC={
  h2board:['보드','Board'],
  hint6:['퍼클은 아래 8줄까지만 지원 · 9줄 이상은 8줄 안에서 끝나는 해만 찾음','PC covers the bottom 8 rows only · on taller boards, only solutions within 8 rows'],
  lblHeight:['높이','Height'],
  clr:['비우기','Clear'],
  h2piece:['피스','Pieces'],
  lblNext:['넥스트','Next'],
  hintBundle:['<b>묶음</b> = 보드 여러 개를 한 덩어리로 묶는 기능<br>· <b>묶기</b>: 보드 칩을 다른 칩 한가운데에 겹쳐 놓으면 묶여요 (같은 색 테두리로 표시)<br>· <b>순서 바꾸기</b>: 칩을 다른 칩에 살짝만 걸쳐 놓으면 자리가 바뀌어요 (묶음 안에서도 가능)<br>· <b>빼기</b>: 칩을 묶음 테두리 밖으로 끌어내면 빠져요 (빨간 점선이 보일 때 놓기)<br>· <b>계산</b>: 묶음 안 보드를 골라 계산하면 묶음 전체를 한 번에 계산해요. 보드별 확률과 \'하나라도/모두\'가 나와요<br>· <b>묶음 복사</b>: 묶음의 보드들을 후멘 한 개(보드마다 한 페이지)로 복사해요','<b>Bundle</b> = group several boards together<br>· <b>Bundle</b>: drop a board chip right on the middle of another chip (shown with a shared coloured border)<br>· <b>Reorder</b>: just overlap a chip\'s edge with another chip to swap places (works inside a bundle too)<br>· <b>Remove</b>: drag a chip outside the bundle border (release while the red dashed outline shows)<br>· <b>Calculate</b>: pick a board of the bundle and calculate to run the whole bundle at once, with per-board odds and Any / All<br>· <b>Copy bundle</b>: copies the bundle\'s boards as one fumen (one page per board)'],
  hintBracket:['[ ] 묶음 · 안은 띄어 써도 됨 · 중첩 가능<br>자동입력: [ 입력 시 ] 추가 · SZ] → [SZ] · []!SZ>LJ} → []!{SZ>LJ}<br>숫자 = 뽑을 개수(생략 시 1개, 쓴 순서 유지)<br>! = 섞기(개수 생략 시 전부)<br><br>[TIL] T·I·L 중 1개<br>[TIL]2 TI·TL·IL 중 하나<br>[TIL]! 3개 전부 섞어서<br>[TIL]2! 2개를 섞어서<br><br>[]! = [IOTSZJL]! → 기본으로 7-bag 지정<br>[^TI] = 7피스에서 T·I를 뺀 나머지 (예: [^TI]!)<br>% = bag 여부 뒤집기 (일반 묶음에 붙이면 bag 지정, []에 붙이면 해제)<br>※ 세이브는 bag으로 지정된 묶음 기준으로 계산돼요 (해제하면 계산 안 함)<br><br>예: [TIL]!JSZ<br>예: [[SZ]! [LJ]!]2!<br><br>{A&lt;B} = 묶음 뒤에 붙이는 순서 조건 (A의 피스가 모두 B보다 앞, 나머지는 자유)<br>{B&gt;A} 도 같은 뜻 (B가 A보다 뒤)<br>예: []!{LJ&lt;SZ} = []!{SZ&gt;LJ}',
    '[ ] group · spaces ok inside · nestable<br>Auto input: [ adds ] · SZ] → [SZ] · []!SZ>LJ} → []!{SZ>LJ}<br>number = how many to pick (default 1, written order kept)<br>! = shuffle (all if no number)<br><br>[TIL] 1 of T·I·L<br>[TIL]2 one of TI·TL·IL<br>[TIL]! all 3, shuffled<br>[TIL]2! 2, shuffled<br><br>[]! = [IOTSZJL]! → 7-bag by default<br>[^TI] = the 7 pieces without T·I (e.g. [^TI]!)<br>% = toggle bag mode (on a plain group: make it a bag · on []: release it)<br>※ Saves are calculated from the groups set as a bag (none if released)<br><br>e.g. [TIL]!JSZ<br>e.g. [[SZ]! [LJ]!]2!<br><br>{A&lt;B} after a group = order rule (every piece of A before every piece of B, others free)<br>{B&gt;A} means the same (B after A)<br>e.g. []!{LJ&lt;SZ} = []!{SZ&gt;LJ}'],
  lblUseHold:['홀드 사용','Use hold'],
  lblRot180:['180° 회전','180° rotation'],
  lblSpin:['스핀·틱 포함','Include spins/tucks'],
  lblJsc:['평균점수,기술확률','Average score & move odds'],lblJcb:['시작 콤보','Start combo'],lblJb2:['SPC/DPC','SPC/DPC'],
  lblProbOnly:['확률만 (빠름)','Probability only (fast)'],lblSolOnly:['해법만 (빠름)','Solutions only (fast)'],lblHoldEmpty:['빈 홀드로 시작','Start with empty hold'],lblB2b:['백투백 유지 확률','B2B-keeping probability'],
  fm:['후멘 복사','Copy fumen'],
  fmcur:['내보내기','Export fumen'],
  hintSee:['',''],
  fmload:['가져오기','Import'],
  go:['실행','Run'],
  h2result:['결과','Result']
};
// tooltips and labels that live in the static markup: set in both languages on every language switch
function applyTitles(){
  const T=(id,ko,en)=>{const e=$(id),l=e&&e.closest('label');if(l) l.title=L(ko,en);};
  T('he','켜면 빈 홀드로 시작, 끄면 넥스트 맨 앞 피스가 이미 홀드에 들어 있는 상태로 시작','On: start with an empty hold. Off: start with the first Next piece already in hold.');
  T('so','모든 해를 찾음 · 최소 해법·실패 큐·남는 미노 통계는 계산 안 함','Finds every solution but skips the minimal set, failed queues and leftover-mino statistics.');
  T('b2b','백투백을 켠 채 시작해, PC 후에도 백투백이 남는 확률(줄 삭제가 쿼드·스핀·PC뿐)도 계산 · 느릴 수 있음','Starts with back-to-back on and also computes the chance it is still on after the PC (only quad, spin, PC clears) · may be slower');
  T('jsc','선택한 모드의 점수표(Jstris 또는 TETR.IO Blitz: 레벨 1 고정, 미니더블 400, 올클리어 3500 / 싱글100·더블300·트리플500·쿼드800, T스핀, 백투백 ×1.5, 콤보 +50×콤보, PC +3000)로 해법 점수와 평균 계산','Computes solution scores and their average with the selected mode\'s scoring table (Jstris or TETR.IO Blitz: level fixed at 1, mini double 400, all clear 3500 / single 100, double 300, triple 500, quad 800, T-spin, back-to-back ×1.5, combo +50×combo, PC +3000).');
  T('sfon','켜면 해법 찾기 버튼이 PC 대신 셋업을 찾습니다 (큐 앞쪽 N피스로 쌓는 셋업)','When on, the search button finds setups instead of PCs (setups built with the first N pieces of the queue).');
  {const e=$('jcb');if(e) e.title=L('이미 이어진 연속 줄 삭제 수 (0 = 없음, 1 = 한 번 지웠음)','Line clears already chained in a row (0 = none, 1 = cleared once)');}
  {const e=$('see');if(e) e.placeholder=L('전체','all');}
  {const e=$('pal');if(e){e.setAttribute('aria-label',L('색칠','Paint colour'));e.querySelectorAll('.sw').forEach(b=>{const k=b.dataset.k;if(k) b.setAttribute('aria-label',k==='G'?L('회색','Gray'):k);});}}
  {const e=$('qhist');if(e) e.setAttribute('aria-label',L('연산 기록','Calculation history'));}
}
function applyLang(){
  document.documentElement.lang=LANG==='en'?'en':'ko';   // screen readers, translation and search follow the language shown
  suLabels();
  $('lang').textContent=LANG==='en'?'한국어':'EN';
  for(const id in STATIC){const el=$(id);if(el) el[id==='hintBracket'||id==='hintBundle'?'innerHTML':'textContent']=STATIC[id][LANG==='en'?1:0];}
  $('lblJsc').textContent=tioMode()?L('평균점수,기술확률 Blitz','Average score & move odds Blitz'):L('평균점수,기술확률 Ultra','Average score & move odds Ultra');
  $('hm').setAttribute('aria-label',L('높이 줄이기','Decrease height'));
  fmPh();
  $('hp').setAttribute('aria-label',L('높이 늘리기','Increase height'));
  for(const [id,ko,en] of [['hintBundle','묶음 설명','About bundles'],['hintBracket','입력 문법 설명','About the input syntax']]){const b=document.querySelector('button.ib[data-t="'+id+'"]');if(b) b.setAttribute('aria-label',L(ko,en));}
  $('hint6').style.display=H>MAXL?'':'none';
  if(!running) $('stop').textContent=L('중지','Stop');
  $('pl').textContent=timer?L('정지','Pause'):L('재생','Play');
  if(lastR) showSols(lastR);
  updSeeHint();
  updOptSum();
  if(typeof qhRender==='function') qhRender();
  applyTitles();
}
$('lang').onclick=()=>{LANG=LANG==='en'?'ko':'en';applyLang();};
applyLang();
['see','he','uh'].forEach(id=>{$(id).addEventListener('input',updSeeHint);$(id).addEventListener('change',updSeeHint);});
updSeeHint();
resetBoard();
