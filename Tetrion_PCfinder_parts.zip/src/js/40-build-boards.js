
// ==== 구축 확률 모드 =======================================================================================================
// 보드에 그린 칸을 주어진 큐(홀드 포함)로 정확히 쌓을 수 있는 큐의 확률. 회색 = 기존 블록, 피스 색 = 그 피스로 쌓을 칸.
// 꽉 찬 줄은 완성되는 순간 지워진다. 백투백: 줄 삭제가 0줄·4줄·스핀인 배치만 백투백을 유지한다(PC 모드와 같은 기준).
// 보드를 여러 개 두고 같은 큐로 한 번에 계산할 수 있다 (보드별 확률, 하나라도 / 모두 쌓을 수 있는 확률).
var SMODE=false,suGo=false,suStepI=0,suEx=null,suRes=null,suSel=0,suGrp=0,suBoards=null,suCur=0,suCnt=1;
var suSets=null,suSetCur=0,suPcQ='',suPcHe=false;
// Each board decides for itself whether it uses a setting (b.useSet). A board that does not use one has its own plain Next / hold, kept in suOff, and no colour.
var suOff={id:0,color:'#8790b8',q:'',he:false,conds:[],get name(){return L('설정 안 씀','No setting');}},suEdit=null;   // suEdit = the object the Next / hold boxes are written into
var pcSrc=null;   // the board shown in the PC finder: always one entry of suBoards (its default board when nothing else is picked); board.pq / board.phe keep its next-queue + hold setting
function pcQSave(){if(SMODE||running) return;const o=pcSrc;if(!o) return;o.pq=$('q').value;o.phe=$('he').checked;}
function pcQLoad(o){if(!o) return;if(typeof o.pq!=='string'){o.pq='';o.phe=false;}   // 구축 모드에서 만든 연동 보드: PC 쪽 넥스트는 따로(비어 있게) 시작 — 이전에 보던 보드의 큐를 물려받지 않는다
  $('q').value=o.pq;$('he').checked=!!o.phe;$('q').dispatchEvent(new Event('input',{bubbles:true}));}
function pcQNow(){return pcSrc;}
var SET_COLORS=['#ff2bd6','#00e5ff','#ffe14d','#39ff9a','#ff8a3d','#9b7bff','#ff5a5a','#4da3ff'];
const INVC={};for(const k of 'IOTSZJL') INVC[COLORS[k]]=k;
function fmPh(){$('fmin').setAttribute('placeholder',L('후멘 코드 붙여넣기 (v115@…)','Paste a fumen code (v115@…)'));}
const SU_MAX=20;
function suLabels(){
  const set=(id,t)=>{const e=$(id);if(e) e.textContent=t;};
  set('mdpc',L('PC 찾기','PC finder'));set('mdsu',L('구축 확률','Build odds'));
  set('suH',L('결과','Result'));
  set('suHint',L('후멘 페이지마다 지형별로 보드 생성','Paste a fumen and each page is turned into a board automatically.'));
  set('badd',L('+ 보드 추가','+ Add board'));set('suAddC',L('+ 조건 추가','+ Add condition'));renderConds();set('bdup',L('복제','Duplicate'));set('bdel',L('삭제','Delete'));set('bgcopy',L('묶음 복사','Copy bundle'));set('pcdup',L('복제','Duplicate'));set('pcdel',L('삭제','Delete'));
  set('kmL',SMODE?L('킥 규칙','Kick rules'):L('킥·점수 규칙','Kick/score rules'));set('bnumL',L('번호','No.'));set('bsetL',L('설정','Setting'));
  if(suBoards&&suSets) suChips(); else pcChips();
  if(!suGo) set('sgo',L('실행','Run'));
  set('sstop',L('중지','Stop'));set('sexh',L('예시 쌓는 순서','Example build order'));
}
// ---- 보드 목록 ----
function suSnap(){return{H,board:board.map(r=>r.slice()),tint:tint.map(r=>r.slice())};}
// One list holds every board, the two default boards too (b.def 'su' = the Build default, 'pc' = the PC finder's default; each is visible only in its own mode).
function pcDefB(){return suBoards&&suBoards.find(b=>b.def==='pc');}
function boardsEnsure(mig){   // mig: the PC default of an older save {snap,q}
  suSetEnsure();
  const had=!!(suBoards&&suBoards.length);if(!had){suBoards=[];suCnt=0;suCur=0;}
  const sid=suSets[Math.min(suSetCur,suSets.length-1)].id;
  if(!suBoards.some(b=>b.def==='su')){const c=had?cpSnap(suBoards[0]):suSnap();suBoards.unshift({num:'0',def:'su',own:'su',set:had?suBoards[0].set:sid,useSet:had?!!suBoards[0].useSet:false,H:c.H,board:c.board,tint:c.tint});suCur=had?suCur+1:0;}
  if(!suBoards.some(b=>b.def==='pc')){
    const c=mig&&mig.snap?mig.snap:suSnap(),b={num:'0',def:'pc',own:'pc',set:sid,useSet:false,H:c.H,board:c.board.map(r=>r.slice()),tint:c.tint.map(r=>r.slice())};
    if(mig&&mig.q){b.pq=mig.q.pq;b.phe=!!mig.q.phe;}else{b.pq=$('q').value;b.phe=$('he').checked;}
    suBoards.push(b);
  }
}
function bcount(su){return suBoards?suBoards.filter(b=>bvis(b,su)).length:0;}   // boards the mode can see: the limit and the setting counts only count these
function suEnsure(){if(!suBoards||!suBoards.length) boardsEnsure();}
function bname(b){return b.def?L('기본보드','Default board'):L('보드 ','Board ')+b.num;}
// boards are private to the mode they were made in (b.own 'pc' | 'su'); importing one from the other mode makes it shared (b.sh). Boards without b.own (older saves) stay shared.
function bvis(b,su){return b.def?b.def===(su?'su':'pc'):(!b.own||b.sh||b.own===(su?'su':'pc'));}
function impUI(el,su){   // 'import' drop-down: the other mode's private boards (chosen one becomes shared). A drop-down, so nothing is listed after the new-board button
  const other=su?'pc':'su',cand=(suBoards||[]).filter(b=>!b.def&&b.own===other&&!b.sh);
  const a=document.createElement('select');a.setAttribute('aria-label',su?L('PC에서 가져오기','Import from PC'):L('구축에서 가져오기','Import from Build'));
  a.style.cssText='width:auto;flex:none;padding:6px 10px;font-size:13px;touch-action:manipulation;border:2px solid #5b6598';
  const o0=document.createElement('option');o0.value='';o0.textContent=su?L('PC에서 가져오기','Import from PC'):L('구축에서 가져오기','Import from Build');a.appendChild(o0);
  cand.forEach((b,k)=>{const o=document.createElement('option');o.value=k;o.textContent=L('보드 ','Board ')+b.num;a.appendChild(o);});
  a.disabled=!cand.length;
  a.onchange=()=>{if(running||a.value==='') return;const b=cand[+a.value];b.sh=true;if(su){suChips();}else{pcPick(b);pcChips();}};
  el.appendChild(a);
}   // the default board (b.def) exists in both modes and can't be deleted or renamed
function suNextNum(list,own){
  if(own==='pc'){const nm=n=>{let t='';n++;while(n>0){const r=(n-1)%26;t=String.fromCharCode(97+r)+t;n=Math.floor((n-1)/26);}return t;};   // PC-made boards: a, b, c … z, aa, ab …
    let i=0;while(list.some(b=>String(b.num).toLowerCase()===nm(i))) i++;return nm(i);}
  let n=1;while(list.some(b=>String(b.num)===String(n))) n++;return String(n);   // Build-made boards: 1, 2, 3 …
}
var suEsc=t=>String(t).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function suSaveCur(){suEnsure();Object.assign(suBoards[suCur],suSnap());suBoards[suCur].conds=suConds;}
function suLoad(i){const b=suBoards[i];H=b.H;board=b.board.map(r=>r.slice());tint=b.tint.map(r=>r.slice());$('hh').value=H;drawEd();
  if(suSets){suSetSave();suLoadBoardSetting(b);}
  suConds=b.conds||(b.conds=[]);renderConds();updOptSum();}   // 조건은 설정이 아니라 보드마다 따로 갖는다
function suBorder(){
  const b=SMODE?(suBoards&&suSets&&suBoards[suCur]):(pcSrc&&suSets?pcSrc:null);
  if(!b||(!SMODE&&b.own==='pc')){ed.style.boxShadow='';return;}   // PC finder: boards made here have no coloured frame; ones brought from Build keep theirs
  if(!b.grp){ed.style.boxShadow='';return;}const c=grpColor(b.grp);ed.style.boxShadow=`0 0 0 4px ${c},0 0 16px 2px ${c}`;
}
// tap the selected board chip -> edit its number in place
function suEditNum(x,b){
  if(running||b.def||!x.parentNode) return;
  const d=document.createElement('div'),inp=document.createElement('input');let done=false;
  d.style.cssText=x.style.cssText+";display:inline-flex;align-items:center;gap:5px;height:var(--h);font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;font-weight:800;color:#000";
  inp.type='text';inp.maxLength=6;inp.value='';inp.placeholder=b.num;inp.spellcheck=false;inp.autocomplete='off';inp.className='nedit';
  inp.style.cssText='width:2.6em;height:1.6em;padding:0;margin:0;text-align:center;letter-spacing:0;text-transform:none;background:transparent;color:#000;caret-color:#000;border:0;border-bottom:2px solid #000;border-radius:0;outline:none;font:inherit;flex:none;min-width:0';
  d.append(document.createTextNode(L('보드 ','Board ')),inp);
  x.parentNode.replaceChild(d,x);inp.focus();
  inp.onblur=()=>{if(done) return;done=true;b.num=inp.value.trim()||b.num;suChips();};
  inp.onkeydown=e=>{if(e.key==='Enter') inp.blur();else if(e.key==='Escape'){done=true;suChips();}};
}
function suChips(){
  pcChips();
  const bar=$('bbar');bar.style.display=SMODE?'':'none';if(!SMODE){suBorder();suSetsUI();return;}
  suEnsure();suPruneGroups();const el=$('bchips');el.innerHTML='';{const dm=$('bdrop');if(dm) dm.remove();}
  if(!bvis(suBoards[suCur],true)) suCur=Math.max(0,suBoards.findIndex(b=>b.def==='su'));
  let lastC=null;
  suBoards.forEach((b,i)=>{if(!bvis(b,true)) return;const S0=suSetOfB(b),S={...S0,color:suCol(S0)},x=document.createElement('button');if(b.grp) S.color=grpColor(b.grp);x.type='button';x.textContent=bname(b);
    x.style.cssText='padding:6px 12px;font-size:13px;touch-action:manipulation;user-select:none;border:2px solid '+S.color+(i===suCur?';background:'+S.color+';color:#000':'');
    x._b=b;x.style.touchAction='none';x.style.webkitTouchCallout='none';
    x.onclick=e=>{if(running) return;if(i===suCur){suEditNum(x,b);return;}suSaveCur();suCur=i;suLoad(i);suChips();};   // tap = select; tap the selected board = edit its number   // double-click = pick this board for the combination (mint ring)
    const w=document.createElement('span');w.style.cssText='display:inline-flex;align-items:center';
    w.append(x);
    if(b.grp&&lastC&&lastC.b.grp===b.grp){   // same bundle as the previous chip: one common border around them
      if(!lastC.g){const g=document.createElement('span');g.dataset.bar='1';g.style.cssText='display:inline-flex;flex-wrap:wrap;align-items:center;gap:2px;padding:2px;margin:2px;max-width:100%;box-sizing:border-box;border:2px solid '+S.color+'';
        el.replaceChild(g,lastC.w);g.append(lastC.w);lastC.g=g;}
      lastC.g.append(w);lastC={b,w,g:lastC.g};
    }else{el.appendChild(w);lastC={b,w,g:null};}});
  {const a=document.createElement('button');a.type='button';a.id='badd2';a.textContent=L('+ 보드 생성','+ New board');a.disabled=bcount(true)>=SU_MAX;
    a.style.cssText='padding:6px 12px;font-size:13px;touch-action:manipulation;border:2px solid #5b6598';a.onclick=()=>suAdd(false);el.appendChild(a);}
  impUI(el,true);
  const cb=suBoards[suCur],cs0=suSetOfB(cb),cs={...cs0,color:suCol(cs0)},bn=$('bnum');
  if(document.activeElement!==bn) bn.value=cb.num;
  bn.style.borderColor=cb.grp?grpColor(cb.grp):cs.color;
  $('bgcopy').style.display=cb.grp?'':'none';
  $('badd').disabled=$('bdup').disabled=bcount(true)>=SU_MAX;$('bdel').disabled=suBoards.length<=1||!!suBoards[suCur].def;
  suBorder();suSetsUI();
}
function suAdd(copy){
  if(running||bcount(true)>=SU_MAX) return;
  suSaveCur();suCnt++;
  const base=copy?suSnap():{H,board:Array.from({length:H},()=>Array(COLS).fill(0)),tint:Array.from({length:H},()=>Array(COLS).fill(null))};
  suBoards.push({num:suNextNum(suBoards),own:'su',set:suBoards[suCur].set,useSet:!!suBoards[suCur].useSet,conds:copy?suConds.map(c=>({...c})):[],...base});suCur=suBoards.length-1;suLoad(suCur);suChips();
}
// ---- 묶음 (bundle): b.grp = bundle id. Bundling only groups boards: members sit next to each other, share a colour, and when one of them is
// selected every member is calculated at the same time, each on its own. Nothing else is shared (terrain, Next and hold stay per board / global).
function grpColor(g){return SET_COLORS[(parseInt(String(g).slice(1))||0)%SET_COLORS.length];}   // 묶음마다 다른 색: 묶음 번호(g0,g1,…)로 선명한 팔레트에서 고른다
function suPruneGroups(){   // a bundle needs at least two boards
  if(!suBoards) return;const n={};for(const b of suBoards) if(b.grp&&bvis(b,true)) n[b.grp]=(n[b.grp]||0)+1;
  for(const b of suBoards) if(b.grp&&(n[b.grp]||0)<2) b.grp='';
}
function suOrderFix(){   // members of one bundle sit next to each other (the default boards stay first)
  if(!suBoards) return;suPruneGroups();
  const out=[],seen=new Set();
  for(const b of suBoards){if(seen.has(b)) continue;seen.add(b);out.push(b);if(b.grp) for(const c of suBoards) if(!seen.has(c)&&c.grp===b.grp){seen.add(c);out.push(c);}}
  suBoards.splice(0,suBoards.length,...out);
}
function suFixKeep(){const sc=suBoards[suCur];suOrderFix();suCur=Math.max(0,suBoards.indexOf(sc));}
function suGroupAdd(x,y){   // put x into y's bundle (made if y has none)
  if(running||!suBoards||!x||!y||x===y) return;
  let g=y.grp;if(!g){let n=0;for(const b of suBoards) if(b.grp) n=Math.max(n,(parseInt(b.grp.slice(1))||0)+1);g='g'+n;y.grp=g;}
  x.grp=g;suFixKeep();suChips();
}
// reorder by dragging a board chip onto another one (mouse or touch). The order is shared by both modes; the default boards stay first.
function bReorder(b,t,su){
  if(running||!suBoards||b===t||b.def||t.def) return;
  const sc=suBoards[suCur],i=suBoards.indexOf(b);if(i<0||suBoards.indexOf(t)<0) return;
  suBoards.splice(i,1);const j=suBoards.indexOf(t);suBoards.splice(i<=j?j+1:j,0,b);suOrderFix();   // moving right lands after the target, moving left lands before it
  suCur=suBoards.indexOf(sc);su?suChips():pcChips();
}
function dragSetup(box,su){
  let st=null,sup=false;
  const PAD=16;   // 순서 바꾸기: 칩에서 이만큼 떨어져 있어도 걸친 걸로 본다 (널널)
  const hit=(x,y)=>{let best=null,ba=-1;const m=st.el.getBoundingClientRect();
    for(const el of box.querySelectorAll('button')){if(!el._b||(!su&&el._b.def)||el===st.el) continue;const r=el.getBoundingClientRect();
      const w=Math.min(m.right,r.right+PAD)-Math.max(m.left,r.left-PAD),h=Math.min(m.bottom,r.bottom+PAD)-Math.max(m.top,r.top-PAD);
      if(w>0&&h>0&&w*h>ba){ba=w*h;
        const cx=(r.left+r.right)/2,cy=(r.top+r.bottom)/2,hw=(r.right-r.left)*.25,hh=(r.bottom-r.top)*.25;   // 묶기: 포인터가 칩 한가운데(가로·세로 50%)에 있을 때만
        best={el,deep:Math.abs(x-cx)<=hw&&Math.abs(y-cy)<=hh};}}
    return best;};
  const barOf=el=>{const g=el.parentNode&&el.parentNode.parentNode;return g&&g.dataset&&g.dataset.bar?g:null;};
  const outOf=(el,x,y)=>{const g=barOf(el);if(!g) return false;const r=g.getBoundingClientRect();return x<r.left-14||x>r.right+14||y<r.top-14||y>r.bottom+14;};   // 자기 묶음 테두리 밖
  const clr=()=>{box.querySelectorAll('button').forEach(e=>{e.style.outline='';});};
  const ok_=(t,same)=>!!(t&&t.deep&&!same);   // 밖으로 끌어냈어도 다른 칩 한가운데에 놓으면 그 칩의 묶음으로 들어간다
  box.addEventListener('pointerdown',e=>{
    sup=false;
    if(running||e.button>0) return;const el=e.target.closest('button');if(!el||!el._b||el._b.def) return;
    st={el,b:el._b,x:e.clientX,y:e.clientY,drag:false};
  });
  window.addEventListener('pointermove',e=>{
    if(!st) return;const dx=e.clientX-st.x,dy=e.clientY-st.y;
    if(!st.drag&&Math.hypot(dx,dy)>7){st.drag=true;st.el.style.position='relative';st.el.style.zIndex='5';st.el.style.opacity='.75';try{st.el.setPointerCapture(e.pointerId);}catch(_){}}
    if(st.drag){st.el.style.transform='translate('+dx+'px,'+dy+'px)';clr();const t=hit(e.clientX,e.clientY);if(t) t.el.style.outline='3px solid '+(su&&t.deep&&t.el._b&&!(st.b.grp&&st.b.grp===t.el._b.grp)?'var(--mint)':'var(--gold)');
      {const g=su&&st.b.grp?barOf(st.el):null;if(g) g.style.outline=outOf(st.el,e.clientX,e.clientY)?'2px dashed #ff5a5a':'';}   // 빨간 점선 = 놓으면 묶음에서 빠짐
      e.preventDefault();}
  },{passive:false});
  const end=(e,ok)=>{
    if(!st) return;const d=st;st=null;
    if(!d.drag) return;
    sup=true;setTimeout(()=>{sup=false;},60);
    const t=ok?(st=d,hit(e.clientX,e.clientY)):null;st=null;
    const gb=su&&d.b.grp?barOf(d.el):null,out=gb?outOf(d.el,e.clientX,e.clientY):false;if(gb) gb.style.outline='';
    d.el.style.transform=d.el.style.position=d.el.style.zIndex=d.el.style.opacity='';clr();
    const tb=t&&t.el._b,same=!!(tb&&d.b.grp&&d.b.grp===tb.grp);
    if(out&&!ok_(t,same)){d.b.grp='';suFixKeep();suChips();if(tb&&!tb.def) bReorder(d.b,tb,su);return;}   // 묶음 밖으로 끌어내면 묶음에서 빠진다
    if(t){if(su&&t.deep&&!same) suGroupAdd(d.b,tb);else bReorder(d.b,tb,su);}   // 같은 묶음 안에서는 순서만 바꾼다   // 깊게 겹침 = 묶음, 살짝 걸침 = 순서 바꾸기
  };
  window.addEventListener('pointerup',e=>end(e,true));window.addEventListener('pointercancel',e=>end(e,false));
  box.addEventListener('click',e=>{if(sup){sup=false;e.stopPropagation();e.preventDefault();}},true);
}
dragSetup($('bchips'),true);dragSetup($('pcchips'),false);
// a shared (imported) board is only removed from the mode it is deleted in: it stays in the other mode as that mode's own board
function bShared(b){return !!b.sh||!b.own;}
function suDel(){
  if(running||suBoards.length<=1||suBoards[suCur].def) return;
  const b=suBoards[suCur];
  if(bShared(b)){
    suSaveCur();b.own='pc';b.sh=false;   // now only visible in the PC finder
    let nx=-1;for(let q=suCur-1;q>=0;q--) if(!suBoards[q].def&&bvis(suBoards[q],true)){nx=q;break;}
    suCur=nx>=0?nx:Math.max(0,suBoards.findIndex(x=>x.def==='su'));suLoad(suCur);suChips();return;
  }
  suBoards.splice(suCur,1);suCur=Math.min(suCur,suBoards.length-1);if(!bvis(suBoards[suCur],true)) suCur=Math.max(0,suBoards.findIndex(b=>b.def==='su'));suLoad(suCur);suChips();
}
function setMode(su){
  if(running) return;
  if(!su&&SMODE){suSaveCur();suSetSave();suEdit=null;$('q').value=suPcQ;   // suEdit=null: PC의 큐를 상자에 넣는 입력 이벤트가 설정(구축 큐)에 저장되지 않게
   $('he').checked=suPcHe;$('q').dispatchEvent(new Event('input',{bubbles:true}));}
  if(su&&!SMODE){pcQSave();Object.assign(pcSrc,suSnap());const bi=suBoards.indexOf(pcSrc);if(bi>=0&&bvis(pcSrc,true)) suCur=bi;suPcQ=$('q').value;suPcHe=$('he').checked;suSetEnsure();}
  SMODE=su;
  if(!su){const cb=suBoards[suCur];if(cb&&!cb.def&&bvis(cb,false)) pcSrc=cb;else if(!pcSrc||!bvis(pcSrc,false)) pcSrc=pcDefB();loadSnap(pcSrc);pcQLoad(pcQNow());pcQSave();}   // a shared board stays selected; the setup builder's own default sends you back to the PC finder's default
  if(su){suEdit=null;const cb=suBoards&&suBoards[suCur];if(cb&&bvis(cb,true)) suLoadBoardSetting(cb);else suSetLoad(suSetCur);}   // 선택한 보드의 설정(없으면 설정 안 씀)의 큐를 다시 보여 준다
  $('mdpc').classList.toggle('on',!su);$('mdsu').classList.toggle('on',su);document.body.classList.toggle('su',su);$('kmL').textContent=su?L('킥 규칙','Kick rules'):L('킥·점수 규칙','Kick/score rules');
    for(const e of [$('go').parentNode,$('see').parentNode,$('status'),$('fq2')]) e.style.display=su?'none':'';
  for(const e of [$('sgorow'),$('sst'),$('suHint'),$('suopt'),$('suwrap')]) e.style.display=su?'':'none';
  $('su').style.display=(su&&suRes)?'':'none';
  if(su){$('res').style.display='none';if(!suBoards){suEnsure();suSaveCur();}else{suEnsure();suLoad(suCur);}}
  for(const id of ['po','so','jsc']) $(id).parentNode.style.display=su?'none':'';
  $('b2b').parentNode.style.display='';
  if(su) $('jsopt').style.display='none'; else $('jsc').dispatchEvent(new Event('change'));
  $('hh').max=hCap();   // the PC finder keeps its 12-row limit
  $('hint6').style.display=(!su&&H>MAXL)?'':'none';
  suChips();updOptSum();fmPh();
  if(!su) restoreSaved();
}
$('mdpc').onclick=()=>setMode(false);
$('mdsu').onclick=()=>setMode(true);
$('badd').onclick=()=>suAdd(false);$('bdup').onclick=()=>suAdd(true);$('bdel').onclick=suDel;
