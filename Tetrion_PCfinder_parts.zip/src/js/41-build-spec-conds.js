// ---- 보드 해석 ----
function suSpec(b){
  const Hh=b.H,B=Hh+BUF,baseRows=Array(B).fill(0),goalRows=Array(B).fill(0),req=[],cc={};let nT=0;
  for(let y=0;y<Hh;y++){req.push(Array(COLS).fill(null));for(let x=0;x<COLS;x++){
    if(!b.board[y][x]) continue;
    const t=b.tint[y][x],ch=t?INVC[t]:null;
    goalRows[BUF+y]|=1<<x;
    if(!ch){baseRows[BUF+y]|=1<<x;continue;}
    nT++;req[y][x]=ch;cc[ch]=(cc[ch]||0)+1;
  }}
  if(!nT) return{err:L('색칠된(피스 색) 칸 없음 · 쌓을 칸에 피스 색 필요','No coloured cells. Paint the cells to build with piece colours.')};
  for(const k in cc) if(cc[k]%4) return{err:L(`${k} 색 칸 ${cc[k]}개 · 4의 배수 아님`,`${cc[k]} cells of colour ${k} is not a multiple of 4.`)};
  if(nT%4) return{err:L(`쌓을 칸 ${nT}개 · 4의 배수 아님`,`${nT} cells to build is not a multiple of 4.`)};
  if(baseRows.some(r=>r===1023)) return{err:L('회색 칸만으로 꽉 찬 줄 있음','A row is already full with gray cells only.')};
  return{name:bname(b),H:Hh,B,baseRows,goalRows,req,n:nT/4,goalKey:goalRows.join(','),startKey:baseRows.join(','),hasClear:goalRows.some(r=>r===1023)};
}
// ---- 한 보드의 큐 평가기 ----
// 상태 = 그린 좌표계의 줄들. 1023(꽉 찬 줄)은 이미 삭제된 줄 → 실제 판은 그 줄들을 빼고 아래로 내려앉힌 것.
// ok = 이 배치가 백투백을 유지하는가 (줄 삭제 0줄·4줄·스핀)
var COND=[['T스핀','T-spin'],['T스핀 싱글','T-spin single'],['T스핀 더블','T-spin double'],['T스핀 트리플','T-spin triple'],['쿼드','Quad'],['올스핀','All-spin'],
  ['T스핀 미니','T-spin mini'],['Z스핀','Z-spin'],['S스핀','S-spin'],['I스핀','I-spin'],['L스핀','L-spin'],['J스핀','J-spin']];
// bit of the placement mask (t.m) that each condition counts (bits 6-8 hold the plain 1/2/3-line clears); at most MAXCOND conditions fit the 18-bit counter
var COND_BIT=[0,1,2,3,4,5,9,10,11,12,13,14],MAXCOND=6;
var condAllOnly=t=>t===5||t>=7;   // all-spin and the single-piece spins (Z S I L J) exist only in TETR.IO mode (Jstris counts T-spins only)
var condName=t=>L(COND[t][0],COND[t][1]);
var suConds=[];
function renderConds(){
  const box=$('suCond');if(!box||!suConds||!COND) return;box.innerHTML='';
  suConds.forEach((c,j)=>{
    const sp=document.createElement('span');
    sp.style.cssText='display:inline-flex;align-items:center;gap:6px;border:1px solid var(--cy);padding:3px 6px;color:var(--ink);font-size:13px';
    const nm=document.createElement('span');nm.textContent=condName(c.t);
    const inp=document.createElement('input');inp.type='number';inp.min=1;inp.max=7;inp.value=c.n;inp.inputMode='numeric';
    inp.style.cssText='width:44px;background:#0c0f1e;border:1px solid var(--line);color:var(--ink);padding:3px;font:inherit;text-align:center';
    inp.onchange=()=>{c.n=Math.max(1,Math.min(7,Math.floor(+inp.value)||1));inp.value=c.n;updOptSum();};
    const tail=document.createElement('span');tail.textContent=L('회 이상','+');tail.style.color='var(--dim)';
    const x=document.createElement('button');x.type='button';x.textContent='×';x.setAttribute('aria-label','remove');
    x.style.cssText='padding:0 6px;min-width:0;line-height:20px';
    x.onclick=()=>{suConds.splice(j,1);renderConds();updOptSum();};
    sp.append(nm,inp,tail,x);box.appendChild(sp);
  });
  const ad=$('suAddC');if(ad) ad.disabled=suConds.length>=MAXCOND;
  renderCList();
}
function renderCList(){
  const el=$('suCList');if(!el) return;
  if(el.dataset.open!=='1'){el.style.display='none';return;}
  const step=el.dataset.step||'root';
  el.innerHTML='';el.style.cssText='display:flex;flex-direction:column;flex-basis:100%;max-height:180px;overflow-y:auto;border:1px solid var(--line);background:#0c0f1e;-webkit-overflow-scrolling:touch';
  const btnStyle='padding:9px 12px;font-size:14px;text-align:left;border:0;border-bottom:1px solid var(--line);background:transparent;flex:none';
  const mkBtn=(label,fn,disabled)=>{
    const b=document.createElement('button');b.type='button';b.textContent=label;b.style.cssText=btnStyle;
    if(disabled){b.disabled=true;b.style.opacity='.35';}
    else b.onclick=fn;
    el.appendChild(b);return b;
  };
  const addCond=t=>{suConds.push({t,n:1});el.dataset.open='0';el.dataset.step='root';renderConds();updOptSum();};
  const taken=t=>suConds.some(c=>c.t===t);
  const back=()=>{el.dataset.step='root';renderCList();};
  if(step==='root'){
    // 1단계: 카테고리
    const tAvail=[0,1,2,3,6].some(t=>!taken(t));
    mkBtn(L('T스핀 ▸','T-spin ▸'),()=>{el.dataset.step='tspin';renderCList();},!tAvail);
    mkBtn(condName(4),()=>addCond(4),taken(4));
    mkBtn(condName(5),()=>addCond(5),taken(5)||!tioMode());
    const oAvail=[7,8,9,10,11].some(t=>!taken(t));
    mkBtn(L('기타 스핀 ▸','Other spins ▸'),()=>{el.dataset.step='other';renderCList();},!oAvail||!tioMode());
  } else if(step==='tspin'){
    // 2단계: T스핀 하위 (미니 → 싱글 → 더블 → 트리플 → 아무 T스핀)
    mkBtn(L('◀ 뒤로','◀ Back'),back);
    const items=[[6,L('미니','Mini')],[1,L('싱글','Single')],[2,L('더블','Double')],[3,L('트리플','Triple')],[0,L('아무 T스핀','Any T-spin')]];
    for(const [t,lab] of items) mkBtn(lab,()=>addCond(t),taken(t));
  } else if(step==='other'){
    // 2단계: Z/S/I/L/J
    mkBtn(L('◀ 뒤로','◀ Back'),back);
    for(const t of [7,8,9,10,11]) mkBtn(condName(t),()=>addCond(t),taken(t)||!tioMode());
  }
}
