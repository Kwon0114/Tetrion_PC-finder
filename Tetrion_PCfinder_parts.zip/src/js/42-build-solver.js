const DUMMY=7;   // piece index of the unused spare piece
function suSolver(specs,needs,holdFilled,u180,spin,allSpin){
  // 큐 하나마다 한 번의 탐색으로 묶음의 모든 보드를 푼다 (보드는 서로 독립). evalAll(buf,strict) = 보드별 최종 상태(없으면 null)의 배열
  const fullFs=specs.map(sp=>{let F=0;sp.conds.forEach((c,j)=>{F+=c.n<<(3*j);});return F;});   // 보드마다 자기 조건
  const nn=specs.length,needMax=Math.max(...needs);
  // board states are interned to small integers: number keys make the per-queue state maps much faster than string keys
  const keyId=new Map(),keyRows=[],keyNode=[];
  const intern=(k,rows,nd)=>{const kk=nd+':'+k;let id=keyId.get(kk);if(id===undefined){id=keyRows.length;keyId.set(kk,id);keyRows.push(rows);keyNode.push(nd);}return id;};
  const startIds=specs.map((x,i)=>intern(x.startKey,x.baseRows,i)),goalIds=specs.map((x,i)=>intern(x.goalKey,x.goalRows,i)),transC=new Map();
  function trans(key,c){
    const ck=key*8+c;let r=transC.get(ck);if(r) return r;
    if(c===DUMMY){r=[];transC.set(ck,r);return r;}   // the spare piece after the typed queue: it can sit in hold or be swapped out, but never be placed
    const nd=keyNode[key],{B,goalRows,req}=specs[nd];
    r=[];const D=keyRows[key],map=[];
    for(let y=0;y<B;y++) if(D[y]!==1023) map.push(y);
    const c0=B-map.length,act=Array(B).fill(0);
    for(let i=0;i<map.length;i++) act[c0+i]=D[map[i]];
    const nid=placementIds(act,TYPES[c],u180,B,spin),ids=ID_OUT;
    for(let ii=0;ii<nid;ii++){
      const id=ids[ii],sig=id%SIGM,tl=(id-sig)/SIGM,top=(tl/10)|0,left=tl%10;
      const o4=[sig>>21,(sig>>14)&127,(sig>>7)&127,sig&127];
      const cs=[],acs=[];let ok=true;
      for(const o of o4){const ay=top+((o/10)|0),x=left+o%10,i=ay-c0;
        if(i<0){ok=false;break;}
        const y=map[i];
        if(!((goalRows[y]>>x)&1)){ok=false;break;}
        const q=req[y-BUF]&&req[y-BUF][x];if(q&&q!==TYPES[c]){ok=false;break;}
        cs.push([y,x]);acs.push([x,ay]);}
      if(!ok) continue;
      const nr=D.slice();for(const [y,x] of cs) nr[y]|=1<<x;
      const nk=intern(nr.join(','),nr,nd);
      // 백투백 유지 판정
      const mk={};for(const [x,ay] of acs) mk[ay]=(mk[ay]|0)|(1<<x);
      let cl=0;for(const ay in mk) if((act[ay]|mk[ay])===1023) cl++;
      let keep=cl===0||cl===4,spn=false;
      if(cl>0&&cl<4&&spin&&(allSpin||TYPES[c]==='T')){if(spinOK(act,TYPES[c],acs,u180,B)){keep=true;spn=true;}}
      const ts=spn&&TYPES[c]==='T';
      // T-spin mini: same rule as the score calculation (corner rule, the 5th-kick exception makes it a full T-spin)
      let mini=false;if(ts){const rr=jsCalc(act,acs,'T',true,{spin:true,u180,tio:allSpin});mini=rr.ev===2||rr.ev===3||rr.ev===7;}
      const pt=TYPES[c];
      const full=ts&&!mini;   // a T-spin mini is its own category and no longer counts as a full T-spin / all-spin
      const m=(mini?512:0)|(spn&&pt==='Z'?1024:0)|(spn&&pt==='S'?2048:0)|(spn&&pt==='I'?4096:0)|(spn&&pt==='L'?8192:0)|(spn&&pt==='J'?16384:0)|(full?1:0)|(full&&cl===1?2:0)|(full&&cl===2?4:0)|(full&&cl===3?8:0)|(cl===4?16:0)|(spn&&!mini?32:0)|(cl===1?64:0)|(cl===2?128:0)|(cl===3?256:0);
      r.push({k:nk,cs,ok:keep,m});
    }
    transC.set(ck,r);return r;
  }
  // strict=true: 백투백을 유지하는 배치만 따라간다
  // Queues are visited in tree order, so neighbours share a prefix: the state layers after each consumed piece are kept and only the part
  // after the first differing piece is recomputed. Results found at or before the shared prefix are reused as is.
  const mkC=()=>({pb:new Int32Array(128),n:0,depth:-1,lay:[],found:new Array(nn).fill(null),nfound:0});
  const cS=mkC(),cB=mkC();
  function evalAll(buf,strict){
    const C=strict?cB:cS,s0=holdFilled?1:0,lay=C.lay,pb=C.pb;
    let d=0;const lim=Math.min(C.n,needMax);
    while(d<lim&&pb[d]===buf[d]) d++;
    for(let i=d;i<needMax;i++) pb[i]=buf[i];
    C.n=needMax;
    let v=(holdFilled&&d<1)?-1:Math.min(C.depth,d);
    if(v<s0){lay[s0]=specs.map((_,r)=>({key:startIds[r],h:holdFilled?buf[0]:-1,mp:false,prev:null,act:null,f:0}));v=s0;C.depth=s0;C.found.fill(null);C.nfound=0;}
    else for(let r=0;r<nn;r++){const f=C.found[r];if(f&&f.layer>v){C.found[r]=null;C.nfound--;}}
    const nf=(f,t,nd)=>{const conds=specs[nd].conds;if(!conds.length||!t.m) return f;let g=f;for(let j=0;j<conds.length;j++) if((t.m>>COND_BIT[conds[j].t])&1){const cn=(f>>(3*j))&7;if(cn<conds[j].n) g+=1<<(3*j);}return g;};
    for(let i=v;i<needMax;i++){
      if(C.nfound===nn) break;
      const c=buf[i],nx=new Map(),cur=lay[i];
      if(!cur.length) break;
      const add=(key,h,mp,prev,act,f)=>{const k=((key*9+h+1)*2+(mp?1:0))*262144+f;if(!nx.has(k)) nx.set(k,{key,h,mp,prev,act,f});};
      for(let si=0;si<cur.length;si++){
        const s=cur[si];
        for(const t of trans(s.key,c)) if(!strict||t.ok) add(t.k,s.h,false,s,{c,cs:t.cs,held:false},nf(s.f,t,keyNode[s.key]));
        if(!s.mp){
          if(s.h>=0){for(const t of trans(s.key,s.h)) if(!strict||t.ok) add(t.k,c,false,s,{c:s.h,cs:t.cs,held:true},nf(s.f,t,keyNode[s.key]));}
          else add(s.key,c,true,s,{c,cs:null,held:true,hold:true},s.f);
        }
      }
      let states=[...nx.values()].filter(s=>needs[keyNode[s.key]]>i);   // 이 보드의 넥스트 한도(i+1개)를 넘기면 버린다
      const seen=new Set();
      for(let q=0,n=states.length;q<n;q++){
        const s=states[q],nd=keyNode[s.key];
        if(s.key!==goalIds[nd]||s.f!==fullFs[nd]||!s.act||!s.act.cs) continue;
        if(!C.found[nd]){C.found[nd]={s,layer:i+1};C.nfound++;}
      }
      lay[i+1]=states;C.depth=i+1;
    }
    return C.found.map(f=>f?f.s:null);
  }
  return{evalAll};
}
const suPct=x=>(x*100).toFixed(x>0&&x<0.01?4:2)+'%';
// 설정 하나(큐·홀드·조건)를 쓰는 보드들 = 한 그룹. 같은 그룹 안에서는 한 큐로 여러 보드를 함께 계산한다 (하나라도 / 모두).
function suPrep(g,pre){
  const S=g.S;let qstr=S.q,seqs;
  try{seqs=buildSeqs(parseQ(qstr));}catch(e){return pre+e.message;}
  if(!seqs.len) return pre+L('넥스트를 입력해야 합니다.','Enter a next queue.');
  const multi=g.bs.length>1,specs=[];
  for(const b of g.bs){   // every board of a bundle is calculated on its own
    const sp=suSpec(b);if(sp.err) return pre+(multi?bname(b)+': ':'')+sp.err;sp.color=S.color;sp.b=b;specs.push(sp);}
  const holdFilled=!S.he,u180=u180v(),spin=$('usp').checked,allSpin=tioMode();
  const maxN=Math.max(...specs.map(x=>x.n));
  // 넥스트가 모자라면 실제 게임처럼 뒤에 랜덤 7백이 이어진다고 보고 이어 붙인다 (홀드 때문에 n+1개까지 필요)
  // 입력한 큐만 쓴다: 랜덤 백을 이어 붙이지 않는다 (예: []! 에는 J가 1개뿐이라 J 2개가 필요한 보드는 불가능). 큐가 n개뿐이면 뒤에 '안 쓰이는 임시 미노' 1개를 붙여 홀드 교환만 가능하게 한다.
  if(seqs.len<maxN) return pre+L(`쌓을 피스 ${maxN}개에 비해 넥스트가 너무 짧습니다.`,`Queue is too short for ${maxN} pieces.`);
  const needs=specs.map(x=>x.n+1),maxNeed=Math.max(...needs);   // n pieces + 1 spare (the next piece of a real game, never placed)
  seqs=seqs.truncate(Math.min(maxNeed,seqs.len));
  for(const sp of specs) sp.conds=(sp.b.conds||[]).map(c=>({t:c.t,n:c.n}));
  const conds=specs.flatMap(sp=>sp.conds);
  if(conds.some(c=>condAllOnly(c.t))&&!allSpin) return pre+L('올스핀·Z/S/I/L/J스핀 조건은 TETR.IO 모드에서만 쓸 수 있습니다 (Jstris는 T스핀만 인정).','All-spin and Z/S/I/L/J-spin conditions need TETR.IO mode (Jstris only counts T-spins).');
  if(conds.some(c=>c.t!==4)&&!spin) return pre+L('스핀 조건은 스핀 사용 옵션 필요','Turn on the spin option to use spin conditions.');
  for(const sp of specs) if(sp.conds.length&&!sp.hasClear) return pre+L(`${multi?sp.name+': ':''}줄 삭제가 없어 조건 만족 불가`,`${multi?sp.name+': ':''}no line clears in this setup, so the conditions cannot be met.`);
  Object.assign(g,{specs,seqs,holdFilled,needs,maxNeed,conds,multi});
  g.solver=suSolver(specs,needs,holdFilled,u180,spin,allSpin);
  return null;
}
const suYield=(()=>{const mc=new MessageChannel(),q=[];mc.port1.onmessage=()=>{const f=q.shift();if(f) f();};return()=>new Promise(r=>{q.push(r);mc.port2.postMessage(0);});})();
async function suCalc(g,pre,ctl,say,b2bOn){
  const {specs,seqs,holdFilled,needs,maxNeed,conds,multi,solver}=g;
  const K=specs.length,N=seqs.n,buf=new Int32Array(Math.max(maxNeed,seqs.len));
  const R=specs.map(()=>({sw:0,sb:0,sc:0,scb:0,ex:null,exB:null,fails:[],bf:[],skipped:false}));
  const T={W:0,any:0,anyB:0,all:0,allB:0,kS:new Float64Array(K+1),kB:new Float64Array(K+1),mS:new Float64Array(1<<K),mB:new Float64Array(1<<K),full:-1,skip:0};
  let done=N;
  const qOf=n=>{let t='';for(let i=0;i<n;i++) if(buf[i]!==DUMMY) t+=TYPES[buf[i]];return t;};
  const wArr=new Float64Array(N),qS=new Uint32Array(N),qB=new Uint32Array(N);
  const needStrict=b2bOn&&specs.some(x=>x.hasClear);
  let tl=performance.now();
  // 큐 하나마다 한 번의 탐색으로 모든 보드를 푼다
  for(let k=0;k<N;k++){
    const w=seqs.fill(k,buf);wArr[k]=w;T.W+=w;
    for(let i=seqs.len;i<maxNeed;i++) buf[i]=DUMMY;
    const fin=solver.evalAll(buf,false),finS=needStrict?solver.evalAll(buf,true):null;
    for(let i=0;i<K;i++){
      const r=R[i],sp=specs[i],f=fin[i];
      let fb=null;if(f&&b2bOn) fb=sp.hasClear?finS[i]:f;
      if(f){r.sw+=w;r.sc++;qS[k]|=1<<i;if(!r.ex||w>r.ex.w) r.ex={w,s:f,q:qOf(needs[i])};}
      else if(r.fails.length<400) r.fails.push({w,q:qOf(needs[i])});
      if(fb){r.sb+=w;r.scb++;qB[k]|=1<<i;if(!r.exB||w>r.exB.w) r.exB={w,s:fb,q:qOf(needs[i])};}
      else if(b2bOn&&f&&r.bf.length<400) r.bf.push({w,q:qOf(needs[i])});
    }
    if((k&63)!==0) continue;
    const now=performance.now();
    if(now-tl>40){tl=now;say(pre+L(`계산 중… ${(k+1).toLocaleString()} / ${N.toLocaleString()} 큐 · 보드 ${K}개 · ${(T.W?R[0].sw/T.W*100:0).toFixed(2)}%`,`Calculating… ${(k+1).toLocaleString()} / ${N.toLocaleString()} queues · ${K} board(s) · ${(T.W?R[0].sw/T.W*100:0).toFixed(2)}%`));await suYield();if(ctl.stop){done=k+1;break;}}
  }
  const lim=Math.min(done,N),doneBoards=(1<<K)-1;
  for(let k=0;k<lim;k++){
    const w=wArr[k],m=qS[k]&doneBoards,mb=qB[k]&doneBoards;
    let c1=0,c2=0;for(let x=m;x;x&=x-1) c1++;for(let x=mb;x;x&=x-1) c2++;
    T.kS[c1]+=w;T.kB[c2]+=w;T.mS[m]+=w;T.mB[mb]+=w;
    if(m) T.any+=w;if(mb) T.anyB+=w;if(m===doneBoards) T.all+=w;if(mb===doneBoards) T.allB+=w;
  }
  return{specs,R,T,done,holdFilled,needs,qlen:seqs.len,multi,conds,b2b:b2bOn,S:g.S,color:suCol(g.S),qtxt:g.S.q.trim()};
}
async function suRun(){
  const sst=$('sst'),say=(t,k)=>{sst.textContent=t;sst.className=k||'';};
  $('sres').style.display='none';$('su').style.display='none';
  suSaveCur();suSetSave();
  const curB=suBoards[suCur];
  // the selected board alone, or - when it is in a bundle - every board of the bundle at the same time (each calculated on its own)
  let useB0=curB.grp?suBoards.filter(b=>bvis(b,true)&&b.grp===curB.grp):[curB];
  {const wc=useB0.filter(b=>b.tint.some(r=>r.some(v=>v)));if(wc.length) useB0=wc;}
  const useB=suBoards.filter(b=>useB0.includes(b));
  const groups=[];
  for(const b of useB){const S=suSetOfB(b);let g=groups.find(x=>x.S===S);if(!g){g={S,bs:[]};groups.push(g);}g.bs.push(b);}
  const mg=groups.length>1,pre=g=>mg?g.S.name+' · ':'';
  for(const g of groups){const e=suPrep(g,pre(g));if(e) return say(e,'bad');}
  const b2bOn=$('b2b').checked;
  suGo=true;running=true;$('sgo').style.display='none';$('sstop').style.display='';
  const ctl={stop:false};$('sstop').onclick=()=>{ctl.stop=true;};
  const t0=performance.now(),out=[];
  try{for(const g of groups){out.push(await suCalc(g,pre(g),ctl,say,b2bOn));if(ctl.stop) break;}}
  finally{running=false;suGo=false;$('sgo').style.display='';$('sstop').style.display='none';suLabels();}
  const sec=((performance.now()-t0)/1000).toFixed(1),part=out.length<groups.length;
  say((ctl.stop?L('중지됨 (일부만 계산) · ','Stopped (partial) · '):'')+(part?L(`설정 ${groups.length}개 중 ${out.length}개만 계산 · `,`${out.length} of ${groups.length} settings calculated · `):'')+L(`${sec}초`,`${sec}s`),ctl.stop?'':'ok');
  suRes={groups:out};suSel=0;suGrp=0;suShow();
  try{chSuDone(out,ctl,parseFloat(sec));}catch(_){}
}
function suSteps(fin){const steps=[];for(let s=fin;s&&s.act;s=s.prev) steps.push(s.act);return steps.reverse();}
function suShow(){
  const A=suRes;if(!A||!A.groups.length) return;
  suGrp=Math.max(0,Math.min(suGrp,A.groups.length-1));const o=A.groups[suGrp];
  $('su').style.display='';$('sres').style.display='';
  const {specs,R,T,multi}=o,pr=x=>T.W?x/T.W:0,pp=x=>x==null?'—':suPct(pr(x));
  const rqOf=i=>{const cs=specs[i].conds||[];return cs.length?L(' · 조건: ',' · requires: ')+cs.map(c=>condName(c.t)+' '+c.n+L('회 이상','+')).join(', '):'';},rqTxt=multi?'':rqOf(0);
  const info=(i)=>L(`쌓을 피스 ${specs[i].n}개 · 사용하는 넥스트 ${Math.min(o.needs[i],o.qlen)}개`,`${specs[i].n} pieces · ${Math.min(o.needs[i],o.qlen)} queue pieces used`)+(multi?rqOf(i):'');
  const meta=L(`홀드 ${o.holdFilled?'첫 피스로 시작':'빈 상태로 시작'} · 큐 ${o.done.toLocaleString()}개${rqTxt}`,`hold ${o.holdFilled?'starts with first piece':'starts empty'} · ${o.done.toLocaleString()} queues${rqTxt}`);
  let h='';const bo=!!o.b2b;
  if(!multi){
    const sp=specs[0],r=R[0];
    h=`<div class="hint" style="margin:0">${L('구축 확률','Build chance')}</div><div style="font:800 26px system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:var(--mint)">${suPct(pr(r.sw))}</div>`+
      (bo?`<div class="hint" style="margin:6px 0 0">${L('백투백 유지 확률','Back-to-back kept')}</div><div style="font:800 22px system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:var(--cy)">${suPct(pr(r.sb))}</div>`:'')+
      `<div class="hint" style="margin:6px 0 0">${info(0)} · ${L(`가능한 큐 ${r.sc.toLocaleString()} / ${o.done.toLocaleString()}`,`buildable queues ${r.sc.toLocaleString()} / ${o.done.toLocaleString()}`)}</div><div class="hint" style="margin:2px 0 0">${meta}</div>`;
  } else {
    const row=(name,a,b,i,bold,extra)=>`<div class="surow" data-i="${i}" style="display:grid;grid-template-columns:${bo?'1fr auto auto':'1fr auto'};gap:14px;padding:7px 4px;border-bottom:1px solid var(--line);border-left:4px solid ${i>=0?o.color:'transparent'};padding-left:8px;${i===suSel?'background:rgba(0,229,255,.1);':''}${i>=0?'cursor:pointer;':''}${bold?'font-weight:800;':''}"><span>${suEsc(name)}${extra||''}</span><span style="color:var(--mint);min-width:62px;text-align:right">${a}</span>${bo?`<span style="color:var(--cy);min-width:62px;text-align:right">${b}</span>`:''}</div>`;
    h=`<div class="surow" style="display:grid;grid-template-columns:${bo?'1fr auto auto':'1fr auto'};gap:14px;padding:4px;font-size:12px;color:var(--dim)"><span>${L('보드','Board')}</span><span style="min-width:62px;text-align:right">${L('구축','Build')}</span>${bo?`<span style="min-width:62px;text-align:right">${L('백투백','B2B')}</span>`:''}</div>`+
      specs.map((sp,i)=>{if(R[i].skipped) return row(sp.name+L(' (생략)',' (skipped)'),'—','—',i,false);
        return row(sp.name,suPct(pr(R[i].sw)),suPct(pr(R[i].sb)),i,false);}).join('')+
      row(L('하나라도 가능','Any board'),suPct(pr(T.any)),suPct(pr(T.anyB)),-1,true)+
      row(L('모두 가능','All boards'),pp(T.all),pp(T.allB),-1,true)+
      `<div class="hint" style="margin:8px 0 0">${meta}</div>`;
  }

  const sm=$('ssum');
  let gh='';
  if(A.groups.length>1) gh=`<div style="display:flex;gap:6px;flex-wrap:wrap;margin:0 0 10px">`+A.groups.map((g,j)=>`<button type="button" data-g="${j}" style="padding:6px 12px;font-size:13px;border:2px solid ${g.color};${j===suGrp?`background:${g.color};color:#000`:''}">${suEsc(g.S.name)}</button>`).join('')+`</div>`;
  gh+=`<div class="hint" style="margin:0 0 8px;color:${o.color}">${L('큐','Queue')} ${suEsc(o.qtxt)}</div>`;
  sm.innerHTML=gh+h;sm.style.borderLeftColor=o.color;
  sm.querySelectorAll('button[data-g]').forEach(e=>{e.onclick=()=>{suGrp=+e.dataset.g;suSel=0;suShow();};});
  sm.querySelectorAll('.surow[data-i]').forEach(e=>{const i=+e.dataset.i;if(i>=0) e.onclick=()=>{suSel=i;suShow();};});
  // 선택한 보드의 상세
  const i=Math.min(suSel,specs.length-1),sp=specs[i],r=R[i];
  const fe=$('sfail'),fe2=$('sfail2');
  const lst=(el,title,arr,count,show)=>{
    if(!show){el.style.display='none';el.innerHTML='';return;}
    const open=el.dataset.open==='1';
    arr=arr.slice().sort((a,b)=>b.w-a.w);
    let h=`<h3><button type="button" class="fold" data-fold>${open?'▾':'▸'} ${title} (${count.toLocaleString()}${L('개','')})</button></h3>`;
    if(open){
      if(!count) h+=`<div class="hint">${L('해당 큐 없음','No such queue.')}</div>`;
      else{
        h+=`<textarea readonly rows="8" style="width:100%;background:#0c0f1e;border:1px solid var(--line);color:var(--ink);font:12px monospace;padding:6px;box-sizing:border-box">`+arr.map(f=>f.q).join('\n')+`</textarea>`;
        h+=`<div class="hint">${count>arr.length?L(` 처음 ${arr.length.toLocaleString()}개만 표시.`,` Only the first ${arr.length.toLocaleString()} are shown.`):''}</div>`;
      }
    }
    el.innerHTML=h;el.style.display='';
    const fb=el.querySelector('button[data-fold]');if(fb) fb.onclick=()=>{el.dataset.open=open?'0':'1';lst(el,title,arr,count,show);};
  };
  const nm=multi?suEsc(sp.name)+' · ':'';
  lst(fe,nm+((sp.conds&&sp.conds.length)?L('조건을 만족하며 쌓을 수 없는 큐','Queues that cannot build it with the requirements'):L('쌓을 수 없는 큐','Queues that cannot build it')),r.fails,o.done-r.sc,!r.skipped);
  lst(fe2,nm+L('쌓을 수는 있지만 백투백이 끊기는 큐','Buildable but breaks back-to-back'),r.bf,r.sc-r.scb,bo&&sp.hasClear&&!r.skipped);
  $('svw').style.boxShadow=`0 0 0 4px ${o.color},0 0 14px 2px ${o.color}`;
  const exs=r.exB||r.ex;
  suEx=null;
  if(exs){let s0=exs.s;while(s0&&s0.act) s0=s0.prev;suEx={steps:suSteps(exs.s),q:exs.q,qi:(s0&&s0.qi)||0,hold:(s0&&s0.qi)?s0.h:-1,base:sp.baseRows.slice(),H:sp.H,b2b:!!r.exB,name:multi?sp.name:''};suStepI=0;}
  $('sexh').textContent=(suEx&&suEx.name?suEx.name+' · ':'')+(suEx&&suEx.b2b&&sp.hasClear?L('예시 쌓는 순서 (백투백 유지)','Example build order (keeps back-to-back)'):L('예시 쌓는 순서','Example build order'));
  $('sexh').style.display=suEx?'':'none';$('svw').style.display=suEx?'':'none';
  document.querySelector('#su .ctl').style.display=suEx?'':'none';$('scap').style.display=suEx?'':'none';
  if(suEx) suDraw();
}
function suDraw(){
  const e=suEx;if(!e) return;
  const cv=$('svw'),Hh=e.H;cv.width=COLS*CELL;cv.height=Hh*CELL;const c=cv.getContext('2d');
  c.clearRect(0,0,cv.width,cv.height);c.strokeStyle='#161b3a';c.lineWidth=1;c.beginPath();
  for(let i=0;i<=COLS;i++){c.moveTo(i*CELL+.5,0);c.lineTo(i*CELL+.5,Hh*CELL);}
  for(let j=0;j<=Hh;j++){c.moveTo(0,j*CELL+.5);c.lineTo(COLS*CELL,j*CELL+.5);}
  c.stroke();
  // 단계를 그린 좌표계(줄이 지워지지 않은 상태)로 쌓은 뒤, 꽉 찬 줄을 빼고 위 줄을 아래로 내려 보여 준다 = 라인 클리어 적용
  let lastCs=null,clearedNow=0,clearedAll=0;
  const fill=e.base.slice(),col=Array.from({length:Hh},()=>Array(COLS).fill(null));
  const nFull=()=>{let n=0;for(let y=0;y<Hh;y++) if(fill[BUF+y]===1023) n++;return n;};
  for(let i=0;i<suStepI;i++){const a=e.steps[i];clearedNow=0;if(!a.cs) continue;lastCs=a.cs;const before=nFull();
    for(const [y,x] of a.cs){fill[y]|=1<<x;col[y-BUF][x]=COLORS[TYPES[a.c]];}
    clearedNow=nFull()-before;}
  clearedAll=nFull();
  const keep=[];for(let y=0;y<Hh;y++) if(fill[BUF+y]!==1023) keep.push(y);
  const map=new Array(Hh).fill(-1);keep.forEach((y,j)=>{map[y]=Hh-keep.length+j;});
  for(const y of keep) for(let x=0;x<COLS;x++) if((e.base[BUF+y]>>x)&1) cell(c,x,map[y],COLORS.G);
  for(const y of keep) for(let x=0;x<COLS;x++) if(col[y][x]) cell(c,x,map[y],col[y][x]);
  if(lastCs){c.strokeStyle='#ffe14d';c.lineWidth=2;for(const [y,x] of lastCs){const r=map[y-BUF];if(r>=0) c.strokeRect(x*CELL+2,r*CELL+2,CELL-4,CELL-4);}}
  const a=suStepI>0?e.steps[suStepI-1]:null;
  $('scap').textContent=`${L('큐','Queue')} ${e.qi?e.q.slice(0,e.qi)+' | '+e.q.slice(e.qi):e.q} · `+(suStepI===0?L('시작','Start')+(e.hold>=0?L(` (홀드 ${TYPES[e.hold]})`,` (hold ${TYPES[e.hold]})`):''):a.hold?L('홀드에 넣음','Hold'):`${TYPES[a.c]}${a.held?L(' (홀드에서 꺼냄)',' (from hold)'):''}`)+(clearedNow?L(` · ${clearedNow}줄 삭제`,` · ${clearedNow} line${clearedNow>1?'s':''} cleared`):'')+` · ${suStepI}/${e.steps.length}`;
}
$('spv').onclick=()=>{if(suEx&&suStepI>0){suStepI--;suDraw();}};
$('snx').onclick=()=>{if(suEx&&suStepI<suEx.steps.length){suStepI++;suDraw();}};
$('sgo').onclick=()=>{if(!running) suRun();};
$('suAddC').onclick=()=>{const el=$('suCList');const open=el.dataset.open==='1';el.dataset.open=open?'0':'1';if(!open) el.dataset.step='root';renderCList();};
