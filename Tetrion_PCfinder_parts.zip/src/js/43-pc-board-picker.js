// ---- PC 찾기 모드의 보드 선택: 기본 보드(셋업과 완전히 별개) 또는 셋업 보드의 복사본 ----
function loadSnap(b){pcSyncLock=true;try{H=b.H;board=b.board.map(r=>r.slice());tint=b.tint.map(r=>r.slice());$('hh').value=H;drawEd();}finally{pcSyncLock=false;}}
function pcChips(){
  const el=$('pcsrc');if(!el||!suBoards||!pcSrc) return;
  if(SMODE){el.style.display='none';return;}
  el.style.display='';const ch=$('pcchips');ch.innerHTML='';
  const mk=(txt,color,on,fn,add)=>{const x=document.createElement('button');x.type='button';x.textContent=txt;
    x.style.cssText='padding:6px 12px;font-size:13px;touch-action:manipulation;border:2px solid '+color+(on?';background:'+color+';color:#000':'');
    if(on) x.dataset.cur='1';x.onclick=fn;ch.appendChild(x);};
  const dB=pcDefB();mk(L('기본보드','Default board'),'#8790b8',pcSrc===dB,()=>pcPick(dB));   // the PC finder's own default board (the setup builder has its own)
  if(suBoards&&suSets) suBoards.forEach(b=>{if(b.def||!bvis(b,false)) return;mk(bname(b),b.own!=='pc'?(b.grp?grpColor(b.grp):suCol(suSetOfB(b))):'#8790b8',pcSrc===b,()=>{if(pcSrc===b) suEditNum(ch.querySelector('button[data-cur]')||ch.lastChild,b);else pcPick(b);});const c=ch.lastChild;c._b=b;c.style.touchAction='none';c.style.userSelect='none';c.style.webkitTouchCallout='none';});
  mk(L('+ 보드 생성','+ New board'),'#5b6598',false,()=>pcMakeBoard(false));
  impUI(ch,false);
  const pm=$('pcmeta');   // same board row as the setup builder: number, duplicate, delete
  pm.style.display='';
  {
    $('pcdup').disabled=!suBoards||bcount(false)>=SU_MAX;$('pcdel').disabled=!!pcSrc.def||!suBoards;
    $('pcdup').onclick=()=>{
      if(running||SMODE) return;
      if(!suBoards||bcount(false)>=SU_MAX) return;
      const sn=suSnap(),src=pcSrc,b={num:suNextNum(suBoards,'pc'),own:'pc',set:src.set,H:sn.H,board:sn.board.map(r=>r.slice()),tint:sn.tint.map(r=>r.slice())};
      b.pq=$('q').value;b.phe=$('he').checked;
      suBoards.push(b);suCnt++;pcPick(b);pcChips();
    };
    $('pcdel').onclick=()=>{
      if(running||SMODE||!suBoards||!pcSrc||pcSrc.def) return;
      const i=suBoards.indexOf(pcSrc);if(i<0) return;
      const nums=suBoards.filter(b=>!b.def&&bvis(b,false)),k=nums.indexOf(pcSrc);
      if(bShared(pcSrc)){pcSrc.own='su';pcSrc.sh=false;}   // shared board: it only leaves the PC finder and stays in the Build mode
      else{suBoards.splice(i,1);suCnt=Math.max(0,suCnt-1);
        if(i<suCur) suCur--;else if(i===suCur) suCur=Math.min(suCur,suBoards.length-1);}
      const rest=suBoards.filter(b=>!b.def&&bvis(b,false));
      const tgt=rest.length?rest[Math.min(k,rest.length-1)]:pcDefB();   // neighbour board, else the PC finder's default board
      pcSrc=tgt;loadSnap(tgt);pcQLoad(pcQNow());pcQSave();$('hint6').style.display=H>MAXL?'':'none';
      pcChips();suBorder();restoreSaved();
    };
  }
  $('pcsrch').textContent='';$('pcsrch').style.display='none';
}
// create a board (setup-mode board list) from the field being edited, or from a given snapshot; works in the PC finder mode too
function pcMakeBoard(snap){
  if(running||SMODE) return null;
  suSetEnsure();
  if(!suBoards){suBoards=[];suCnt=0;suCur=0;}
  if(bcount(false)>=SU_MAX){st(L(`보드는 최대 ${SU_MAX}개`,`At most ${SU_MAX} boards.`),'bad');return null;}
  const sn=snap||{H,board:Array.from({length:H},()=>Array(COLS).fill(0)),tint:Array.from({length:H},()=>Array(COLS).fill(null))},b={num:suNextNum(suBoards,'pc'),own:'pc',set:suSets[Math.min(suSetCur,suSets.length-1)].id,useSet:false,H:sn.H,board:sn.board.map(r=>r.slice()),tint:sn.tint.map(r=>r.slice())};
  if(snap){b.pq=$('q').value;b.phe=$('he').checked;}else{b.pq='';b.phe=false;}   // 새 보드는 지형도 넥스트도 비어 있게 (현재 보드를 복사하지 않음)
  suBoards.push(b);suCnt++;pcChips();
  st(L(`${bname(b)} 생성`,`Created ${bname(b)}.`),'ok');
  return b;
}
function pcPick(src){
  if(running||SMODE||src===pcSrc) return;
  pcQSave();Object.assign(pcSrc,suSnap());
  loadSnap(src);
  pcSrc=src;pcQLoad(pcQNow());pcQSave();$('hint6').style.display=H>MAXL?'':'none';
  pcChips();suBorder();restoreSaved();
}
pcChips();
// ---- 설정(큐·홀드·조건·상징색) 목록: 보드마다 하나를 골라 배정 ----
function suCol(S){return S.color;}   // 색은 설정의 것: 설정을 안 쓰는 보드는 중립색
function suSetById(id){return suSets.find(S=>S.id===id)||suSets[0];}
function suSetsUI(){}   // (no settings bar any more)
function suSetOfB(b){return b&&b.useSet?suSetById(b.set):suOff;}   // the setting a board belongs to (suOff = none)
function suSetEnsure(){if(!suSets){suSets=[{id:1,name:L('설정 ','Setting ')+1,color:SET_COLORS[0],q:$('q').value,he:$('he').checked,conds:suConds}];suSetCur=0;suOff.q=$('q').value;suOff.he=$('he').checked;}}
function suSetSave(){if(!suSets||!SMODE||!suEdit) return;suEdit.q=$('q').value;suEdit.he=$('he').checked;}
function suOffLoad(){suEdit=suOff;$('q').value=suOff.q;$('he').checked=suOff.he;$('q').dispatchEvent(new Event('input',{bubbles:true}));renderConds();updOptSum();suSetsUI();}
function suLoadBoardSetting(b){   // show the Next / hold of the selected board's setting (or the plain one of a board without a setting)
  if(b.useSet){const si=suSets.findIndex(S=>S.id===b.set);if(si>=0&&(si!==suSetCur||suEdit!==suSets[si])) suSetLoad(si);}
  else if(suEdit!==suOff) suOffLoad();
}
function suSetLoad(i){
  suSetCur=i;const S=suSets[i];suEdit=S;
  $('q').value=S.q;$('he').checked=S.he;$('q').dispatchEvent(new Event('input',{bubbles:true}));
  renderConds();updOptSum();suSetsUI();
}
$('bnum').oninput=()=>{if(running||!suBoards) return;suBoards[suCur].num=$('bnum').value.trim()||'?';suChips();};
$('q').addEventListener('input',()=>{if(SMODE) suSetSave();});
$('he').addEventListener('change',()=>{if(SMODE) suSetSave();});
