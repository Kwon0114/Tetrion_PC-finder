
// ==== 자동 저장 / 복원 (localStorage) ====================================================================================================
// 보드·넥스트·옵션·설정·언어·모드를 브라우저에 저장하고, 다시 열면 그대로 복원한다. 저장이 막힌 환경(일부 앱 내 뷰어)에서는 조용히 건너뛴다.
const PKEY='tetrionPCFinder.v1';
const lsGet=()=>{try{return localStorage.getItem(PKEY);}catch(_){return null;}};
const lsSet=v=>{try{localStorage.setItem(PKEY,v);return true;}catch(_){return false;}};
const lsDel=()=>{try{localStorage.removeItem(PKEY);}catch(_){}};
const okSnap=b=>!!b&&Number.isInteger(b.H)&&b.H>=2&&b.H<=23&&Array.isArray(b.board)&&b.board.length===b.H&&b.board.every(r=>Array.isArray(r)&&r.length===COLS)
  &&Array.isArray(b.tint)&&b.tint.length===b.H&&b.tint.every(r=>Array.isArray(r)&&r.length===COLS);
const cpSnap=b=>({H:b.H,board:b.board.map(r=>r.slice()),tint:b.tint.map(r=>r.slice())});
function persistCollect(){
  if(running) return null;
  pcQSave();
  const d={v:1,lang:LANG,smode:SMODE,kmode:$('kmode').value,
    opt:{po:$('po').checked,so:$('so').checked,b2b:$('b2b').checked,jsc:$('jsc').checked,jb2:$('jb2').checked,jcb:$('jcb').value,see:$('see').value,sfon:$('sfon').checked,sfn:$('sfn').value}};
  if(SMODE&&suBoards&&suSets){suSaveCur();suSetSave();}
  // PC-mode values: while the setup mode is open they are parked in pcSrc (the field) / suPcQ / suPcHe
  if(SMODE){d.q=suPcQ;d.he=suPcHe;d.field=pcSrc?cpSnap(pcSrc):cpSnap(suSnap());}
  else{d.q=$('q').value;d.he=$('he').checked;d.field=cpSnap(suSnap());}
  d.pcSrc=suBoards&&pcSrc?suBoards.indexOf(pcSrc):-1;
  if(suBoards&&suSets) d.su={off:{q:suOff.q,he:!!suOff.he},cur:suCur,cnt:suCnt,setCur:suSetCur,
    boards:suBoards.map(b=>({grp:b.grp||'',num:b.num,set:b.set,own:b.own||'',sh:!!b.sh,useSet:!!b.useSet,def:b.def==='pc'?'pc':(b.def?'su':''),pq:typeof b.pq==='string'?b.pq:undefined,phe:!!b.phe,cl:b.cl|0,conds:(b.conds||[]).map(c=>({t:c.t,n:c.n})),...cpSnap(b)})),
    sets:suSets.map(S=>({id:S.id,name:S.name,color:S.color,q:S.q,he:!!S.he,all:!!S.all,conds:(S.conds||[]).map(c=>({t:c.t,n:c.n}))}))};
  return d;
}
let lastP='';
function persistSave(){
  let d;try{d=persistCollect();}catch(_){return;}
  if(!d) return;
  const s=JSON.stringify(d);if(s===lastP) return;
  if(lsSet(s)) lastP=s;
}
function persistLoad(){
  const raw=lsGet();if(!raw) return;
  try{
    const d=JSON.parse(raw);if(!d||d.v!==1) return;
    if(d.lang==='en') LANG='en';
    const o=d.opt||{};
    if(d.kmode==='js'||d.kmode==='tio') $('kmode').value=d.kmode;
    for(const id of ['po','so','b2b','jsc','jb2','sfon']) if(typeof o[id]==='boolean') $(id).checked=o[id];
    if(o.see!=null) $('see').value=o.see;
    if(o.sfn) $('sfn').value=o.sfn;
    if(typeof d.q==='string') $('q').value=d.q;
    if(typeof d.he==='boolean') $('he').checked=d.he;
    // setup mode data (boards + settings)
    const U=d.su;
    if(U&&Array.isArray(U.boards)&&Array.isArray(U.sets)&&U.sets.length&&U.boards.length&&U.boards.every(okSnap)){
      suSets=U.sets.map(S=>({id:+S.id||1,name:String(S.name||'설정'),color:String(S.color||SET_COLORS[0]),q:String(S.q||''),he:!!S.he,all:!!S.all,
        conds:(Array.isArray(S.conds)?S.conds:[]).filter(c=>c&&c.t>=0&&c.t<COND.length).map(c=>({t:c.t|0,n:Math.max(1,Math.min(7,c.n|0||1))}))}));
      suSetCur=Math.min(Math.max(0,U.setCur|0),suSets.length-1);
      suBoards=U.boards.map(b=>({grp:typeof b.grp==='string'?b.grp:'',num:String(b.num||'1'),own:b.own==='pc'||b.own==='su'?b.own:'',sh:!!b.sh,useSet:false,set:suSets.some(S=>S.id===b.set)?b.set:suSets[0].id,def:b.def==='pc'?'pc':(b.def?'su':''),pq:typeof b.pq==='string'?b.pq:undefined,phe:!!b.phe,cl:Math.max(0,Math.min(23,b.cl|0)),conds:(Array.isArray(b.conds)?b.conds:((suSets.find(S=>S.id===b.set)||suSets[0]).conds||[])).filter(c=>c&&c.t>=0&&c.t<COND.length).map(c=>({t:c.t|0,n:Math.max(1,Math.min(7,c.n|0||1))})),...cpSnap(b)}));   // 예전 저장본: 설정의 조건을 각 보드에 복사
      if(U.off&&typeof U.off==='object'){suOff.q=String(U.off.q||'');suOff.he=!!U.off.he;}else{const S0=suSets[suSetCur];suOff.q=S0.q;suOff.he=S0.he;}   // older saves: the boards without a setting used the edited setting's Next / hold
      suCur=Math.min(Math.max(0,U.cur|0),suBoards.length-1);suCnt=Math.max(suBoards.length,U.cnt|0);suConds=suBoards[suCur].conds;
    }
    if(okSnap(d.field)) loadSnap(d.field);
    boardsEnsure({snap:okSnap(d.pcDef)?cpSnap(d.pcDef):null,q:d.pcDefQ&&typeof d.pcDefQ.pq==='string'?d.pcDefQ:null});   // older saves kept the PC default apart (d.pcDef / d.pcDefQ)
    {const sc=suBoards[suCur],ps=d.pcSrc>=0?suBoards[d.pcSrc]:null;suOrderFix();suCur=Math.max(0,suBoards.indexOf(sc));if(ps) d.pcSrc=suBoards.indexOf(ps);}   // saves made before this fix may have a chained board in front of its parent
    pcSrc=(d.pcSrc>=0&&suBoards[d.pcSrc]&&bvis(suBoards[d.pcSrc],false))?suBoards[d.pcSrc]:pcDefB();
    if(!d.smode) pcQLoad(pcQNow());
    $('kmode').dispatchEvent(new Event('change'));
    $('jsc').dispatchEvent(new Event('change'));
    if(o.jcb!=null) $('jcb').value=o.jcb;
    $('sfon').dispatchEvent(new Event('change'));
    $('q').dispatchEvent(new Event('input',{bubbles:true}));
    $('hint6').style.display=H>MAXL?'':'none';
    applyLang();
    if(d.smode) setMode(true); else {pcChips();suBorder();}
  }catch(err){lsDel();}
}
persistLoad();
// both default boards exist from the start
boardsEnsure(null);if(!pcSrc||!suBoards.includes(pcSrc)) pcSrc=pcDefB();pcChips();
$('q').addEventListener('input',pcQSave);$('he').addEventListener('change',pcQSave);
setInterval(persistSave,1500);
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden') persistSave();});
addEventListener('pagehide',persistSave);
// offline / install: the service worker only exists when the page is served over http(s) next to sw.js
suLabels();
window.__test={search,placementIds,snapshot};
